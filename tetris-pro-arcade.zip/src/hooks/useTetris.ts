const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { BOARD_WIDTH, TOTAL_ROWS, TETROMINOES, SPAWN_POSITIONS, JLSTZ_WALL_KICKS, I_WALL_KICKS, LEVEL_SPEEDS, LOCK_DELAY_MS, MAX_LOCK_RESETS, SCORES } from "/src/utils/tetrisConstants.ts";
import { sound } from "/src/utils/soundEffects.ts";
const ALL_PIECES = [
	"I",
	"J",
	"L",
	"O",
	"S",
	"T",
	"Z"
];
// Fisher-Yates shuffle for 7-bag randomizer
function generateBag() {
	const bag = [...ALL_PIECES];
	for (let i = bag.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[bag[i], bag[j]] = [bag[j], bag[i]];
	}
	return bag;
}
function createEmptyBoard() {
	return Array.from({ length: TOTAL_ROWS }, () => Array(BOARD_WIDTH).fill(null));
}
// Checks if piece collides with walls or locked blocks
export function checkCollision(piece, board, offset = {
	x: 0,
	y: 0
}) {
	const coords = TETROMINOES[piece.type][piece.rotation];
	for (const coord of coords) {
		const targetX = piece.position.x + coord.x + offset.x;
		const targetY = piece.position.y + coord.y + offset.y;
		if (targetX < 0 || targetX >= BOARD_WIDTH) return true;
		if (targetY >= TOTAL_ROWS) return true;
		if (targetY >= 0 && board[targetY][targetX] !== null) return true;
	}
	return false;
}
export function useTetris(gameMode = "marathon") {
	const [board, setBoard] = useState(createEmptyBoard);
	const [currentPiece, setCurrentPiece] = useState(null);
	const [ghostY, setGhostY] = useState(0);
	const [nextQueue, setNextQueue] = useState([]);
	const [holdPiece, setHoldPiece] = useState(null);
	const [canHold, setCanHold] = useState(true);
	const [gameStatus, setGameStatus] = useState("idle");
	const [clearingRows, setClearingRows] = useState([]);
	const [popups, setPopups] = useState([]);
	const [boardShake, setBoardShake] = useState(false);
	const [zenSpeed, setZenSpeed] = useState(500);
	const [stats, setStats] = useState({
		score: 0,
		lines: 0,
		level: 1,
		singles: 0,
		doubles: 0,
		triples: 0,
		tetrises: 0,
		tspins: 0,
		maxCombo: 0,
		currentCombo: -1,
		backToBack: false,
		startTime: 0,
		elapsedTime: 0,
		remainingLines: gameMode === "sprint" ? 40 : undefined,
		remainingTime: gameMode === "ultra" ? 120 : undefined
	});
	const [highScores, setHighScores] = useState(() => {
		try {
			const saved = localStorage.getItem("tetris_high_scores");
			return saved ? JSON.parse(saved) : [];
		} catch {
			return [];
		}
	});
	// Internal refs to prevent stale state in requestAnimationFrame and interval loops
	const bagRef = useRef([]);
	const boardRef = useRef(board);
	boardRef.current = board;
	const currentPieceRef = useRef(currentPiece);
	currentPieceRef.current = currentPiece;
	const gameStatusRef = useRef(gameStatus);
	gameStatusRef.current = gameStatus;
	const statsRef = useRef(stats);
	statsRef.current = stats;
	const lockTimeoutRef = useRef(null);
	const lockResetsRef = useRef(0);
	const dropTimerRef = useRef(null);
	const ultraTimerRef = useRef(null);
	const lastRotateWasTSpinRef = useRef(false);
	// Trigger floating popup notification (e.g. "+800 TETRIS!")
	const addPopup = useCallback((text, points, color) => {
		const popup = {
			id: `${Date.now()}-${Math.random()}`,
			text,
			points,
			color,
			time: Date.now()
		};
		setPopups((prev) => [...prev.slice(-3), popup]);
	}, []);
	// Compute ghost piece position
	const calculateGhostY = useCallback((piece, b) => {
		let offset = 0;
		while (!checkCollision(piece, b, {
			x: 0,
			y: offset + 1
		})) {
			offset++;
		}
		return piece.position.y + offset;
	}, []);
	// Helper to pull next piece from queue and replenish 7-bag
	const getNextPieceType = useCallback(() => {
		let currentBag = bagRef.current;
		if (currentBag.length < 7) {
			currentBag = [...currentBag, ...generateBag()];
			bagRef.current = currentBag;
		}
		const nextType = currentBag[0];
		const updatedBag = currentBag.slice(1);
		bagRef.current = updatedBag;
		setNextQueue(updatedBag.slice(0, 5));
		return nextType;
	}, []);
	// Spawn a new piece
	const spawnPiece = useCallback((typeToSpawn) => {
		const type = typeToSpawn || getNextPieceType();
		const newPiece = {
			type,
			rotation: 0,
			position: { ...SPAWN_POSITIONS[type] }
		};
		// Check game over (spawning piece immediately collides)
		if (checkCollision(newPiece, boardRef.current)) {
			if (gameMode !== "zen") {
				setGameStatus("gameover");
				sound.playGameOver();
				return;
			} else {
				// In Zen mode, clear top rows to keep practicing
				const cleared = createEmptyBoard();
				setBoard(cleared);
				boardRef.current = cleared;
			}
		}
		setCurrentPiece(newPiece);
		currentPieceRef.current = newPiece;
		setGhostY(calculateGhostY(newPiece, boardRef.current));
		setCanHold(true);
		lockResetsRef.current = 0;
		lastRotateWasTSpinRef.current = false;
	}, [
		calculateGhostY,
		gameMode,
		getNextPieceType
	]);
	// Lock the current piece into the board and check line clears
	const lockPiece = useCallback(() => {
		const piece = currentPieceRef.current;
		if (!piece) return;
		if (lockTimeoutRef.current) {
			window.clearTimeout(lockTimeoutRef.current);
			lockTimeoutRef.current = null;
		}
		const coords = TETROMINOES[piece.type][piece.rotation];
		const newBoard = boardRef.current.map((row) => [...row]);
		// Stamp piece into board
		for (const coord of coords) {
			const x = piece.position.x + coord.x;
			const y = piece.position.y + coord.y;
			if (y >= 0 && y < TOTAL_ROWS && x >= 0 && x < BOARD_WIDTH) {
				newBoard[y][x] = piece.type;
			}
		}
		// Identify complete lines (ignoring buffer rows)
		const fullRowIndices = [];
		for (let r = 0; r < TOTAL_ROWS; r++) {
			if (newBoard[r].every((cell) => cell !== null)) {
				fullRowIndices.push(r);
			}
		}
		const isTSpin = lastRotateWasTSpinRef.current;
		if (fullRowIndices.length > 0) {
			// Trigger line clear visual flash
			setClearingRows(fullRowIndices);
			sound.playLineClear(fullRowIndices.length);
			// Camera shake on big clears
			if (fullRowIndices.length >= 4 || isTSpin) {
				setBoardShake(true);
				setTimeout(() => setBoardShake(false), 250);
			}
			setTimeout(() => {
				// Remove cleared rows and add fresh empty rows at top
				const remainingBoard = newBoard.filter((_, idx) => !fullRowIndices.includes(idx));
				const emptyRows = Array.from({ length: fullRowIndices.length }, () => Array(BOARD_WIDTH).fill(null));
				const finalBoard = [...emptyRows, ...remainingBoard];
				setBoard(finalBoard);
				boardRef.current = finalBoard;
				setClearingRows([]);
				// Score Calculation
				const linesCount = fullRowIndices.length;
				const currentLvl = statsRef.current.level;
				const currentCombo = statsRef.current.currentCombo + 1;
				const isB2B = statsRef.current.backToBack;
				let basePoints = 0;
				let actionLabel = "";
				if (isTSpin) {
					if (linesCount === 1) {
						basePoints = SCORES.TSPIN_SINGLE * currentLvl;
						actionLabel = "T-SPIN SINGLE";
					} else if (linesCount === 2) {
						basePoints = SCORES.TSPIN_DOUBLE * currentLvl;
						actionLabel = "T-SPIN DOUBLE!";
					} else if (linesCount === 3) {
						basePoints = SCORES.TSPIN_TRIPLE * currentLvl;
						actionLabel = "T-SPIN TRIPLE!!";
					}
				} else {
					switch (linesCount) {
						case 1:
							basePoints = SCORES.SINGLE * currentLvl;
							actionLabel = "SINGLE";
							break;
						case 2:
							basePoints = SCORES.DOUBLE * currentLvl;
							actionLabel = "DOUBLE!";
							break;
						case 3:
							basePoints = SCORES.TRIPLE * currentLvl;
							actionLabel = "TRIPLE!!";
							break;
						case 4:
							basePoints = (isB2B ? SCORES.B2B_TETRIS : SCORES.TETRIS) * currentLvl;
							actionLabel = isB2B ? "B2B TETRIS!!" : "TETRIS!";
							break;
					}
				}
				// Combo bonus
				const comboBonus = currentCombo > 0 ? 50 * currentCombo * currentLvl : 0;
				const totalPoints = basePoints + comboBonus;
				if (actionLabel) {
					addPopup(`${actionLabel} ${currentCombo > 0 ? `· ${currentCombo} COMBO` : ""}`, totalPoints);
				}
				const newTotalLines = statsRef.current.lines + linesCount;
				const newLevel = gameMode === "marathon" ? Math.floor(newTotalLines / 10) + 1 : currentLvl;
				if (newLevel > currentLvl) {
					sound.playLevelUp();
					addPopup(`LEVEL ${newLevel}!`, 0, "#38bdf8");
				}
				// Check Sprint mode win
				if (gameMode === "sprint" && newTotalLines >= 40) {
					setGameStatus("victory");
					sound.playVictory();
				}
				setStats((prev) => ({
					...prev,
					score: prev.score + totalPoints,
					lines: newTotalLines,
					level: newLevel,
					singles: prev.singles + (linesCount === 1 ? 1 : 0),
					doubles: prev.doubles + (linesCount === 2 ? 1 : 0),
					triples: prev.triples + (linesCount === 3 ? 1 : 0),
					tetrises: prev.tetrises + (linesCount === 4 ? 1 : 0),
					tspins: prev.tspins + (isTSpin ? 1 : 0),
					currentCombo,
					maxCombo: Math.max(prev.maxCombo, currentCombo),
					backToBack: linesCount === 4 || isTSpin,
					remainingLines: gameMode === "sprint" ? Math.max(0, 40 - newTotalLines) : undefined
				}));
				spawnPiece();
			}, 160);
		} else {
			// No lines cleared: reset combo and advance piece
			setBoard(newBoard);
			boardRef.current = newBoard;
			setStats((prev) => ({
				...prev,
				currentCombo: -1,
				backToBack: isTSpin ? prev.backToBack : prev.backToBack
			}));
			spawnPiece();
		}
	}, [
		addPopup,
		gameMode,
		spawnPiece
	]);
	// Try movement
	const moveHorizontal = useCallback((direction) => {
		if (gameStatusRef.current !== "playing" || !currentPieceRef.current) return false;
		const piece = currentPieceRef.current;
		if (!checkCollision(piece, boardRef.current, {
			x: direction,
			y: 0
		})) {
			const movedPiece = {
				...piece,
				position: {
					x: piece.position.x + direction,
					y: piece.position.y
				}
			};
			setCurrentPiece(movedPiece);
			currentPieceRef.current = movedPiece;
			setGhostY(calculateGhostY(movedPiece, boardRef.current));
			sound.playMove();
			// Reset lock timer if on ground and within lock limit
			if (checkCollision(movedPiece, boardRef.current, {
				x: 0,
				y: 1
			})) {
				if (lockResetsRef.current < MAX_LOCK_RESETS) {
					lockResetsRef.current++;
					if (lockTimeoutRef.current) {
						window.clearTimeout(lockTimeoutRef.current);
						lockTimeoutRef.current = null;
					}
				}
			}
			return true;
		}
		return false;
	}, [calculateGhostY]);
	// Soft Drop
	const softDrop = useCallback(() => {
		if (gameStatusRef.current !== "playing" || !currentPieceRef.current) return;
		const piece = currentPieceRef.current;
		if (!checkCollision(piece, boardRef.current, {
			x: 0,
			y: 1
		})) {
			const droppedPiece = {
				...piece,
				position: {
					x: piece.position.x,
					y: piece.position.y + 1
				}
			};
			setCurrentPiece(droppedPiece);
			currentPieceRef.current = droppedPiece;
			sound.playSoftDrop();
			setStats((prev) => ({
				...prev,
				score: prev.score + SCORES.SOFT_DROP
			}));
		}
	}, []);
	// Hard Drop
	const hardDrop = useCallback(() => {
		if (gameStatusRef.current !== "playing" || !currentPieceRef.current) return;
		const piece = currentPieceRef.current;
		let dropDistance = 0;
		while (!checkCollision(piece, boardRef.current, {
			x: 0,
			y: dropDistance + 1
		})) {
			dropDistance++;
		}
		const droppedPiece = {
			...piece,
			position: {
				x: piece.position.x,
				y: piece.position.y + dropDistance
			}
		};
		setCurrentPiece(droppedPiece);
		currentPieceRef.current = droppedPiece;
		sound.playHardDrop();
		// Visual camera punch
		setBoardShake(true);
		setTimeout(() => setBoardShake(false), 120);
		setStats((prev) => ({
			...prev,
			score: prev.score + dropDistance * SCORES.HARD_DROP
		}));
		lockPiece();
	}, [lockPiece]);
	// Rotate Piece using SRS (Super Rotation System)
	const rotate = useCallback((clockwise = true) => {
		if (gameStatusRef.current !== "playing" || !currentPieceRef.current) return;
		const piece = currentPieceRef.current;
		if (piece.type === "O") return;
		const currentRot = piece.rotation;
		const nextRot = clockwise ? (currentRot + 1) % 4 : (currentRot + 3) % 4;
		const kickKey = `${currentRot}->${nextRot}`;
		const kicks = piece.type === "I" ? I_WALL_KICKS[kickKey] : JLSTZ_WALL_KICKS[kickKey];
		if (!kicks) return;
		for (const kick of kicks) {
			const testPiece = {
				...piece,
				rotation: nextRot,
				position: {
					x: piece.position.x + kick.x,
					y: piece.position.y - kick.y
				}
			};
			if (!checkCollision(testPiece, boardRef.current)) {
				// T-Spin detection (3-corner rule)
				if (piece.type === "T") {
					const cx = testPiece.position.x + 1;
					const cy = testPiece.position.y + 1;
					const corners = [
						{
							x: cx - 1,
							y: cy - 1
						},
						{
							x: cx + 1,
							y: cy - 1
						},
						{
							x: cx - 1,
							y: cy + 1
						},
						{
							x: cx + 1,
							y: cy + 1
						}
					];
					let occupiedCorners = 0;
					for (const c of corners) {
						if (c.x < 0 || c.x >= BOARD_WIDTH || c.y >= TOTAL_ROWS || c.y >= 0 && boardRef.current[c.y][c.x] !== null) {
							occupiedCorners++;
						}
					}
					lastRotateWasTSpinRef.current = occupiedCorners >= 3;
				} else {
					lastRotateWasTSpinRef.current = false;
				}
				setCurrentPiece(testPiece);
				currentPieceRef.current = testPiece;
				setGhostY(calculateGhostY(testPiece, boardRef.current));
				sound.playRotate();
				// Lock delay reset
				if (lockResetsRef.current < MAX_LOCK_RESETS) {
					lockResetsRef.current++;
					if (lockTimeoutRef.current) {
						window.clearTimeout(lockTimeoutRef.current);
						lockTimeoutRef.current = null;
					}
				}
				return;
			}
		}
	}, [calculateGhostY]);
	// Hold Piece
	const hold = useCallback(() => {
		if (gameStatusRef.current !== "playing" || !currentPieceRef.current || !canHold) return;
		sound.playHold();
		const currentType = currentPieceRef.current.type;
		if (holdPiece === null) {
			setHoldPiece(currentType);
			spawnPiece();
		} else {
			const nextType = holdPiece;
			setHoldPiece(currentType);
			spawnPiece(nextType);
		}
		setCanHold(false);
	}, [
		canHold,
		holdPiece,
		spawnPiece
	]);
	// Start new game
	const startGame = useCallback((mode = gameMode) => {
		const empty = createEmptyBoard();
		setBoard(empty);
		boardRef.current = empty;
		bagRef.current = generateBag();
		const initialQueue = [...bagRef.current, ...generateBag()];
		bagRef.current = initialQueue.slice(1);
		setNextQueue(bagRef.current.slice(0, 5));
		setHoldPiece(null);
		setCanHold(true);
		setClearingRows([]);
		setPopups([]);
		lockResetsRef.current = 0;
		lastRotateWasTSpinRef.current = false;
		setStats({
			score: 0,
			lines: 0,
			level: 1,
			singles: 0,
			doubles: 0,
			triples: 0,
			tetrises: 0,
			tspins: 0,
			maxCombo: 0,
			currentCombo: -1,
			backToBack: false,
			startTime: Date.now(),
			elapsedTime: 0,
			remainingLines: mode === "sprint" ? 40 : undefined,
			remainingTime: mode === "ultra" ? 120 : undefined
		});
		const firstPieceType = initialQueue[0];
		const newPiece = {
			type: firstPieceType,
			rotation: 0,
			position: { ...SPAWN_POSITIONS[firstPieceType] }
		};
		setCurrentPiece(newPiece);
		currentPieceRef.current = newPiece;
		setGhostY(calculateGhostY(newPiece, empty));
		setGameStatus("playing");
	}, [calculateGhostY, gameMode]);
	// Pause / Resume
	const togglePause = useCallback(() => {
		setGameStatus((prev) => {
			if (prev === "playing") return "paused";
			if (prev === "paused") return "playing";
			return prev;
		});
	}, []);
	// Main Gravity Game Loop
	useEffect(() => {
		if (gameStatus !== "playing") {
			if (dropTimerRef.current) {
				window.clearTimeout(dropTimerRef.current);
				dropTimerRef.current = null;
			}
			return;
		}
		const currentLvl = stats.level;
		const speed = gameMode === "zen" ? zenSpeed : LEVEL_SPEEDS[Math.min(currentLvl - 1, LEVEL_SPEEDS.length - 1)];
		const tick = () => {
			if (gameStatusRef.current !== "playing") return;
			const piece = currentPieceRef.current;
			if (!piece) return;
			if (!checkCollision(piece, boardRef.current, {
				x: 0,
				y: 1
			})) {
				// Drop 1 row
				const droppedPiece = {
					...piece,
					position: {
						x: piece.position.x,
						y: piece.position.y + 1
					}
				};
				setCurrentPiece(droppedPiece);
				currentPieceRef.current = droppedPiece;
			} else {
				// Piece hit ground: initiate lock delay if not already active
				if (!lockTimeoutRef.current) {
					lockTimeoutRef.current = window.setTimeout(() => {
						lockPiece();
					}, LOCK_DELAY_MS);
				}
			}
			dropTimerRef.current = window.setTimeout(tick, speed);
		};
		dropTimerRef.current = window.setTimeout(tick, speed);
		return () => {
			if (dropTimerRef.current) {
				window.clearTimeout(dropTimerRef.current);
				dropTimerRef.current = null;
			}
		};
	}, [
		gameStatus,
		stats.level,
		gameMode,
		zenSpeed,
		lockPiece
	]);
	// Timer loop for Ultra Mode & Elapsed Time
	useEffect(() => {
		if (gameStatus !== "playing") {
			if (ultraTimerRef.current) {
				window.clearInterval(ultraTimerRef.current);
				ultraTimerRef.current = null;
			}
			return;
		}
		ultraTimerRef.current = window.setInterval(() => {
			setStats((prev) => {
				const nextElapsed = prev.startTime > 0 ? Date.now() - prev.startTime : 0;
				if (gameMode === "ultra") {
					const nextRemaining = Math.max(0, 120 - Math.floor(nextElapsed / 1e3));
					if (nextRemaining <= 0) {
						setGameStatus("victory");
						sound.playVictory();
						return {
							...prev,
							elapsedTime: nextElapsed,
							remainingTime: 0
						};
					}
					return {
						...prev,
						elapsedTime: nextElapsed,
						remainingTime: nextRemaining
					};
				}
				return {
					...prev,
					elapsedTime: nextElapsed
				};
			});
		}, 100);
		return () => {
			if (ultraTimerRef.current) {
				window.clearInterval(ultraTimerRef.current);
				ultraTimerRef.current = null;
			}
		};
	}, [gameStatus, gameMode]);
	// Sync high scores to local storage on gameover or victory
	useEffect(() => {
		if (gameStatus === "gameover" || gameStatus === "victory") {
			if (stats.score > 0) {
				const entry = {
					id: `${Date.now()}`,
					mode: gameMode,
					score: stats.score,
					lines: stats.lines,
					level: stats.level,
					timeMs: stats.elapsedTime,
					date: new Date().toLocaleDateString(undefined, {
						month: "short",
						day: "numeric",
						year: "numeric"
					})
				};
				setHighScores((prev) => {
					const updated = [...prev, entry].sort((a, b) => b.score - a.score).slice(0, 20);
					try {
						localStorage.setItem("tetris_high_scores", JSON.stringify(updated));
					} catch {}
					return updated;
				});
			}
		}
	}, [
		gameStatus,
		gameMode,
		stats.score,
		stats.lines,
		stats.level,
		stats.elapsedTime
	]);
	return {
		board,
		currentPiece,
		ghostY,
		nextQueue,
		holdPiece,
		canHold,
		gameStatus,
		stats,
		highScores,
		clearingRows,
		popups,
		boardShake,
		zenSpeed,
		setZenSpeed,
		startGame,
		togglePause,
		moveHorizontal,
		softDrop,
		hardDrop,
		rotate,
		hold
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxVQUFVLFdBQVcsUUFBUSxtQkFBbUI7QUFhekQsU0FDRSxhQUdBLFlBQ0EsYUFDQSxpQkFDQSxrQkFDQSxjQUNBLGNBQ0EsZUFDQSxpQkFDQSxjQUNLO0FBQ1AsU0FBUyxhQUFhO0FBRXRCLE1BQU0sYUFBOEI7Q0FBQztDQUFLO0NBQUs7Q0FBSztDQUFLO0NBQUs7Q0FBSztBQUFHOztBQUd0RSxTQUFTLGNBQStCO0NBQ3RDLE1BQU0sTUFBTSxDQUFDLEdBQUcsVUFBVTtDQUMxQixLQUFLLElBQUksSUFBSSxJQUFJLFNBQVMsR0FBRyxJQUFJLEdBQUcsS0FBSztFQUN2QyxNQUFNLElBQUksS0FBSyxNQUFNLEtBQUssT0FBTyxLQUFLLElBQUksRUFBRTtFQUM1QyxDQUFDLElBQUksSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLElBQUksSUFBSSxFQUFFO0NBQ3BDO0NBQ0EsT0FBTztBQUNUO0FBRUEsU0FBUyxtQkFBMEI7Q0FDakMsT0FBTyxNQUFNLEtBQUssRUFBRSxRQUFRLFdBQVcsU0FBUyxNQUFNLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0FBQy9FOztBQUdBLE9BQU8sU0FBUyxlQUFlLE9BQWMsT0FBYyxTQUFtQjtDQUFFLEdBQUc7Q0FBRyxHQUFHO0FBQUUsR0FBWTtDQUNyRyxNQUFNLFNBQVMsWUFBWSxNQUFNLEtBQUssQ0FBQyxNQUFNO0NBQzdDLEtBQUssTUFBTSxTQUFTLFFBQVE7RUFDMUIsTUFBTSxVQUFVLE1BQU0sU0FBUyxJQUFJLE1BQU0sSUFBSSxPQUFPO0VBQ3BELE1BQU0sVUFBVSxNQUFNLFNBQVMsSUFBSSxNQUFNLElBQUksT0FBTztFQUVwRCxJQUFJLFVBQVUsS0FBSyxXQUFXLGFBQWEsT0FBTztFQUNsRCxJQUFJLFdBQVcsWUFBWSxPQUFPO0VBQ2xDLElBQUksV0FBVyxLQUFLLE1BQU0sUUFBUSxDQUFDLGFBQWEsTUFBTSxPQUFPO0NBQy9EO0NBQ0EsT0FBTztBQUNUO0FBRUEsT0FBTyxTQUFTLFVBQVUsV0FBcUIsWUFBWTtDQUN6RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWdCLGdCQUFnQjtDQUMxRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBdUIsSUFBSTtDQUNuRSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlCLENBQUM7Q0FDOUMsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQTBCLENBQUMsQ0FBQztDQUM5RCxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBK0IsSUFBSTtDQUNyRSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQWtCLElBQUk7Q0FDcEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQXFCLE1BQU07Q0FDL0QsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQW1CLENBQUMsQ0FBQztDQUM3RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQXdCLENBQUMsQ0FBQztDQUN0RCxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBa0IsS0FBSztDQUMzRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLEdBQUc7Q0FFcEQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFvQjtFQUM1QyxPQUFPO0VBQ1AsT0FBTztFQUNQLE9BQU87RUFDUCxTQUFTO0VBQ1QsU0FBUztFQUNULFNBQVM7RUFDVCxVQUFVO0VBQ1YsUUFBUTtFQUNSLFVBQVU7RUFDVixjQUFjLENBQUM7RUFDZixZQUFZO0VBQ1osV0FBVztFQUNYLGFBQWE7RUFDYixnQkFBZ0IsYUFBYSxXQUFXLEtBQUs7RUFDN0MsZUFBZSxhQUFhLFVBQVUsTUFBTTtDQUM5QyxDQUFDO0NBRUQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLGVBQWlDO0VBQ25FLElBQUk7R0FDRixNQUFNLFFBQVEsYUFBYSxRQUFRLG9CQUFvQjtHQUN2RCxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSSxDQUFDO0VBQ3RDLFFBQVE7R0FDTixPQUFPLENBQUM7RUFDVjtDQUNGLENBQUM7O0NBR0QsTUFBTSxTQUFTLE9BQXdCLENBQUMsQ0FBQztDQUN6QyxNQUFNLFdBQVcsT0FBYyxLQUFLO0NBQ3BDLFNBQVMsVUFBVTtDQUNuQixNQUFNLGtCQUFrQixPQUFxQixZQUFZO0NBQ3pELGdCQUFnQixVQUFVO0NBQzFCLE1BQU0sZ0JBQWdCLE9BQW1CLFVBQVU7Q0FDbkQsY0FBYyxVQUFVO0NBQ3hCLE1BQU0sV0FBVyxPQUFrQixLQUFLO0NBQ3hDLFNBQVMsVUFBVTtDQUVuQixNQUFNLGlCQUFpQixPQUFzQixJQUFJO0NBQ2pELE1BQU0sZ0JBQWdCLE9BQWUsQ0FBQztDQUN0QyxNQUFNLGVBQWUsT0FBc0IsSUFBSTtDQUMvQyxNQUFNLGdCQUFnQixPQUFzQixJQUFJO0NBQ2hELE1BQU0sd0JBQXdCLE9BQWdCLEtBQUs7O0NBR25ELE1BQU0sV0FBVyxhQUFhLE1BQWMsUUFBZ0IsVUFBbUI7RUFDN0UsTUFBTSxRQUFxQjtHQUN6QixJQUFJLEdBQUcsS0FBSyxJQUFJLEVBQUUsR0FBRyxLQUFLLE9BQU87R0FDakM7R0FDQTtHQUNBO0dBQ0EsTUFBTSxLQUFLLElBQUk7RUFDakI7RUFDQSxXQUFXLFNBQVMsQ0FBQyxHQUFHLEtBQUssTUFBTSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7Q0FDaEQsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxrQkFBa0IsYUFBYSxPQUFjLE1BQXFCO0VBQ3RFLElBQUksU0FBUztFQUNiLE9BQU8sQ0FBQyxlQUFlLE9BQU8sR0FBRztHQUFFLEdBQUc7R0FBRyxHQUFHLFNBQVM7RUFBRSxDQUFDLEdBQUc7R0FDekQ7RUFDRjtFQUNBLE9BQU8sTUFBTSxTQUFTLElBQUk7Q0FDNUIsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxtQkFBbUIsa0JBQWlDO0VBQ3hELElBQUksYUFBYSxPQUFPO0VBQ3hCLElBQUksV0FBVyxTQUFTLEdBQUc7R0FDekIsYUFBYSxDQUFDLEdBQUcsWUFBWSxHQUFHLFlBQVksQ0FBQztHQUM3QyxPQUFPLFVBQVU7RUFDbkI7RUFFQSxNQUFNLFdBQVcsV0FBVztFQUM1QixNQUFNLGFBQWEsV0FBVyxNQUFNLENBQUM7RUFDckMsT0FBTyxVQUFVO0VBQ2pCLGFBQWEsV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ25DLE9BQU87Q0FDVCxHQUFHLENBQUMsQ0FBQzs7Q0FHTCxNQUFNLGFBQWEsYUFBYSxnQkFBZ0M7RUFDOUQsTUFBTSxPQUFPLGVBQWUsaUJBQWlCO0VBQzdDLE1BQU0sV0FBa0I7R0FDdEI7R0FDQSxVQUFVO0dBQ1YsVUFBVSxFQUFFLEdBQUcsZ0JBQWdCLE1BQU07RUFDdkM7O0VBR0EsSUFBSSxlQUFlLFVBQVUsU0FBUyxPQUFPLEdBQUc7R0FDOUMsSUFBSSxhQUFhLE9BQU87SUFDdEIsY0FBYyxVQUFVO0lBQ3hCLE1BQU0sYUFBYTtJQUNuQjtHQUNGLE9BQU87O0lBRUwsTUFBTSxVQUFVLGlCQUFpQjtJQUNqQyxTQUFTLE9BQU87SUFDaEIsU0FBUyxVQUFVO0dBQ3JCO0VBQ0Y7RUFFQSxnQkFBZ0IsUUFBUTtFQUN4QixnQkFBZ0IsVUFBVTtFQUMxQixVQUFVLGdCQUFnQixVQUFVLFNBQVMsT0FBTyxDQUFDO0VBQ3JELFdBQVcsSUFBSTtFQUNmLGNBQWMsVUFBVTtFQUN4QixzQkFBc0IsVUFBVTtDQUNsQyxHQUFHO0VBQUM7RUFBaUI7RUFBVTtDQUFnQixDQUFDOztDQUdoRCxNQUFNLFlBQVksa0JBQWtCO0VBQ2xDLE1BQU0sUUFBUSxnQkFBZ0I7RUFDOUIsSUFBSSxDQUFDLE9BQU87RUFFWixJQUFJLGVBQWUsU0FBUztHQUMxQixPQUFPLGFBQWEsZUFBZSxPQUFPO0dBQzFDLGVBQWUsVUFBVTtFQUMzQjtFQUVBLE1BQU0sU0FBUyxZQUFZLE1BQU0sS0FBSyxDQUFDLE1BQU07RUFDN0MsTUFBTSxXQUFXLFNBQVMsUUFBUSxLQUFLLFFBQVEsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7RUFHdkQsS0FBSyxNQUFNLFNBQVMsUUFBUTtHQUMxQixNQUFNLElBQUksTUFBTSxTQUFTLElBQUksTUFBTTtHQUNuQyxNQUFNLElBQUksTUFBTSxTQUFTLElBQUksTUFBTTtHQUNuQyxJQUFJLEtBQUssS0FBSyxJQUFJLGNBQWMsS0FBSyxLQUFLLElBQUksYUFBYTtJQUN6RCxTQUFTLEVBQUUsQ0FBQyxLQUFLLE1BQU07R0FDekI7RUFDRjs7RUFHQSxNQUFNLGlCQUEyQixDQUFDO0VBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxZQUFZLEtBQUs7R0FDbkMsSUFBSSxTQUFTLEVBQUUsQ0FBQyxPQUFPLFNBQVMsU0FBUyxJQUFJLEdBQUc7SUFDOUMsZUFBZSxLQUFLLENBQUM7R0FDdkI7RUFDRjtFQUVBLE1BQU0sVUFBVSxzQkFBc0I7RUFFdEMsSUFBSSxlQUFlLFNBQVMsR0FBRzs7R0FFN0IsZ0JBQWdCLGNBQWM7R0FDOUIsTUFBTSxjQUFjLGVBQWUsTUFBTTs7R0FHekMsSUFBSSxlQUFlLFVBQVUsS0FBSyxTQUFTO0lBQ3pDLGNBQWMsSUFBSTtJQUNsQixpQkFBaUIsY0FBYyxLQUFLLEdBQUcsR0FBRztHQUM1QztHQUVBLGlCQUFpQjs7SUFFZixNQUFNLGlCQUFpQixTQUFTLFFBQVEsR0FBRyxRQUFRLENBQUMsZUFBZSxTQUFTLEdBQUcsQ0FBQztJQUNoRixNQUFNLFlBQVksTUFBTSxLQUFLLEVBQUUsUUFBUSxlQUFlLE9BQU8sU0FBUyxNQUFNLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDO0lBQ25HLE1BQU0sYUFBYSxDQUFDLEdBQUcsV0FBVyxHQUFHLGNBQWM7SUFFbkQsU0FBUyxVQUFVO0lBQ25CLFNBQVMsVUFBVTtJQUNuQixnQkFBZ0IsQ0FBQyxDQUFDOztJQUdsQixNQUFNLGFBQWEsZUFBZTtJQUNsQyxNQUFNLGFBQWEsU0FBUyxRQUFRO0lBQ3BDLE1BQU0sZUFBZSxTQUFTLFFBQVEsZUFBZTtJQUNyRCxNQUFNLFFBQVEsU0FBUyxRQUFRO0lBRS9CLElBQUksYUFBYTtJQUNqQixJQUFJLGNBQWM7SUFFbEIsSUFBSSxTQUFTO0tBQ1gsSUFBSSxlQUFlLEdBQUc7TUFDcEIsYUFBYSxPQUFPLGVBQWU7TUFDbkMsY0FBYztLQUNoQixPQUFPLElBQUksZUFBZSxHQUFHO01BQzNCLGFBQWEsT0FBTyxlQUFlO01BQ25DLGNBQWM7S0FDaEIsT0FBTyxJQUFJLGVBQWUsR0FBRztNQUMzQixhQUFhLE9BQU8sZUFBZTtNQUNuQyxjQUFjO0tBQ2hCO0lBQ0YsT0FBTztLQUNMLFFBQVEsWUFBUjtNQUNFLEtBQUs7T0FDSCxhQUFhLE9BQU8sU0FBUztPQUM3QixjQUFjO09BQ2Q7TUFDRixLQUFLO09BQ0gsYUFBYSxPQUFPLFNBQVM7T0FDN0IsY0FBYztPQUNkO01BQ0YsS0FBSztPQUNILGFBQWEsT0FBTyxTQUFTO09BQzdCLGNBQWM7T0FDZDtNQUNGLEtBQUs7T0FDSCxjQUFjLFFBQVEsT0FBTyxhQUFhLE9BQU8sVUFBVTtPQUMzRCxjQUFjLFFBQVEsaUJBQWlCO09BQ3ZDO0tBQ0o7SUFDRjs7SUFHQSxNQUFNLGFBQWEsZUFBZSxJQUFJLEtBQUssZUFBZSxhQUFhO0lBQ3ZFLE1BQU0sY0FBYyxhQUFhO0lBRWpDLElBQUksYUFBYTtLQUNmLFNBQVMsR0FBRyxZQUFZLEdBQUcsZUFBZSxJQUFJLEtBQUssYUFBYSxVQUFVLE1BQU0sV0FBVztJQUM3RjtJQUVBLE1BQU0sZ0JBQWdCLFNBQVMsUUFBUSxRQUFRO0lBQy9DLE1BQU0sV0FBVyxhQUFhLGFBQWEsS0FBSyxNQUFNLGdCQUFnQixFQUFFLElBQUksSUFBSTtJQUVoRixJQUFJLFdBQVcsWUFBWTtLQUN6QixNQUFNLFlBQVk7S0FDbEIsU0FBUyxTQUFTLFNBQVMsSUFBSSxHQUFHLFNBQVM7SUFDN0M7O0lBR0EsSUFBSSxhQUFhLFlBQVksaUJBQWlCLElBQUk7S0FDaEQsY0FBYyxTQUFTO0tBQ3ZCLE1BQU0sWUFBWTtJQUNwQjtJQUVBLFVBQVUsVUFBVTtLQUNsQixHQUFHO0tBQ0gsT0FBTyxLQUFLLFFBQVE7S0FDcEIsT0FBTztLQUNQLE9BQU87S0FDUCxTQUFTLEtBQUssV0FBVyxlQUFlLElBQUksSUFBSTtLQUNoRCxTQUFTLEtBQUssV0FBVyxlQUFlLElBQUksSUFBSTtLQUNoRCxTQUFTLEtBQUssV0FBVyxlQUFlLElBQUksSUFBSTtLQUNoRCxVQUFVLEtBQUssWUFBWSxlQUFlLElBQUksSUFBSTtLQUNsRCxRQUFRLEtBQUssVUFBVSxVQUFVLElBQUk7S0FDckM7S0FDQSxVQUFVLEtBQUssSUFBSSxLQUFLLFVBQVUsWUFBWTtLQUM5QyxZQUFZLGVBQWUsS0FBSztLQUNoQyxnQkFBZ0IsYUFBYSxXQUFXLEtBQUssSUFBSSxHQUFHLEtBQUssYUFBYSxJQUFJO0lBQzVFLEVBQUU7SUFFRixXQUFXO0dBQ2IsR0FBRyxHQUFHO0VBQ1IsT0FBTzs7R0FFTCxTQUFTLFFBQVE7R0FDakIsU0FBUyxVQUFVO0dBRW5CLFVBQVUsVUFBVTtJQUNsQixHQUFHO0lBQ0gsY0FBYyxDQUFDO0lBQ2YsWUFBWSxVQUFVLEtBQUssYUFBYSxLQUFLO0dBQy9DLEVBQUU7R0FFRixXQUFXO0VBQ2I7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFVO0NBQVUsQ0FBQzs7Q0FHbkMsTUFBTSxpQkFBaUIsYUFBYSxjQUErQjtFQUNqRSxJQUFJLGNBQWMsWUFBWSxhQUFhLENBQUMsZ0JBQWdCLFNBQVMsT0FBTztFQUU1RSxNQUFNLFFBQVEsZ0JBQWdCO0VBQzlCLElBQUksQ0FBQyxlQUFlLE9BQU8sU0FBUyxTQUFTO0dBQUUsR0FBRztHQUFXLEdBQUc7RUFBRSxDQUFDLEdBQUc7R0FDcEUsTUFBTSxhQUFvQjtJQUN4QixHQUFHO0lBQ0gsVUFBVTtLQUFFLEdBQUcsTUFBTSxTQUFTLElBQUk7S0FBVyxHQUFHLE1BQU0sU0FBUztJQUFFO0dBQ25FO0dBQ0EsZ0JBQWdCLFVBQVU7R0FDMUIsZ0JBQWdCLFVBQVU7R0FDMUIsVUFBVSxnQkFBZ0IsWUFBWSxTQUFTLE9BQU8sQ0FBQztHQUN2RCxNQUFNLFNBQVM7O0dBR2YsSUFBSSxlQUFlLFlBQVksU0FBUyxTQUFTO0lBQUUsR0FBRztJQUFHLEdBQUc7R0FBRSxDQUFDLEdBQUc7SUFDaEUsSUFBSSxjQUFjLFVBQVUsaUJBQWlCO0tBQzNDLGNBQWM7S0FDZCxJQUFJLGVBQWUsU0FBUztNQUMxQixPQUFPLGFBQWEsZUFBZSxPQUFPO01BQzFDLGVBQWUsVUFBVTtLQUMzQjtJQUNGO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxPQUFPO0NBQ1QsR0FBRyxDQUFDLGVBQWUsQ0FBQzs7Q0FHcEIsTUFBTSxXQUFXLGtCQUFrQjtFQUNqQyxJQUFJLGNBQWMsWUFBWSxhQUFhLENBQUMsZ0JBQWdCLFNBQVM7RUFFckUsTUFBTSxRQUFRLGdCQUFnQjtFQUM5QixJQUFJLENBQUMsZUFBZSxPQUFPLFNBQVMsU0FBUztHQUFFLEdBQUc7R0FBRyxHQUFHO0VBQUUsQ0FBQyxHQUFHO0dBQzVELE1BQU0sZUFBc0I7SUFDMUIsR0FBRztJQUNILFVBQVU7S0FBRSxHQUFHLE1BQU0sU0FBUztLQUFHLEdBQUcsTUFBTSxTQUFTLElBQUk7SUFBRTtHQUMzRDtHQUNBLGdCQUFnQixZQUFZO0dBQzVCLGdCQUFnQixVQUFVO0dBQzFCLE1BQU0sYUFBYTtHQUNuQixVQUFVLFVBQVU7SUFBRSxHQUFHO0lBQU0sT0FBTyxLQUFLLFFBQVEsT0FBTztHQUFVLEVBQUU7RUFDeEU7Q0FDRixHQUFHLENBQUMsQ0FBQzs7Q0FHTCxNQUFNLFdBQVcsa0JBQWtCO0VBQ2pDLElBQUksY0FBYyxZQUFZLGFBQWEsQ0FBQyxnQkFBZ0IsU0FBUztFQUVyRSxNQUFNLFFBQVEsZ0JBQWdCO0VBQzlCLElBQUksZUFBZTtFQUNuQixPQUFPLENBQUMsZUFBZSxPQUFPLFNBQVMsU0FBUztHQUFFLEdBQUc7R0FBRyxHQUFHLGVBQWU7RUFBRSxDQUFDLEdBQUc7R0FDOUU7RUFDRjtFQUVBLE1BQU0sZUFBc0I7R0FDMUIsR0FBRztHQUNILFVBQVU7SUFBRSxHQUFHLE1BQU0sU0FBUztJQUFHLEdBQUcsTUFBTSxTQUFTLElBQUk7R0FBYTtFQUN0RTtFQUVBLGdCQUFnQixZQUFZO0VBQzVCLGdCQUFnQixVQUFVO0VBQzFCLE1BQU0sYUFBYTs7RUFHbkIsY0FBYyxJQUFJO0VBQ2xCLGlCQUFpQixjQUFjLEtBQUssR0FBRyxHQUFHO0VBRTFDLFVBQVUsVUFBVTtHQUNsQixHQUFHO0dBQ0gsT0FBTyxLQUFLLFFBQVEsZUFBZSxPQUFPO0VBQzVDLEVBQUU7RUFFRixVQUFVO0NBQ1osR0FBRyxDQUFDLFNBQVMsQ0FBQzs7Q0FHZCxNQUFNLFNBQVMsYUFBYSxZQUFxQixTQUFTO0VBQ3hELElBQUksY0FBYyxZQUFZLGFBQWEsQ0FBQyxnQkFBZ0IsU0FBUztFQUVyRSxNQUFNLFFBQVEsZ0JBQWdCO0VBQzlCLElBQUksTUFBTSxTQUFTLEtBQUs7RUFFeEIsTUFBTSxhQUFhLE1BQU07RUFDekIsTUFBTSxVQUFXLGFBQWEsYUFBYSxLQUFLLEtBQUssYUFBYSxLQUFLO0VBQ3ZFLE1BQU0sVUFBVSxHQUFHLFdBQVcsSUFBSTtFQUNsQyxNQUFNLFFBQVEsTUFBTSxTQUFTLE1BQU0sYUFBYSxXQUFXLGlCQUFpQjtFQUU1RSxJQUFJLENBQUMsT0FBTztFQUVaLEtBQUssTUFBTSxRQUFRLE9BQU87R0FDeEIsTUFBTSxZQUFtQjtJQUN2QixHQUFHO0lBQ0gsVUFBVTtJQUNWLFVBQVU7S0FDUixHQUFHLE1BQU0sU0FBUyxJQUFJLEtBQUs7S0FDM0IsR0FBRyxNQUFNLFNBQVMsSUFBSSxLQUFLO0lBQzdCO0dBQ0Y7R0FFQSxJQUFJLENBQUMsZUFBZSxXQUFXLFNBQVMsT0FBTyxHQUFHOztJQUVoRCxJQUFJLE1BQU0sU0FBUyxLQUFLO0tBQ3RCLE1BQU0sS0FBSyxVQUFVLFNBQVMsSUFBSTtLQUNsQyxNQUFNLEtBQUssVUFBVSxTQUFTLElBQUk7S0FDbEMsTUFBTSxVQUFVO01BQ2Q7T0FBRSxHQUFHLEtBQUs7T0FBRyxHQUFHLEtBQUs7TUFBRTtNQUN2QjtPQUFFLEdBQUcsS0FBSztPQUFHLEdBQUcsS0FBSztNQUFFO01BQ3ZCO09BQUUsR0FBRyxLQUFLO09BQUcsR0FBRyxLQUFLO01BQUU7TUFDdkI7T0FBRSxHQUFHLEtBQUs7T0FBRyxHQUFHLEtBQUs7TUFBRTtLQUN6QjtLQUNBLElBQUksa0JBQWtCO0tBQ3RCLEtBQUssTUFBTSxLQUFLLFNBQVM7TUFDdkIsSUFBSSxFQUFFLElBQUksS0FBSyxFQUFFLEtBQUssZUFBZSxFQUFFLEtBQUssY0FBZSxFQUFFLEtBQUssS0FBSyxTQUFTLFFBQVEsRUFBRSxFQUFFLENBQUMsRUFBRSxPQUFPLE1BQU87T0FDM0c7TUFDRjtLQUNGO0tBQ0Esc0JBQXNCLFVBQVUsbUJBQW1CO0lBQ3JELE9BQU87S0FDTCxzQkFBc0IsVUFBVTtJQUNsQztJQUVBLGdCQUFnQixTQUFTO0lBQ3pCLGdCQUFnQixVQUFVO0lBQzFCLFVBQVUsZ0JBQWdCLFdBQVcsU0FBUyxPQUFPLENBQUM7SUFDdEQsTUFBTSxXQUFXOztJQUdqQixJQUFJLGNBQWMsVUFBVSxpQkFBaUI7S0FDM0MsY0FBYztLQUNkLElBQUksZUFBZSxTQUFTO01BQzFCLE9BQU8sYUFBYSxlQUFlLE9BQU87TUFDMUMsZUFBZSxVQUFVO0tBQzNCO0lBQ0Y7SUFDQTtHQUNGO0VBQ0Y7Q0FDRixHQUFHLENBQUMsZUFBZSxDQUFDOztDQUdwQixNQUFNLE9BQU8sa0JBQWtCO0VBQzdCLElBQUksY0FBYyxZQUFZLGFBQWEsQ0FBQyxnQkFBZ0IsV0FBVyxDQUFDLFNBQVM7RUFFakYsTUFBTSxTQUFTO0VBQ2YsTUFBTSxjQUFjLGdCQUFnQixRQUFRO0VBRTVDLElBQUksY0FBYyxNQUFNO0dBQ3RCLGFBQWEsV0FBVztHQUN4QixXQUFXO0VBQ2IsT0FBTztHQUNMLE1BQU0sV0FBVztHQUNqQixhQUFhLFdBQVc7R0FDeEIsV0FBVyxRQUFRO0VBQ3JCO0VBQ0EsV0FBVyxLQUFLO0NBQ2xCLEdBQUc7RUFBQztFQUFTO0VBQVc7Q0FBVSxDQUFDOztDQUduQyxNQUFNLFlBQVksYUFBYSxPQUFpQixhQUFhO0VBQzNELE1BQU0sUUFBUSxpQkFBaUI7RUFDL0IsU0FBUyxLQUFLO0VBQ2QsU0FBUyxVQUFVO0VBRW5CLE9BQU8sVUFBVSxZQUFZO0VBQzdCLE1BQU0sZUFBZSxDQUFDLEdBQUcsT0FBTyxTQUFTLEdBQUcsWUFBWSxDQUFDO0VBQ3pELE9BQU8sVUFBVSxhQUFhLE1BQU0sQ0FBQztFQUNyQyxhQUFhLE9BQU8sUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBRXZDLGFBQWEsSUFBSTtFQUNqQixXQUFXLElBQUk7RUFDZixnQkFBZ0IsQ0FBQyxDQUFDO0VBQ2xCLFVBQVUsQ0FBQyxDQUFDO0VBQ1osY0FBYyxVQUFVO0VBQ3hCLHNCQUFzQixVQUFVO0VBRWhDLFNBQVM7R0FDUCxPQUFPO0dBQ1AsT0FBTztHQUNQLE9BQU87R0FDUCxTQUFTO0dBQ1QsU0FBUztHQUNULFNBQVM7R0FDVCxVQUFVO0dBQ1YsUUFBUTtHQUNSLFVBQVU7R0FDVixjQUFjLENBQUM7R0FDZixZQUFZO0dBQ1osV0FBVyxLQUFLLElBQUk7R0FDcEIsYUFBYTtHQUNiLGdCQUFnQixTQUFTLFdBQVcsS0FBSztHQUN6QyxlQUFlLFNBQVMsVUFBVSxNQUFNO0VBQzFDLENBQUM7RUFFRCxNQUFNLGlCQUFpQixhQUFhO0VBQ3BDLE1BQU0sV0FBa0I7R0FDdEIsTUFBTTtHQUNOLFVBQVU7R0FDVixVQUFVLEVBQUUsR0FBRyxnQkFBZ0IsZ0JBQWdCO0VBQ2pEO0VBRUEsZ0JBQWdCLFFBQVE7RUFDeEIsZ0JBQWdCLFVBQVU7RUFDMUIsVUFBVSxnQkFBZ0IsVUFBVSxLQUFLLENBQUM7RUFDMUMsY0FBYyxTQUFTO0NBQ3pCLEdBQUcsQ0FBQyxpQkFBaUIsUUFBUSxDQUFDOztDQUc5QixNQUFNLGNBQWMsa0JBQWtCO0VBQ3BDLGVBQWUsU0FBUztHQUN0QixJQUFJLFNBQVMsV0FBVyxPQUFPO0dBQy9CLElBQUksU0FBUyxVQUFVLE9BQU87R0FDOUIsT0FBTztFQUNULENBQUM7Q0FDSCxHQUFHLENBQUMsQ0FBQzs7Q0FHTCxnQkFBZ0I7RUFDZCxJQUFJLGVBQWUsV0FBVztHQUM1QixJQUFJLGFBQWEsU0FBUztJQUN4QixPQUFPLGFBQWEsYUFBYSxPQUFPO0lBQ3hDLGFBQWEsVUFBVTtHQUN6QjtHQUNBO0VBQ0Y7RUFFQSxNQUFNLGFBQWEsTUFBTTtFQUN6QixNQUFNLFFBQVEsYUFBYSxRQUFRLFdBQVcsYUFBYSxLQUFLLElBQUksYUFBYSxHQUFHLGFBQWEsU0FBUyxDQUFDO0VBRTNHLE1BQU0sYUFBYTtHQUNqQixJQUFJLGNBQWMsWUFBWSxXQUFXO0dBRXpDLE1BQU0sUUFBUSxnQkFBZ0I7R0FDOUIsSUFBSSxDQUFDLE9BQU87R0FFWixJQUFJLENBQUMsZUFBZSxPQUFPLFNBQVMsU0FBUztJQUFFLEdBQUc7SUFBRyxHQUFHO0dBQUUsQ0FBQyxHQUFHOztJQUU1RCxNQUFNLGVBQXNCO0tBQzFCLEdBQUc7S0FDSCxVQUFVO01BQUUsR0FBRyxNQUFNLFNBQVM7TUFBRyxHQUFHLE1BQU0sU0FBUyxJQUFJO0tBQUU7SUFDM0Q7SUFDQSxnQkFBZ0IsWUFBWTtJQUM1QixnQkFBZ0IsVUFBVTtHQUM1QixPQUFPOztJQUVMLElBQUksQ0FBQyxlQUFlLFNBQVM7S0FDM0IsZUFBZSxVQUFVLE9BQU8saUJBQWlCO01BQy9DLFVBQVU7S0FDWixHQUFHLGFBQWE7SUFDbEI7R0FDRjtHQUVBLGFBQWEsVUFBVSxPQUFPLFdBQVcsTUFBTSxLQUFLO0VBQ3REO0VBRUEsYUFBYSxVQUFVLE9BQU8sV0FBVyxNQUFNLEtBQUs7RUFFcEQsYUFBYTtHQUNYLElBQUksYUFBYSxTQUFTO0lBQ3hCLE9BQU8sYUFBYSxhQUFhLE9BQU87SUFDeEMsYUFBYSxVQUFVO0dBQ3pCO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBWSxNQUFNO0VBQU87RUFBVTtFQUFVO0NBQVMsQ0FBQzs7Q0FHM0QsZ0JBQWdCO0VBQ2QsSUFBSSxlQUFlLFdBQVc7R0FDNUIsSUFBSSxjQUFjLFNBQVM7SUFDekIsT0FBTyxjQUFjLGNBQWMsT0FBTztJQUMxQyxjQUFjLFVBQVU7R0FDMUI7R0FDQTtFQUNGO0VBRUEsY0FBYyxVQUFVLE9BQU8sa0JBQWtCO0dBQy9DLFVBQVUsU0FBUztJQUNqQixNQUFNLGNBQWMsS0FBSyxZQUFZLElBQUksS0FBSyxJQUFJLElBQUksS0FBSyxZQUFZO0lBRXZFLElBQUksYUFBYSxTQUFTO0tBQ3hCLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxNQUFNLGNBQWMsR0FBSSxDQUFDO0tBQ3RFLElBQUksaUJBQWlCLEdBQUc7TUFDdEIsY0FBYyxTQUFTO01BQ3ZCLE1BQU0sWUFBWTtNQUNsQixPQUFPO09BQUUsR0FBRztPQUFNLGFBQWE7T0FBYSxlQUFlO01BQUU7S0FDL0Q7S0FDQSxPQUFPO01BQUUsR0FBRztNQUFNLGFBQWE7TUFBYSxlQUFlO0tBQWM7SUFDM0U7SUFFQSxPQUFPO0tBQUUsR0FBRztLQUFNLGFBQWE7SUFBWTtHQUM3QyxDQUFDO0VBQ0gsR0FBRyxHQUFHO0VBRU4sYUFBYTtHQUNYLElBQUksY0FBYyxTQUFTO0lBQ3pCLE9BQU8sY0FBYyxjQUFjLE9BQU87SUFDMUMsY0FBYyxVQUFVO0dBQzFCO0VBQ0Y7Q0FDRixHQUFHLENBQUMsWUFBWSxRQUFRLENBQUM7O0NBR3pCLGdCQUFnQjtFQUNkLElBQUksZUFBZSxjQUFjLGVBQWUsV0FBVztHQUN6RCxJQUFJLE1BQU0sUUFBUSxHQUFHO0lBQ25CLE1BQU0sUUFBd0I7S0FDNUIsSUFBSSxHQUFHLEtBQUssSUFBSTtLQUNoQixNQUFNO0tBQ04sT0FBTyxNQUFNO0tBQ2IsT0FBTyxNQUFNO0tBQ2IsT0FBTyxNQUFNO0tBQ2IsUUFBUSxNQUFNO0tBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixXQUFXO01BQUUsT0FBTztNQUFTLEtBQUs7TUFBVyxNQUFNO0tBQVUsQ0FBQztJQUNwRztJQUNBLGVBQWUsU0FBUztLQUN0QixNQUFNLFVBQVUsQ0FBQyxHQUFHLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLEVBQUU7S0FDOUUsSUFBSTtNQUNGLGFBQWEsUUFBUSxzQkFBc0IsS0FBSyxVQUFVLE9BQU8sQ0FBQztLQUNwRSxRQUFRLENBRVI7S0FDQSxPQUFPO0lBQ1QsQ0FBQztHQUNIO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBWTtFQUFVLE1BQU07RUFBTyxNQUFNO0VBQU8sTUFBTTtFQUFPLE1BQU07Q0FBVyxDQUFDO0NBRW5GLE9BQU87RUFDTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZVRldHJpcy50cyJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgVGV0cm9taW5vVHlwZSxcbiAgUm90YXRpb25TdGF0ZSxcbiAgUG9zaXRpb24sXG4gIFBpZWNlLFxuICBCb2FyZCxcbiAgR2FtZU1vZGUsXG4gIEdhbWVTdGF0dXMsXG4gIEdhbWVTdGF0cyxcbiAgQWN0aW9uUG9wdXAsXG4gIEhpZ2hTY29yZUVudHJ5LFxufSBmcm9tICcuLi90eXBlcy90ZXRyaXMnO1xuaW1wb3J0IHtcbiAgQk9BUkRfV0lEVEgsXG4gIEJPQVJEX0hFSUdIVCxcbiAgQlVGRkVSX1JPV1MsXG4gIFRPVEFMX1JPV1MsXG4gIFRFVFJPTUlOT0VTLFxuICBTUEFXTl9QT1NJVElPTlMsXG4gIEpMU1RaX1dBTExfS0lDS1MsXG4gIElfV0FMTF9LSUNLUyxcbiAgTEVWRUxfU1BFRURTLFxuICBMT0NLX0RFTEFZX01TLFxuICBNQVhfTE9DS19SRVNFVFMsXG4gIFNDT1JFUyxcbn0gZnJvbSAnLi4vdXRpbHMvdGV0cmlzQ29uc3RhbnRzJztcbmltcG9ydCB7IHNvdW5kIH0gZnJvbSAnLi4vdXRpbHMvc291bmRFZmZlY3RzJztcblxuY29uc3QgQUxMX1BJRUNFUzogVGV0cm9taW5vVHlwZVtdID0gWydJJywgJ0onLCAnTCcsICdPJywgJ1MnLCAnVCcsICdaJ107XG5cbi8vIEZpc2hlci1ZYXRlcyBzaHVmZmxlIGZvciA3LWJhZyByYW5kb21pemVyXG5mdW5jdGlvbiBnZW5lcmF0ZUJhZygpOiBUZXRyb21pbm9UeXBlW10ge1xuICBjb25zdCBiYWcgPSBbLi4uQUxMX1BJRUNFU107XG4gIGZvciAobGV0IGkgPSBiYWcubGVuZ3RoIC0gMTsgaSA+IDA7IGktLSkge1xuICAgIGNvbnN0IGogPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAoaSArIDEpKTtcbiAgICBbYmFnW2ldLCBiYWdbal1dID0gW2JhZ1tqXSwgYmFnW2ldXTtcbiAgfVxuICByZXR1cm4gYmFnO1xufVxuXG5mdW5jdGlvbiBjcmVhdGVFbXB0eUJvYXJkKCk6IEJvYXJkIHtcbiAgcmV0dXJuIEFycmF5LmZyb20oeyBsZW5ndGg6IFRPVEFMX1JPV1MgfSwgKCkgPT4gQXJyYXkoQk9BUkRfV0lEVEgpLmZpbGwobnVsbCkpO1xufVxuXG4vLyBDaGVja3MgaWYgcGllY2UgY29sbGlkZXMgd2l0aCB3YWxscyBvciBsb2NrZWQgYmxvY2tzXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tDb2xsaXNpb24ocGllY2U6IFBpZWNlLCBib2FyZDogQm9hcmQsIG9mZnNldDogUG9zaXRpb24gPSB7IHg6IDAsIHk6IDAgfSk6IGJvb2xlYW4ge1xuICBjb25zdCBjb29yZHMgPSBURVRST01JTk9FU1twaWVjZS50eXBlXVtwaWVjZS5yb3RhdGlvbl07XG4gIGZvciAoY29uc3QgY29vcmQgb2YgY29vcmRzKSB7XG4gICAgY29uc3QgdGFyZ2V0WCA9IHBpZWNlLnBvc2l0aW9uLnggKyBjb29yZC54ICsgb2Zmc2V0Lng7XG4gICAgY29uc3QgdGFyZ2V0WSA9IHBpZWNlLnBvc2l0aW9uLnkgKyBjb29yZC55ICsgb2Zmc2V0Lnk7XG5cbiAgICBpZiAodGFyZ2V0WCA8IDAgfHwgdGFyZ2V0WCA+PSBCT0FSRF9XSURUSCkgcmV0dXJuIHRydWU7XG4gICAgaWYgKHRhcmdldFkgPj0gVE9UQUxfUk9XUykgcmV0dXJuIHRydWU7XG4gICAgaWYgKHRhcmdldFkgPj0gMCAmJiBib2FyZFt0YXJnZXRZXVt0YXJnZXRYXSAhPT0gbnVsbCkgcmV0dXJuIHRydWU7XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVGV0cmlzKGdhbWVNb2RlOiBHYW1lTW9kZSA9ICdtYXJhdGhvbicpIHtcbiAgY29uc3QgW2JvYXJkLCBzZXRCb2FyZF0gPSB1c2VTdGF0ZTxCb2FyZD4oY3JlYXRlRW1wdHlCb2FyZCk7XG4gIGNvbnN0IFtjdXJyZW50UGllY2UsIHNldEN1cnJlbnRQaWVjZV0gPSB1c2VTdGF0ZTxQaWVjZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbZ2hvc3RZLCBzZXRHaG9zdFldID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcbiAgY29uc3QgW25leHRRdWV1ZSwgc2V0TmV4dFF1ZXVlXSA9IHVzZVN0YXRlPFRldHJvbWlub1R5cGVbXT4oW10pO1xuICBjb25zdCBbaG9sZFBpZWNlLCBzZXRIb2xkUGllY2VdID0gdXNlU3RhdGU8VGV0cm9taW5vVHlwZSB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY2FuSG9sZCwgc2V0Q2FuSG9sZF0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW2dhbWVTdGF0dXMsIHNldEdhbWVTdGF0dXNdID0gdXNlU3RhdGU8R2FtZVN0YXR1cz4oJ2lkbGUnKTtcbiAgY29uc3QgW2NsZWFyaW5nUm93cywgc2V0Q2xlYXJpbmdSb3dzXSA9IHVzZVN0YXRlPG51bWJlcltdPihbXSk7XG4gIGNvbnN0IFtwb3B1cHMsIHNldFBvcHVwc10gPSB1c2VTdGF0ZTxBY3Rpb25Qb3B1cFtdPihbXSk7XG4gIGNvbnN0IFtib2FyZFNoYWtlLCBzZXRCb2FyZFNoYWtlXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3plblNwZWVkLCBzZXRaZW5TcGVlZF0gPSB1c2VTdGF0ZTxudW1iZXI+KDUwMCk7XG5cbiAgY29uc3QgW3N0YXRzLCBzZXRTdGF0c10gPSB1c2VTdGF0ZTxHYW1lU3RhdHM+KHtcbiAgICBzY29yZTogMCxcbiAgICBsaW5lczogMCxcbiAgICBsZXZlbDogMSxcbiAgICBzaW5nbGVzOiAwLFxuICAgIGRvdWJsZXM6IDAsXG4gICAgdHJpcGxlczogMCxcbiAgICB0ZXRyaXNlczogMCxcbiAgICB0c3BpbnM6IDAsXG4gICAgbWF4Q29tYm86IDAsXG4gICAgY3VycmVudENvbWJvOiAtMSxcbiAgICBiYWNrVG9CYWNrOiBmYWxzZSxcbiAgICBzdGFydFRpbWU6IDAsXG4gICAgZWxhcHNlZFRpbWU6IDAsXG4gICAgcmVtYWluaW5nTGluZXM6IGdhbWVNb2RlID09PSAnc3ByaW50JyA/IDQwIDogdW5kZWZpbmVkLFxuICAgIHJlbWFpbmluZ1RpbWU6IGdhbWVNb2RlID09PSAndWx0cmEnID8gMTIwIDogdW5kZWZpbmVkLFxuICB9KTtcblxuICBjb25zdCBbaGlnaFNjb3Jlcywgc2V0SGlnaFNjb3Jlc10gPSB1c2VTdGF0ZTxIaWdoU2NvcmVFbnRyeVtdPigoKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHNhdmVkID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3RldHJpc19oaWdoX3Njb3JlcycpO1xuICAgICAgcmV0dXJuIHNhdmVkID8gSlNPTi5wYXJzZShzYXZlZCkgOiBbXTtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEludGVybmFsIHJlZnMgdG8gcHJldmVudCBzdGFsZSBzdGF0ZSBpbiByZXF1ZXN0QW5pbWF0aW9uRnJhbWUgYW5kIGludGVydmFsIGxvb3BzXG4gIGNvbnN0IGJhZ1JlZiA9IHVzZVJlZjxUZXRyb21pbm9UeXBlW10+KFtdKTtcbiAgY29uc3QgYm9hcmRSZWYgPSB1c2VSZWY8Qm9hcmQ+KGJvYXJkKTtcbiAgYm9hcmRSZWYuY3VycmVudCA9IGJvYXJkO1xuICBjb25zdCBjdXJyZW50UGllY2VSZWYgPSB1c2VSZWY8UGllY2UgfCBudWxsPihjdXJyZW50UGllY2UpO1xuICBjdXJyZW50UGllY2VSZWYuY3VycmVudCA9IGN1cnJlbnRQaWVjZTtcbiAgY29uc3QgZ2FtZVN0YXR1c1JlZiA9IHVzZVJlZjxHYW1lU3RhdHVzPihnYW1lU3RhdHVzKTtcbiAgZ2FtZVN0YXR1c1JlZi5jdXJyZW50ID0gZ2FtZVN0YXR1cztcbiAgY29uc3Qgc3RhdHNSZWYgPSB1c2VSZWY8R2FtZVN0YXRzPihzdGF0cyk7XG4gIHN0YXRzUmVmLmN1cnJlbnQgPSBzdGF0cztcblxuICBjb25zdCBsb2NrVGltZW91dFJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgbG9ja1Jlc2V0c1JlZiA9IHVzZVJlZjxudW1iZXI+KDApO1xuICBjb25zdCBkcm9wVGltZXJSZWYgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IHVsdHJhVGltZXJSZWYgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG4gIGNvbnN0IGxhc3RSb3RhdGVXYXNUU3BpblJlZiA9IHVzZVJlZjxib29sZWFuPihmYWxzZSk7XG5cbiAgLy8gVHJpZ2dlciBmbG9hdGluZyBwb3B1cCBub3RpZmljYXRpb24gKGUuZy4gXCIrODAwIFRFVFJJUyFcIilcbiAgY29uc3QgYWRkUG9wdXAgPSB1c2VDYWxsYmFjaygodGV4dDogc3RyaW5nLCBwb2ludHM6IG51bWJlciwgY29sb3I/OiBzdHJpbmcpID0+IHtcbiAgICBjb25zdCBwb3B1cDogQWN0aW9uUG9wdXAgPSB7XG4gICAgICBpZDogYCR7RGF0ZS5ub3coKX0tJHtNYXRoLnJhbmRvbSgpfWAsXG4gICAgICB0ZXh0LFxuICAgICAgcG9pbnRzLFxuICAgICAgY29sb3IsXG4gICAgICB0aW1lOiBEYXRlLm5vdygpLFxuICAgIH07XG4gICAgc2V0UG9wdXBzKChwcmV2KSA9PiBbLi4ucHJldi5zbGljZSgtMyksIHBvcHVwXSk7XG4gIH0sIFtdKTtcblxuICAvLyBDb21wdXRlIGdob3N0IHBpZWNlIHBvc2l0aW9uXG4gIGNvbnN0IGNhbGN1bGF0ZUdob3N0WSA9IHVzZUNhbGxiYWNrKChwaWVjZTogUGllY2UsIGI6IEJvYXJkKTogbnVtYmVyID0+IHtcbiAgICBsZXQgb2Zmc2V0ID0gMDtcbiAgICB3aGlsZSAoIWNoZWNrQ29sbGlzaW9uKHBpZWNlLCBiLCB7IHg6IDAsIHk6IG9mZnNldCArIDEgfSkpIHtcbiAgICAgIG9mZnNldCsrO1xuICAgIH1cbiAgICByZXR1cm4gcGllY2UucG9zaXRpb24ueSArIG9mZnNldDtcbiAgfSwgW10pO1xuXG4gIC8vIEhlbHBlciB0byBwdWxsIG5leHQgcGllY2UgZnJvbSBxdWV1ZSBhbmQgcmVwbGVuaXNoIDctYmFnXG4gIGNvbnN0IGdldE5leHRQaWVjZVR5cGUgPSB1c2VDYWxsYmFjaygoKTogVGV0cm9taW5vVHlwZSA9PiB7XG4gICAgbGV0IGN1cnJlbnRCYWcgPSBiYWdSZWYuY3VycmVudDtcbiAgICBpZiAoY3VycmVudEJhZy5sZW5ndGggPCA3KSB7XG4gICAgICBjdXJyZW50QmFnID0gWy4uLmN1cnJlbnRCYWcsIC4uLmdlbmVyYXRlQmFnKCldO1xuICAgICAgYmFnUmVmLmN1cnJlbnQgPSBjdXJyZW50QmFnO1xuICAgIH1cblxuICAgIGNvbnN0IG5leHRUeXBlID0gY3VycmVudEJhZ1swXTtcbiAgICBjb25zdCB1cGRhdGVkQmFnID0gY3VycmVudEJhZy5zbGljZSgxKTtcbiAgICBiYWdSZWYuY3VycmVudCA9IHVwZGF0ZWRCYWc7XG4gICAgc2V0TmV4dFF1ZXVlKHVwZGF0ZWRCYWcuc2xpY2UoMCwgNSkpO1xuICAgIHJldHVybiBuZXh0VHlwZTtcbiAgfSwgW10pO1xuXG4gIC8vIFNwYXduIGEgbmV3IHBpZWNlXG4gIGNvbnN0IHNwYXduUGllY2UgPSB1c2VDYWxsYmFjaygodHlwZVRvU3Bhd24/OiBUZXRyb21pbm9UeXBlKSA9PiB7XG4gICAgY29uc3QgdHlwZSA9IHR5cGVUb1NwYXduIHx8IGdldE5leHRQaWVjZVR5cGUoKTtcbiAgICBjb25zdCBuZXdQaWVjZTogUGllY2UgPSB7XG4gICAgICB0eXBlLFxuICAgICAgcm90YXRpb246IDAsXG4gICAgICBwb3NpdGlvbjogeyAuLi5TUEFXTl9QT1NJVElPTlNbdHlwZV0gfSxcbiAgICB9O1xuXG4gICAgLy8gQ2hlY2sgZ2FtZSBvdmVyIChzcGF3bmluZyBwaWVjZSBpbW1lZGlhdGVseSBjb2xsaWRlcylcbiAgICBpZiAoY2hlY2tDb2xsaXNpb24obmV3UGllY2UsIGJvYXJkUmVmLmN1cnJlbnQpKSB7XG4gICAgICBpZiAoZ2FtZU1vZGUgIT09ICd6ZW4nKSB7XG4gICAgICAgIHNldEdhbWVTdGF0dXMoJ2dhbWVvdmVyJyk7XG4gICAgICAgIHNvdW5kLnBsYXlHYW1lT3ZlcigpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBJbiBaZW4gbW9kZSwgY2xlYXIgdG9wIHJvd3MgdG8ga2VlcCBwcmFjdGljaW5nXG4gICAgICAgIGNvbnN0IGNsZWFyZWQgPSBjcmVhdGVFbXB0eUJvYXJkKCk7XG4gICAgICAgIHNldEJvYXJkKGNsZWFyZWQpO1xuICAgICAgICBib2FyZFJlZi5jdXJyZW50ID0gY2xlYXJlZDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBzZXRDdXJyZW50UGllY2UobmV3UGllY2UpO1xuICAgIGN1cnJlbnRQaWVjZVJlZi5jdXJyZW50ID0gbmV3UGllY2U7XG4gICAgc2V0R2hvc3RZKGNhbGN1bGF0ZUdob3N0WShuZXdQaWVjZSwgYm9hcmRSZWYuY3VycmVudCkpO1xuICAgIHNldENhbkhvbGQodHJ1ZSk7XG4gICAgbG9ja1Jlc2V0c1JlZi5jdXJyZW50ID0gMDtcbiAgICBsYXN0Um90YXRlV2FzVFNwaW5SZWYuY3VycmVudCA9IGZhbHNlO1xuICB9LCBbY2FsY3VsYXRlR2hvc3RZLCBnYW1lTW9kZSwgZ2V0TmV4dFBpZWNlVHlwZV0pO1xuXG4gIC8vIExvY2sgdGhlIGN1cnJlbnQgcGllY2UgaW50byB0aGUgYm9hcmQgYW5kIGNoZWNrIGxpbmUgY2xlYXJzXG4gIGNvbnN0IGxvY2tQaWVjZSA9IHVzZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBwaWVjZSA9IGN1cnJlbnRQaWVjZVJlZi5jdXJyZW50O1xuICAgIGlmICghcGllY2UpIHJldHVybjtcblxuICAgIGlmIChsb2NrVGltZW91dFJlZi5jdXJyZW50KSB7XG4gICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KGxvY2tUaW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgbG9ja1RpbWVvdXRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuXG4gICAgY29uc3QgY29vcmRzID0gVEVUUk9NSU5PRVNbcGllY2UudHlwZV1bcGllY2Uucm90YXRpb25dO1xuICAgIGNvbnN0IG5ld0JvYXJkID0gYm9hcmRSZWYuY3VycmVudC5tYXAoKHJvdykgPT4gWy4uLnJvd10pO1xuXG4gICAgLy8gU3RhbXAgcGllY2UgaW50byBib2FyZFxuICAgIGZvciAoY29uc3QgY29vcmQgb2YgY29vcmRzKSB7XG4gICAgICBjb25zdCB4ID0gcGllY2UucG9zaXRpb24ueCArIGNvb3JkLng7XG4gICAgICBjb25zdCB5ID0gcGllY2UucG9zaXRpb24ueSArIGNvb3JkLnk7XG4gICAgICBpZiAoeSA+PSAwICYmIHkgPCBUT1RBTF9ST1dTICYmIHggPj0gMCAmJiB4IDwgQk9BUkRfV0lEVEgpIHtcbiAgICAgICAgbmV3Qm9hcmRbeV1beF0gPSBwaWVjZS50eXBlO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElkZW50aWZ5IGNvbXBsZXRlIGxpbmVzIChpZ25vcmluZyBidWZmZXIgcm93cylcbiAgICBjb25zdCBmdWxsUm93SW5kaWNlczogbnVtYmVyW10gPSBbXTtcbiAgICBmb3IgKGxldCByID0gMDsgciA8IFRPVEFMX1JPV1M7IHIrKykge1xuICAgICAgaWYgKG5ld0JvYXJkW3JdLmV2ZXJ5KChjZWxsKSA9PiBjZWxsICE9PSBudWxsKSkge1xuICAgICAgICBmdWxsUm93SW5kaWNlcy5wdXNoKHIpO1xuICAgICAgfVxuICAgIH1cblxuICAgIGNvbnN0IGlzVFNwaW4gPSBsYXN0Um90YXRlV2FzVFNwaW5SZWYuY3VycmVudDtcblxuICAgIGlmIChmdWxsUm93SW5kaWNlcy5sZW5ndGggPiAwKSB7XG4gICAgICAvLyBUcmlnZ2VyIGxpbmUgY2xlYXIgdmlzdWFsIGZsYXNoXG4gICAgICBzZXRDbGVhcmluZ1Jvd3MoZnVsbFJvd0luZGljZXMpO1xuICAgICAgc291bmQucGxheUxpbmVDbGVhcihmdWxsUm93SW5kaWNlcy5sZW5ndGgpO1xuXG4gICAgICAvLyBDYW1lcmEgc2hha2Ugb24gYmlnIGNsZWFyc1xuICAgICAgaWYgKGZ1bGxSb3dJbmRpY2VzLmxlbmd0aCA+PSA0IHx8IGlzVFNwaW4pIHtcbiAgICAgICAgc2V0Qm9hcmRTaGFrZSh0cnVlKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiBzZXRCb2FyZFNoYWtlKGZhbHNlKSwgMjUwKTtcbiAgICAgIH1cblxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIC8vIFJlbW92ZSBjbGVhcmVkIHJvd3MgYW5kIGFkZCBmcmVzaCBlbXB0eSByb3dzIGF0IHRvcFxuICAgICAgICBjb25zdCByZW1haW5pbmdCb2FyZCA9IG5ld0JvYXJkLmZpbHRlcigoXywgaWR4KSA9PiAhZnVsbFJvd0luZGljZXMuaW5jbHVkZXMoaWR4KSk7XG4gICAgICAgIGNvbnN0IGVtcHR5Um93cyA9IEFycmF5LmZyb20oeyBsZW5ndGg6IGZ1bGxSb3dJbmRpY2VzLmxlbmd0aCB9LCAoKSA9PiBBcnJheShCT0FSRF9XSURUSCkuZmlsbChudWxsKSk7XG4gICAgICAgIGNvbnN0IGZpbmFsQm9hcmQgPSBbLi4uZW1wdHlSb3dzLCAuLi5yZW1haW5pbmdCb2FyZF07XG5cbiAgICAgICAgc2V0Qm9hcmQoZmluYWxCb2FyZCk7XG4gICAgICAgIGJvYXJkUmVmLmN1cnJlbnQgPSBmaW5hbEJvYXJkO1xuICAgICAgICBzZXRDbGVhcmluZ1Jvd3MoW10pO1xuXG4gICAgICAgIC8vIFNjb3JlIENhbGN1bGF0aW9uXG4gICAgICAgIGNvbnN0IGxpbmVzQ291bnQgPSBmdWxsUm93SW5kaWNlcy5sZW5ndGg7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRMdmwgPSBzdGF0c1JlZi5jdXJyZW50LmxldmVsO1xuICAgICAgICBjb25zdCBjdXJyZW50Q29tYm8gPSBzdGF0c1JlZi5jdXJyZW50LmN1cnJlbnRDb21ibyArIDE7XG4gICAgICAgIGNvbnN0IGlzQjJCID0gc3RhdHNSZWYuY3VycmVudC5iYWNrVG9CYWNrO1xuXG4gICAgICAgIGxldCBiYXNlUG9pbnRzID0gMDtcbiAgICAgICAgbGV0IGFjdGlvbkxhYmVsID0gJyc7XG5cbiAgICAgICAgaWYgKGlzVFNwaW4pIHtcbiAgICAgICAgICBpZiAobGluZXNDb3VudCA9PT0gMSkge1xuICAgICAgICAgICAgYmFzZVBvaW50cyA9IFNDT1JFUy5UU1BJTl9TSU5HTEUgKiBjdXJyZW50THZsO1xuICAgICAgICAgICAgYWN0aW9uTGFiZWwgPSAnVC1TUElOIFNJTkdMRSc7XG4gICAgICAgICAgfSBlbHNlIGlmIChsaW5lc0NvdW50ID09PSAyKSB7XG4gICAgICAgICAgICBiYXNlUG9pbnRzID0gU0NPUkVTLlRTUElOX0RPVUJMRSAqIGN1cnJlbnRMdmw7XG4gICAgICAgICAgICBhY3Rpb25MYWJlbCA9ICdULVNQSU4gRE9VQkxFISc7XG4gICAgICAgICAgfSBlbHNlIGlmIChsaW5lc0NvdW50ID09PSAzKSB7XG4gICAgICAgICAgICBiYXNlUG9pbnRzID0gU0NPUkVTLlRTUElOX1RSSVBMRSAqIGN1cnJlbnRMdmw7XG4gICAgICAgICAgICBhY3Rpb25MYWJlbCA9ICdULVNQSU4gVFJJUExFISEnO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzd2l0Y2ggKGxpbmVzQ291bnQpIHtcbiAgICAgICAgICAgIGNhc2UgMTpcbiAgICAgICAgICAgICAgYmFzZVBvaW50cyA9IFNDT1JFUy5TSU5HTEUgKiBjdXJyZW50THZsO1xuICAgICAgICAgICAgICBhY3Rpb25MYWJlbCA9ICdTSU5HTEUnO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMjpcbiAgICAgICAgICAgICAgYmFzZVBvaW50cyA9IFNDT1JFUy5ET1VCTEUgKiBjdXJyZW50THZsO1xuICAgICAgICAgICAgICBhY3Rpb25MYWJlbCA9ICdET1VCTEUhJztcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDM6XG4gICAgICAgICAgICAgIGJhc2VQb2ludHMgPSBTQ09SRVMuVFJJUExFICogY3VycmVudEx2bDtcbiAgICAgICAgICAgICAgYWN0aW9uTGFiZWwgPSAnVFJJUExFISEnO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgNDpcbiAgICAgICAgICAgICAgYmFzZVBvaW50cyA9IChpc0IyQiA/IFNDT1JFUy5CMkJfVEVUUklTIDogU0NPUkVTLlRFVFJJUykgKiBjdXJyZW50THZsO1xuICAgICAgICAgICAgICBhY3Rpb25MYWJlbCA9IGlzQjJCID8gJ0IyQiBURVRSSVMhIScgOiAnVEVUUklTISc7XG4gICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENvbWJvIGJvbnVzXG4gICAgICAgIGNvbnN0IGNvbWJvQm9udXMgPSBjdXJyZW50Q29tYm8gPiAwID8gNTAgKiBjdXJyZW50Q29tYm8gKiBjdXJyZW50THZsIDogMDtcbiAgICAgICAgY29uc3QgdG90YWxQb2ludHMgPSBiYXNlUG9pbnRzICsgY29tYm9Cb251cztcblxuICAgICAgICBpZiAoYWN0aW9uTGFiZWwpIHtcbiAgICAgICAgICBhZGRQb3B1cChgJHthY3Rpb25MYWJlbH0gJHtjdXJyZW50Q29tYm8gPiAwID8gYMK3ICR7Y3VycmVudENvbWJvfSBDT01CT2AgOiAnJ31gLCB0b3RhbFBvaW50cyk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXdUb3RhbExpbmVzID0gc3RhdHNSZWYuY3VycmVudC5saW5lcyArIGxpbmVzQ291bnQ7XG4gICAgICAgIGNvbnN0IG5ld0xldmVsID0gZ2FtZU1vZGUgPT09ICdtYXJhdGhvbicgPyBNYXRoLmZsb29yKG5ld1RvdGFsTGluZXMgLyAxMCkgKyAxIDogY3VycmVudEx2bDtcblxuICAgICAgICBpZiAobmV3TGV2ZWwgPiBjdXJyZW50THZsKSB7XG4gICAgICAgICAgc291bmQucGxheUxldmVsVXAoKTtcbiAgICAgICAgICBhZGRQb3B1cChgTEVWRUwgJHtuZXdMZXZlbH0hYCwgMCwgJyMzOGJkZjgnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENoZWNrIFNwcmludCBtb2RlIHdpblxuICAgICAgICBpZiAoZ2FtZU1vZGUgPT09ICdzcHJpbnQnICYmIG5ld1RvdGFsTGluZXMgPj0gNDApIHtcbiAgICAgICAgICBzZXRHYW1lU3RhdHVzKCd2aWN0b3J5Jyk7XG4gICAgICAgICAgc291bmQucGxheVZpY3RvcnkoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHNldFN0YXRzKChwcmV2KSA9PiAoe1xuICAgICAgICAgIC4uLnByZXYsXG4gICAgICAgICAgc2NvcmU6IHByZXYuc2NvcmUgKyB0b3RhbFBvaW50cyxcbiAgICAgICAgICBsaW5lczogbmV3VG90YWxMaW5lcyxcbiAgICAgICAgICBsZXZlbDogbmV3TGV2ZWwsXG4gICAgICAgICAgc2luZ2xlczogcHJldi5zaW5nbGVzICsgKGxpbmVzQ291bnQgPT09IDEgPyAxIDogMCksXG4gICAgICAgICAgZG91YmxlczogcHJldi5kb3VibGVzICsgKGxpbmVzQ291bnQgPT09IDIgPyAxIDogMCksXG4gICAgICAgICAgdHJpcGxlczogcHJldi50cmlwbGVzICsgKGxpbmVzQ291bnQgPT09IDMgPyAxIDogMCksXG4gICAgICAgICAgdGV0cmlzZXM6IHByZXYudGV0cmlzZXMgKyAobGluZXNDb3VudCA9PT0gNCA/IDEgOiAwKSxcbiAgICAgICAgICB0c3BpbnM6IHByZXYudHNwaW5zICsgKGlzVFNwaW4gPyAxIDogMCksXG4gICAgICAgICAgY3VycmVudENvbWJvLFxuICAgICAgICAgIG1heENvbWJvOiBNYXRoLm1heChwcmV2Lm1heENvbWJvLCBjdXJyZW50Q29tYm8pLFxuICAgICAgICAgIGJhY2tUb0JhY2s6IGxpbmVzQ291bnQgPT09IDQgfHwgaXNUU3BpbixcbiAgICAgICAgICByZW1haW5pbmdMaW5lczogZ2FtZU1vZGUgPT09ICdzcHJpbnQnID8gTWF0aC5tYXgoMCwgNDAgLSBuZXdUb3RhbExpbmVzKSA6IHVuZGVmaW5lZCxcbiAgICAgICAgfSkpO1xuXG4gICAgICAgIHNwYXduUGllY2UoKTtcbiAgICAgIH0sIDE2MCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIE5vIGxpbmVzIGNsZWFyZWQ6IHJlc2V0IGNvbWJvIGFuZCBhZHZhbmNlIHBpZWNlXG4gICAgICBzZXRCb2FyZChuZXdCb2FyZCk7XG4gICAgICBib2FyZFJlZi5jdXJyZW50ID0gbmV3Qm9hcmQ7XG5cbiAgICAgIHNldFN0YXRzKChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBjdXJyZW50Q29tYm86IC0xLFxuICAgICAgICBiYWNrVG9CYWNrOiBpc1RTcGluID8gcHJldi5iYWNrVG9CYWNrIDogcHJldi5iYWNrVG9CYWNrLFxuICAgICAgfSkpO1xuXG4gICAgICBzcGF3blBpZWNlKCk7XG4gICAgfVxuICB9LCBbYWRkUG9wdXAsIGdhbWVNb2RlLCBzcGF3blBpZWNlXSk7XG5cbiAgLy8gVHJ5IG1vdmVtZW50XG4gIGNvbnN0IG1vdmVIb3Jpem9udGFsID0gdXNlQ2FsbGJhY2soKGRpcmVjdGlvbjogLTEgfCAxKTogYm9vbGVhbiA9PiB7XG4gICAgaWYgKGdhbWVTdGF0dXNSZWYuY3VycmVudCAhPT0gJ3BsYXlpbmcnIHx8ICFjdXJyZW50UGllY2VSZWYuY3VycmVudCkgcmV0dXJuIGZhbHNlO1xuXG4gICAgY29uc3QgcGllY2UgPSBjdXJyZW50UGllY2VSZWYuY3VycmVudDtcbiAgICBpZiAoIWNoZWNrQ29sbGlzaW9uKHBpZWNlLCBib2FyZFJlZi5jdXJyZW50LCB7IHg6IGRpcmVjdGlvbiwgeTogMCB9KSkge1xuICAgICAgY29uc3QgbW92ZWRQaWVjZTogUGllY2UgPSB7XG4gICAgICAgIC4uLnBpZWNlLFxuICAgICAgICBwb3NpdGlvbjogeyB4OiBwaWVjZS5wb3NpdGlvbi54ICsgZGlyZWN0aW9uLCB5OiBwaWVjZS5wb3NpdGlvbi55IH0sXG4gICAgICB9O1xuICAgICAgc2V0Q3VycmVudFBpZWNlKG1vdmVkUGllY2UpO1xuICAgICAgY3VycmVudFBpZWNlUmVmLmN1cnJlbnQgPSBtb3ZlZFBpZWNlO1xuICAgICAgc2V0R2hvc3RZKGNhbGN1bGF0ZUdob3N0WShtb3ZlZFBpZWNlLCBib2FyZFJlZi5jdXJyZW50KSk7XG4gICAgICBzb3VuZC5wbGF5TW92ZSgpO1xuXG4gICAgICAvLyBSZXNldCBsb2NrIHRpbWVyIGlmIG9uIGdyb3VuZCBhbmQgd2l0aGluIGxvY2sgbGltaXRcbiAgICAgIGlmIChjaGVja0NvbGxpc2lvbihtb3ZlZFBpZWNlLCBib2FyZFJlZi5jdXJyZW50LCB7IHg6IDAsIHk6IDEgfSkpIHtcbiAgICAgICAgaWYgKGxvY2tSZXNldHNSZWYuY3VycmVudCA8IE1BWF9MT0NLX1JFU0VUUykge1xuICAgICAgICAgIGxvY2tSZXNldHNSZWYuY3VycmVudCsrO1xuICAgICAgICAgIGlmIChsb2NrVGltZW91dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KGxvY2tUaW1lb3V0UmVmLmN1cnJlbnQpO1xuICAgICAgICAgICAgbG9ja1RpbWVvdXRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9LCBbY2FsY3VsYXRlR2hvc3RZXSk7XG5cbiAgLy8gU29mdCBEcm9wXG4gIGNvbnN0IHNvZnREcm9wID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChnYW1lU3RhdHVzUmVmLmN1cnJlbnQgIT09ICdwbGF5aW5nJyB8fCAhY3VycmVudFBpZWNlUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIGNvbnN0IHBpZWNlID0gY3VycmVudFBpZWNlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjaGVja0NvbGxpc2lvbihwaWVjZSwgYm9hcmRSZWYuY3VycmVudCwgeyB4OiAwLCB5OiAxIH0pKSB7XG4gICAgICBjb25zdCBkcm9wcGVkUGllY2U6IFBpZWNlID0ge1xuICAgICAgICAuLi5waWVjZSxcbiAgICAgICAgcG9zaXRpb246IHsgeDogcGllY2UucG9zaXRpb24ueCwgeTogcGllY2UucG9zaXRpb24ueSArIDEgfSxcbiAgICAgIH07XG4gICAgICBzZXRDdXJyZW50UGllY2UoZHJvcHBlZFBpZWNlKTtcbiAgICAgIGN1cnJlbnRQaWVjZVJlZi5jdXJyZW50ID0gZHJvcHBlZFBpZWNlO1xuICAgICAgc291bmQucGxheVNvZnREcm9wKCk7XG4gICAgICBzZXRTdGF0cygocHJldikgPT4gKHsgLi4ucHJldiwgc2NvcmU6IHByZXYuc2NvcmUgKyBTQ09SRVMuU09GVF9EUk9QIH0pKTtcbiAgICB9XG4gIH0sIFtdKTtcblxuICAvLyBIYXJkIERyb3BcbiAgY29uc3QgaGFyZERyb3AgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKGdhbWVTdGF0dXNSZWYuY3VycmVudCAhPT0gJ3BsYXlpbmcnIHx8ICFjdXJyZW50UGllY2VSZWYuY3VycmVudCkgcmV0dXJuO1xuXG4gICAgY29uc3QgcGllY2UgPSBjdXJyZW50UGllY2VSZWYuY3VycmVudDtcbiAgICBsZXQgZHJvcERpc3RhbmNlID0gMDtcbiAgICB3aGlsZSAoIWNoZWNrQ29sbGlzaW9uKHBpZWNlLCBib2FyZFJlZi5jdXJyZW50LCB7IHg6IDAsIHk6IGRyb3BEaXN0YW5jZSArIDEgfSkpIHtcbiAgICAgIGRyb3BEaXN0YW5jZSsrO1xuICAgIH1cblxuICAgIGNvbnN0IGRyb3BwZWRQaWVjZTogUGllY2UgPSB7XG4gICAgICAuLi5waWVjZSxcbiAgICAgIHBvc2l0aW9uOiB7IHg6IHBpZWNlLnBvc2l0aW9uLngsIHk6IHBpZWNlLnBvc2l0aW9uLnkgKyBkcm9wRGlzdGFuY2UgfSxcbiAgICB9O1xuXG4gICAgc2V0Q3VycmVudFBpZWNlKGRyb3BwZWRQaWVjZSk7XG4gICAgY3VycmVudFBpZWNlUmVmLmN1cnJlbnQgPSBkcm9wcGVkUGllY2U7XG4gICAgc291bmQucGxheUhhcmREcm9wKCk7XG5cbiAgICAvLyBWaXN1YWwgY2FtZXJhIHB1bmNoXG4gICAgc2V0Qm9hcmRTaGFrZSh0cnVlKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHNldEJvYXJkU2hha2UoZmFsc2UpLCAxMjApO1xuXG4gICAgc2V0U3RhdHMoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgc2NvcmU6IHByZXYuc2NvcmUgKyBkcm9wRGlzdGFuY2UgKiBTQ09SRVMuSEFSRF9EUk9QLFxuICAgIH0pKTtcblxuICAgIGxvY2tQaWVjZSgpO1xuICB9LCBbbG9ja1BpZWNlXSk7XG5cbiAgLy8gUm90YXRlIFBpZWNlIHVzaW5nIFNSUyAoU3VwZXIgUm90YXRpb24gU3lzdGVtKVxuICBjb25zdCByb3RhdGUgPSB1c2VDYWxsYmFjaygoY2xvY2t3aXNlOiBib29sZWFuID0gdHJ1ZSkgPT4ge1xuICAgIGlmIChnYW1lU3RhdHVzUmVmLmN1cnJlbnQgIT09ICdwbGF5aW5nJyB8fCAhY3VycmVudFBpZWNlUmVmLmN1cnJlbnQpIHJldHVybjtcblxuICAgIGNvbnN0IHBpZWNlID0gY3VycmVudFBpZWNlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHBpZWNlLnR5cGUgPT09ICdPJykgcmV0dXJuOyAvLyBPIHBpZWNlIGRvZXMgbm90IHJvdGF0ZVxuXG4gICAgY29uc3QgY3VycmVudFJvdCA9IHBpZWNlLnJvdGF0aW9uO1xuICAgIGNvbnN0IG5leHRSb3QgPSAoY2xvY2t3aXNlID8gKGN1cnJlbnRSb3QgKyAxKSAlIDQgOiAoY3VycmVudFJvdCArIDMpICUgNCkgYXMgUm90YXRpb25TdGF0ZTtcbiAgICBjb25zdCBraWNrS2V5ID0gYCR7Y3VycmVudFJvdH0tPiR7bmV4dFJvdH1gO1xuICAgIGNvbnN0IGtpY2tzID0gcGllY2UudHlwZSA9PT0gJ0knID8gSV9XQUxMX0tJQ0tTW2tpY2tLZXldIDogSkxTVFpfV0FMTF9LSUNLU1traWNrS2V5XTtcblxuICAgIGlmICgha2lja3MpIHJldHVybjtcblxuICAgIGZvciAoY29uc3Qga2ljayBvZiBraWNrcykge1xuICAgICAgY29uc3QgdGVzdFBpZWNlOiBQaWVjZSA9IHtcbiAgICAgICAgLi4ucGllY2UsXG4gICAgICAgIHJvdGF0aW9uOiBuZXh0Um90LFxuICAgICAgICBwb3NpdGlvbjoge1xuICAgICAgICAgIHg6IHBpZWNlLnBvc2l0aW9uLnggKyBraWNrLngsXG4gICAgICAgICAgeTogcGllY2UucG9zaXRpb24ueSAtIGtpY2sueSwgLy8gU1JTIHRhYmxlcyBpbnZlcnQgeVxuICAgICAgICB9LFxuICAgICAgfTtcblxuICAgICAgaWYgKCFjaGVja0NvbGxpc2lvbih0ZXN0UGllY2UsIGJvYXJkUmVmLmN1cnJlbnQpKSB7XG4gICAgICAgIC8vIFQtU3BpbiBkZXRlY3Rpb24gKDMtY29ybmVyIHJ1bGUpXG4gICAgICAgIGlmIChwaWVjZS50eXBlID09PSAnVCcpIHtcbiAgICAgICAgICBjb25zdCBjeCA9IHRlc3RQaWVjZS5wb3NpdGlvbi54ICsgMTtcbiAgICAgICAgICBjb25zdCBjeSA9IHRlc3RQaWVjZS5wb3NpdGlvbi55ICsgMTtcbiAgICAgICAgICBjb25zdCBjb3JuZXJzID0gW1xuICAgICAgICAgICAgeyB4OiBjeCAtIDEsIHk6IGN5IC0gMSB9LFxuICAgICAgICAgICAgeyB4OiBjeCArIDEsIHk6IGN5IC0gMSB9LFxuICAgICAgICAgICAgeyB4OiBjeCAtIDEsIHk6IGN5ICsgMSB9LFxuICAgICAgICAgICAgeyB4OiBjeCArIDEsIHk6IGN5ICsgMSB9LFxuICAgICAgICAgIF07XG4gICAgICAgICAgbGV0IG9jY3VwaWVkQ29ybmVycyA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBjIG9mIGNvcm5lcnMpIHtcbiAgICAgICAgICAgIGlmIChjLnggPCAwIHx8IGMueCA+PSBCT0FSRF9XSURUSCB8fCBjLnkgPj0gVE9UQUxfUk9XUyB8fCAoYy55ID49IDAgJiYgYm9hcmRSZWYuY3VycmVudFtjLnldW2MueF0gIT09IG51bGwpKSB7XG4gICAgICAgICAgICAgIG9jY3VwaWVkQ29ybmVycysrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBsYXN0Um90YXRlV2FzVFNwaW5SZWYuY3VycmVudCA9IG9jY3VwaWVkQ29ybmVycyA+PSAzO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGxhc3RSb3RhdGVXYXNUU3BpblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH1cblxuICAgICAgICBzZXRDdXJyZW50UGllY2UodGVzdFBpZWNlKTtcbiAgICAgICAgY3VycmVudFBpZWNlUmVmLmN1cnJlbnQgPSB0ZXN0UGllY2U7XG4gICAgICAgIHNldEdob3N0WShjYWxjdWxhdGVHaG9zdFkodGVzdFBpZWNlLCBib2FyZFJlZi5jdXJyZW50KSk7XG4gICAgICAgIHNvdW5kLnBsYXlSb3RhdGUoKTtcblxuICAgICAgICAvLyBMb2NrIGRlbGF5IHJlc2V0XG4gICAgICAgIGlmIChsb2NrUmVzZXRzUmVmLmN1cnJlbnQgPCBNQVhfTE9DS19SRVNFVFMpIHtcbiAgICAgICAgICBsb2NrUmVzZXRzUmVmLmN1cnJlbnQrKztcbiAgICAgICAgICBpZiAobG9ja1RpbWVvdXRSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgd2luZG93LmNsZWFyVGltZW91dChsb2NrVGltZW91dFJlZi5jdXJyZW50KTtcbiAgICAgICAgICAgIGxvY2tUaW1lb3V0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICB9LCBbY2FsY3VsYXRlR2hvc3RZXSk7XG5cbiAgLy8gSG9sZCBQaWVjZVxuICBjb25zdCBob2xkID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmIChnYW1lU3RhdHVzUmVmLmN1cnJlbnQgIT09ICdwbGF5aW5nJyB8fCAhY3VycmVudFBpZWNlUmVmLmN1cnJlbnQgfHwgIWNhbkhvbGQpIHJldHVybjtcblxuICAgIHNvdW5kLnBsYXlIb2xkKCk7XG4gICAgY29uc3QgY3VycmVudFR5cGUgPSBjdXJyZW50UGllY2VSZWYuY3VycmVudC50eXBlO1xuXG4gICAgaWYgKGhvbGRQaWVjZSA9PT0gbnVsbCkge1xuICAgICAgc2V0SG9sZFBpZWNlKGN1cnJlbnRUeXBlKTtcbiAgICAgIHNwYXduUGllY2UoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgbmV4dFR5cGUgPSBob2xkUGllY2U7XG4gICAgICBzZXRIb2xkUGllY2UoY3VycmVudFR5cGUpO1xuICAgICAgc3Bhd25QaWVjZShuZXh0VHlwZSk7XG4gICAgfVxuICAgIHNldENhbkhvbGQoZmFsc2UpO1xuICB9LCBbY2FuSG9sZCwgaG9sZFBpZWNlLCBzcGF3blBpZWNlXSk7XG5cbiAgLy8gU3RhcnQgbmV3IGdhbWVcbiAgY29uc3Qgc3RhcnRHYW1lID0gdXNlQ2FsbGJhY2soKG1vZGU6IEdhbWVNb2RlID0gZ2FtZU1vZGUpID0+IHtcbiAgICBjb25zdCBlbXB0eSA9IGNyZWF0ZUVtcHR5Qm9hcmQoKTtcbiAgICBzZXRCb2FyZChlbXB0eSk7XG4gICAgYm9hcmRSZWYuY3VycmVudCA9IGVtcHR5O1xuXG4gICAgYmFnUmVmLmN1cnJlbnQgPSBnZW5lcmF0ZUJhZygpO1xuICAgIGNvbnN0IGluaXRpYWxRdWV1ZSA9IFsuLi5iYWdSZWYuY3VycmVudCwgLi4uZ2VuZXJhdGVCYWcoKV07XG4gICAgYmFnUmVmLmN1cnJlbnQgPSBpbml0aWFsUXVldWUuc2xpY2UoMSk7XG4gICAgc2V0TmV4dFF1ZXVlKGJhZ1JlZi5jdXJyZW50LnNsaWNlKDAsIDUpKTtcblxuICAgIHNldEhvbGRQaWVjZShudWxsKTtcbiAgICBzZXRDYW5Ib2xkKHRydWUpO1xuICAgIHNldENsZWFyaW5nUm93cyhbXSk7XG4gICAgc2V0UG9wdXBzKFtdKTtcbiAgICBsb2NrUmVzZXRzUmVmLmN1cnJlbnQgPSAwO1xuICAgIGxhc3RSb3RhdGVXYXNUU3BpblJlZi5jdXJyZW50ID0gZmFsc2U7XG5cbiAgICBzZXRTdGF0cyh7XG4gICAgICBzY29yZTogMCxcbiAgICAgIGxpbmVzOiAwLFxuICAgICAgbGV2ZWw6IDEsXG4gICAgICBzaW5nbGVzOiAwLFxuICAgICAgZG91YmxlczogMCxcbiAgICAgIHRyaXBsZXM6IDAsXG4gICAgICB0ZXRyaXNlczogMCxcbiAgICAgIHRzcGluczogMCxcbiAgICAgIG1heENvbWJvOiAwLFxuICAgICAgY3VycmVudENvbWJvOiAtMSxcbiAgICAgIGJhY2tUb0JhY2s6IGZhbHNlLFxuICAgICAgc3RhcnRUaW1lOiBEYXRlLm5vdygpLFxuICAgICAgZWxhcHNlZFRpbWU6IDAsXG4gICAgICByZW1haW5pbmdMaW5lczogbW9kZSA9PT0gJ3NwcmludCcgPyA0MCA6IHVuZGVmaW5lZCxcbiAgICAgIHJlbWFpbmluZ1RpbWU6IG1vZGUgPT09ICd1bHRyYScgPyAxMjAgOiB1bmRlZmluZWQsXG4gICAgfSk7XG5cbiAgICBjb25zdCBmaXJzdFBpZWNlVHlwZSA9IGluaXRpYWxRdWV1ZVswXTtcbiAgICBjb25zdCBuZXdQaWVjZTogUGllY2UgPSB7XG4gICAgICB0eXBlOiBmaXJzdFBpZWNlVHlwZSxcbiAgICAgIHJvdGF0aW9uOiAwLFxuICAgICAgcG9zaXRpb246IHsgLi4uU1BBV05fUE9TSVRJT05TW2ZpcnN0UGllY2VUeXBlXSB9LFxuICAgIH07XG5cbiAgICBzZXRDdXJyZW50UGllY2UobmV3UGllY2UpO1xuICAgIGN1cnJlbnRQaWVjZVJlZi5jdXJyZW50ID0gbmV3UGllY2U7XG4gICAgc2V0R2hvc3RZKGNhbGN1bGF0ZUdob3N0WShuZXdQaWVjZSwgZW1wdHkpKTtcbiAgICBzZXRHYW1lU3RhdHVzKCdwbGF5aW5nJyk7XG4gIH0sIFtjYWxjdWxhdGVHaG9zdFksIGdhbWVNb2RlXSk7XG5cbiAgLy8gUGF1c2UgLyBSZXN1bWVcbiAgY29uc3QgdG9nZ2xlUGF1c2UgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0R2FtZVN0YXR1cygocHJldikgPT4ge1xuICAgICAgaWYgKHByZXYgPT09ICdwbGF5aW5nJykgcmV0dXJuICdwYXVzZWQnO1xuICAgICAgaWYgKHByZXYgPT09ICdwYXVzZWQnKSByZXR1cm4gJ3BsYXlpbmcnO1xuICAgICAgcmV0dXJuIHByZXY7XG4gICAgfSk7XG4gIH0sIFtdKTtcblxuICAvLyBNYWluIEdyYXZpdHkgR2FtZSBMb29wXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGdhbWVTdGF0dXMgIT09ICdwbGF5aW5nJykge1xuICAgICAgaWYgKGRyb3BUaW1lclJlZi5jdXJyZW50KSB7XG4gICAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoZHJvcFRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICBkcm9wVGltZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgY3VycmVudEx2bCA9IHN0YXRzLmxldmVsO1xuICAgIGNvbnN0IHNwZWVkID0gZ2FtZU1vZGUgPT09ICd6ZW4nID8gemVuU3BlZWQgOiBMRVZFTF9TUEVFRFNbTWF0aC5taW4oY3VycmVudEx2bCAtIDEsIExFVkVMX1NQRUVEUy5sZW5ndGggLSAxKV07XG5cbiAgICBjb25zdCB0aWNrID0gKCkgPT4ge1xuICAgICAgaWYgKGdhbWVTdGF0dXNSZWYuY3VycmVudCAhPT0gJ3BsYXlpbmcnKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IHBpZWNlID0gY3VycmVudFBpZWNlUmVmLmN1cnJlbnQ7XG4gICAgICBpZiAoIXBpZWNlKSByZXR1cm47XG5cbiAgICAgIGlmICghY2hlY2tDb2xsaXNpb24ocGllY2UsIGJvYXJkUmVmLmN1cnJlbnQsIHsgeDogMCwgeTogMSB9KSkge1xuICAgICAgICAvLyBEcm9wIDEgcm93XG4gICAgICAgIGNvbnN0IGRyb3BwZWRQaWVjZTogUGllY2UgPSB7XG4gICAgICAgICAgLi4ucGllY2UsXG4gICAgICAgICAgcG9zaXRpb246IHsgeDogcGllY2UucG9zaXRpb24ueCwgeTogcGllY2UucG9zaXRpb24ueSArIDEgfSxcbiAgICAgICAgfTtcbiAgICAgICAgc2V0Q3VycmVudFBpZWNlKGRyb3BwZWRQaWVjZSk7XG4gICAgICAgIGN1cnJlbnRQaWVjZVJlZi5jdXJyZW50ID0gZHJvcHBlZFBpZWNlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gUGllY2UgaGl0IGdyb3VuZDogaW5pdGlhdGUgbG9jayBkZWxheSBpZiBub3QgYWxyZWFkeSBhY3RpdmVcbiAgICAgICAgaWYgKCFsb2NrVGltZW91dFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgbG9ja1RpbWVvdXRSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIGxvY2tQaWVjZSgpO1xuICAgICAgICAgIH0sIExPQ0tfREVMQVlfTVMpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGRyb3BUaW1lclJlZi5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQodGljaywgc3BlZWQpO1xuICAgIH07XG5cbiAgICBkcm9wVGltZXJSZWYuY3VycmVudCA9IHdpbmRvdy5zZXRUaW1lb3V0KHRpY2ssIHNwZWVkKTtcblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBpZiAoZHJvcFRpbWVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgd2luZG93LmNsZWFyVGltZW91dChkcm9wVGltZXJSZWYuY3VycmVudCk7XG4gICAgICAgIGRyb3BUaW1lclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbZ2FtZVN0YXR1cywgc3RhdHMubGV2ZWwsIGdhbWVNb2RlLCB6ZW5TcGVlZCwgbG9ja1BpZWNlXSk7XG5cbiAgLy8gVGltZXIgbG9vcCBmb3IgVWx0cmEgTW9kZSAmIEVsYXBzZWQgVGltZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChnYW1lU3RhdHVzICE9PSAncGxheWluZycpIHtcbiAgICAgIGlmICh1bHRyYVRpbWVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgd2luZG93LmNsZWFySW50ZXJ2YWwodWx0cmFUaW1lclJlZi5jdXJyZW50KTtcbiAgICAgICAgdWx0cmFUaW1lclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB1bHRyYVRpbWVyUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgc2V0U3RhdHMoKHByZXYpID0+IHtcbiAgICAgICAgY29uc3QgbmV4dEVsYXBzZWQgPSBwcmV2LnN0YXJ0VGltZSA+IDAgPyBEYXRlLm5vdygpIC0gcHJldi5zdGFydFRpbWUgOiAwO1xuXG4gICAgICAgIGlmIChnYW1lTW9kZSA9PT0gJ3VsdHJhJykge1xuICAgICAgICAgIGNvbnN0IG5leHRSZW1haW5pbmcgPSBNYXRoLm1heCgwLCAxMjAgLSBNYXRoLmZsb29yKG5leHRFbGFwc2VkIC8gMTAwMCkpO1xuICAgICAgICAgIGlmIChuZXh0UmVtYWluaW5nIDw9IDApIHtcbiAgICAgICAgICAgIHNldEdhbWVTdGF0dXMoJ3ZpY3RvcnknKTtcbiAgICAgICAgICAgIHNvdW5kLnBsYXlWaWN0b3J5KCk7XG4gICAgICAgICAgICByZXR1cm4geyAuLi5wcmV2LCBlbGFwc2VkVGltZTogbmV4dEVsYXBzZWQsIHJlbWFpbmluZ1RpbWU6IDAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHsgLi4ucHJldiwgZWxhcHNlZFRpbWU6IG5leHRFbGFwc2VkLCByZW1haW5pbmdUaW1lOiBuZXh0UmVtYWluaW5nIH07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4geyAuLi5wcmV2LCBlbGFwc2VkVGltZTogbmV4dEVsYXBzZWQgfTtcbiAgICAgIH0pO1xuICAgIH0sIDEwMCk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKHVsdHJhVGltZXJSZWYuY3VycmVudCkge1xuICAgICAgICB3aW5kb3cuY2xlYXJJbnRlcnZhbCh1bHRyYVRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICB1bHRyYVRpbWVyUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFtnYW1lU3RhdHVzLCBnYW1lTW9kZV0pO1xuXG4gIC8vIFN5bmMgaGlnaCBzY29yZXMgdG8gbG9jYWwgc3RvcmFnZSBvbiBnYW1lb3ZlciBvciB2aWN0b3J5XG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGdhbWVTdGF0dXMgPT09ICdnYW1lb3ZlcicgfHwgZ2FtZVN0YXR1cyA9PT0gJ3ZpY3RvcnknKSB7XG4gICAgICBpZiAoc3RhdHMuc2NvcmUgPiAwKSB7XG4gICAgICAgIGNvbnN0IGVudHJ5OiBIaWdoU2NvcmVFbnRyeSA9IHtcbiAgICAgICAgICBpZDogYCR7RGF0ZS5ub3coKX1gLFxuICAgICAgICAgIG1vZGU6IGdhbWVNb2RlLFxuICAgICAgICAgIHNjb3JlOiBzdGF0cy5zY29yZSxcbiAgICAgICAgICBsaW5lczogc3RhdHMubGluZXMsXG4gICAgICAgICAgbGV2ZWw6IHN0YXRzLmxldmVsLFxuICAgICAgICAgIHRpbWVNczogc3RhdHMuZWxhcHNlZFRpbWUsXG4gICAgICAgICAgZGF0ZTogbmV3IERhdGUoKS50b0xvY2FsZURhdGVTdHJpbmcodW5kZWZpbmVkLCB7IG1vbnRoOiAnc2hvcnQnLCBkYXk6ICdudW1lcmljJywgeWVhcjogJ251bWVyaWMnIH0pLFxuICAgICAgICB9O1xuICAgICAgICBzZXRIaWdoU2NvcmVzKChwcmV2KSA9PiB7XG4gICAgICAgICAgY29uc3QgdXBkYXRlZCA9IFsuLi5wcmV2LCBlbnRyeV0uc29ydCgoYSwgYikgPT4gYi5zY29yZSAtIGEuc2NvcmUpLnNsaWNlKDAsIDIwKTtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ3RldHJpc19oaWdoX3Njb3JlcycsIEpTT04uc3RyaW5naWZ5KHVwZGF0ZWQpKTtcbiAgICAgICAgICB9IGNhdGNoIHtcbiAgICAgICAgICAgIC8vIGlnbm9yZVxuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gdXBkYXRlZDtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbZ2FtZVN0YXR1cywgZ2FtZU1vZGUsIHN0YXRzLnNjb3JlLCBzdGF0cy5saW5lcywgc3RhdHMubGV2ZWwsIHN0YXRzLmVsYXBzZWRUaW1lXSk7XG5cbiAgcmV0dXJuIHtcbiAgICBib2FyZCxcbiAgICBjdXJyZW50UGllY2UsXG4gICAgZ2hvc3RZLFxuICAgIG5leHRRdWV1ZSxcbiAgICBob2xkUGllY2UsXG4gICAgY2FuSG9sZCxcbiAgICBnYW1lU3RhdHVzLFxuICAgIHN0YXRzLFxuICAgIGhpZ2hTY29yZXMsXG4gICAgY2xlYXJpbmdSb3dzLFxuICAgIHBvcHVwcyxcbiAgICBib2FyZFNoYWtlLFxuICAgIHplblNwZWVkLFxuICAgIHNldFplblNwZWVkLFxuICAgIHN0YXJ0R2FtZSxcbiAgICB0b2dnbGVQYXVzZSxcbiAgICBtb3ZlSG9yaXpvbnRhbCxcbiAgICBzb2Z0RHJvcCxcbiAgICBoYXJkRHJvcCxcbiAgICByb3RhdGUsXG4gICAgaG9sZCxcbiAgfTtcbn1cbiJdfQ==