const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=82647e6a";
import { Play, RotateCcw, Pause, Trophy, Keyboard, Github, Sparkles, Flame, Clock, Zap, Coffee } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
import { THEMES, DEFAULT_KEYBINDINGS } from "/src/utils/tetrisConstants.ts";
import { useTetris } from "/src/hooks/useTetris.ts";
import { TetrisBoard } from "/src/components/TetrisBoard.tsx";
import { HoldQueue } from "/src/components/HoldQueue.tsx";
import { NextQueue } from "/src/components/NextQueue.tsx";
import { ScoreBoard } from "/src/components/ScoreBoard.tsx";
import { SoundControls } from "/src/components/SoundControls.tsx";
import { ThemeSelector } from "/src/components/ThemeSelector.tsx";
import { MobileControls } from "/src/components/MobileControls.tsx";
import { HighScoresModal } from "/src/components/HighScoresModal.tsx";
import { KeybindingsModal } from "/src/components/KeybindingsModal.tsx";
import { GitHubExportModal } from "/src/components/GitHubExportModal.tsx";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export default function App() {
	const [selectedMode, setSelectedMode] = useState("marathon");
	const [currentThemeId, setCurrentThemeId] = useState("cyber");
	const [isGitHubModalOpen, setIsGitHubModalOpen] = useState(false);
	const [isHighScoresModalOpen, setIsHighScoresModalOpen] = useState(false);
	const [isControlsModalOpen, setIsControlsModalOpen] = useState(false);
	const activeTheme = THEMES[currentThemeId];
	const { board, currentPiece, ghostY, nextQueue, holdPiece, canHold, gameStatus, stats, highScores, clearingRows, popups, boardShake, zenSpeed, setZenSpeed, startGame, togglePause, moveHorizontal, softDrop, hardDrop, rotate, hold } = useTetris(selectedMode);
	// Trigger confetti on victory (e.g. Sprint completed or Ultra finished)
	useEffect(() => {
		if (gameStatus === "victory") {
			confetti({
				particleCount: 100,
				spread: 70,
				origin: { y: .6 }
			});
		}
	}, [gameStatus]);
	// Keyboard Event Management with DAS & ARR
	const keysPressedRef = useRef(new Set());
	const dasTimerRef = useRef(null);
	const arrIntervalRef = useRef(null);
	const handleKeyDown = useCallback((e) => {
		// Prevent browser scroll on game keys
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) {
			e.preventDefault();
		}
		if (e.repeat && [
			"Space",
			"KeyC",
			"KeyP",
			"KeyR"
		].includes(e.code)) {
			return;
		}
		const code = e.code;
		keysPressedRef.current.add(code);
		// Global control shortcuts
		if (DEFAULT_KEYBINDINGS.pause.includes(code)) {
			togglePause();
			return;
		}
		if (DEFAULT_KEYBINDINGS.restart.includes(code)) {
			startGame(selectedMode);
			return;
		}
		if (gameStatus !== "playing") return;
		// Single action triggers
		if (DEFAULT_KEYBINDINGS.hardDrop.includes(code)) {
			hardDrop();
			return;
		}
		if (DEFAULT_KEYBINDINGS.rotateCW.includes(code)) {
			rotate(true);
			return;
		}
		if (DEFAULT_KEYBINDINGS.rotateCCW.includes(code)) {
			rotate(false);
			return;
		}
		if (DEFAULT_KEYBINDINGS.hold.includes(code)) {
			hold();
			return;
		}
		// Movement with DAS (Delayed Auto Shift)
		if (DEFAULT_KEYBINDINGS.moveLeft.includes(code)) {
			moveHorizontal(-1);
			if (dasTimerRef.current) clearTimeout(dasTimerRef.current);
			if (arrIntervalRef.current) clearInterval(arrIntervalRef.current);
			dasTimerRef.current = window.setTimeout(() => {
				arrIntervalRef.current = window.setInterval(() => {
					if (keysPressedRef.current.has(code)) {
						moveHorizontal(-1);
					}
				}, 35);
			}, 150);
		} else if (DEFAULT_KEYBINDINGS.moveRight.includes(code)) {
			moveHorizontal(1);
			if (dasTimerRef.current) clearTimeout(dasTimerRef.current);
			if (arrIntervalRef.current) clearInterval(arrIntervalRef.current);
			dasTimerRef.current = window.setTimeout(() => {
				arrIntervalRef.current = window.setInterval(() => {
					if (keysPressedRef.current.has(code)) {
						moveHorizontal(1);
					}
				}, 35);
			}, 150);
		} else if (DEFAULT_KEYBINDINGS.softDrop.includes(code)) {
			softDrop();
		}
	}, [
		gameStatus,
		hardDrop,
		hold,
		moveHorizontal,
		rotate,
		selectedMode,
		softDrop,
		startGame,
		togglePause
	]);
	const handleKeyUp = useCallback((e) => {
		keysPressedRef.current.delete(e.code);
		const isLeftReleased = DEFAULT_KEYBINDINGS.moveLeft.includes(e.code);
		const isRightReleased = DEFAULT_KEYBINDINGS.moveRight.includes(e.code);
		if (isLeftReleased || isRightReleased) {
			if (dasTimerRef.current) {
				clearTimeout(dasTimerRef.current);
				dasTimerRef.current = null;
			}
			if (arrIntervalRef.current) {
				clearInterval(arrIntervalRef.current);
				arrIntervalRef.current = null;
			}
		}
	}, []);
	useEffect(() => {
		window.addEventListener("keydown", handleKeyDown);
		window.addEventListener("keyup", handleKeyUp);
		return () => {
			window.removeEventListener("keydown", handleKeyDown);
			window.removeEventListener("keyup", handleKeyUp);
			if (dasTimerRef.current) clearTimeout(dasTimerRef.current);
			if (arrIntervalRef.current) clearInterval(arrIntervalRef.current);
		};
	}, [handleKeyDown, handleKeyUp]);
	// Mode Selection Handler
	const handleSelectMode = (mode) => {
		setSelectedMode(mode);
		startGame(mode);
	};
	const handleClearScores = () => {
		localStorage.removeItem("tetris_high_scores");
		window.location.reload();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `min-h-screen bg-gradient-to-b ${activeTheme.background} text-slate-100 flex flex-col selection:bg-cyan-500/30 font-sans`,
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex items-center justify-between gap-8 px-6 py-3.5 border-b border-slate-800/80 bg-slate-950/40 backdrop-blur-md sticky top-0 z-40",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-lg font-extrabold tracking-tight text-white whitespace-nowrap",
							children: "Tetris Pro Arcade"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hidden sm:inline-block text-[11px] font-mono text-cyan-400 font-bold bg-cyan-950/60 border border-cyan-800/60 px-2 py-0.5 rounded-md",
							children: "SRS v2.4"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 204,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("nav", {
						className: "hidden md:flex items-center gap-6 text-sm font-medium text-slate-400",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsControlsModalOpen(true),
								className: "hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Keyboard, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 219,
									columnNumber: 13
								}, this), "Controls"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsHighScoresModalOpen(true),
								className: "hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Trophy, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 13
								}, this), "Leaderboard"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsGitHubModalOpen(true),
								className: "hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 text-cyan-400",
								children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 13
								}, this), "GitHub Guide"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3 shrink-0",
						children: [/* @__PURE__ */ _jsxDEV(SoundControls, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 240,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setIsGitHubModalOpen(true),
							className: "flex items-center gap-2 px-4 py-2 text-xs font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 rounded-xl transition-all shadow-md shadow-cyan-600/20 active:scale-95 whitespace-nowrap shrink-0",
							children: [/* @__PURE__ */ _jsxDEV(Github, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 245,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Export to GitHub" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 246,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 239,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 flex flex-col items-center justify-start p-3 md:p-6 max-w-6xl w-full mx-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-full flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800/60",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1.5 p-1 bg-slate-900/60 border border-slate-800 rounded-xl text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleSelectMode("marathon"),
									className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${selectedMode === "marathon" ? "bg-slate-800 text-cyan-300 shadow-sm border border-cyan-500/30" : "text-slate-400 hover:text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 265,
										columnNumber: 15
									}, this), "Marathon"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleSelectMode("sprint"),
									className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${selectedMode === "sprint" ? "bg-slate-800 text-emerald-300 shadow-sm border border-emerald-500/30" : "text-slate-400 hover:text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Zap, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 276,
										columnNumber: 15
									}, this), "Sprint (40L)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 268,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleSelectMode("ultra"),
									className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${selectedMode === "ultra" ? "bg-slate-800 text-rose-300 shadow-sm border border-rose-500/30" : "text-slate-400 hover:text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 287,
										columnNumber: 15
									}, this), "Ultra (2m)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 279,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleSelectMode("zen"),
									className: `flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition-all ${selectedMode === "zen" ? "bg-slate-800 text-purple-300 shadow-sm border border-purple-500/30" : "text-slate-400 hover:text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Coffee, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 15
									}, this), "Zen"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 290,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 256,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV(ThemeSelector, {
							currentThemeId,
							onSelectTheme: setCurrentThemeId
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-full flex flex-col lg:flex-row items-center lg:items-start justify-center gap-4 md:gap-8",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "hidden lg:flex flex-col gap-4 w-40 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV(HoldQueue, {
									holdPiece,
									canHold,
									theme: activeTheme,
									onHoldClick: hold
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg text-xs space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-slate-300 block",
											children: "KEY SHORTCUTS"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 314,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-slate-400 text-[11px]",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Rotate CW" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 316,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("kbd", {
												className: "font-mono bg-slate-800 px-1.5 rounded text-cyan-300",
												children: "↑ / X"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 317,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 315,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-slate-400 text-[11px]",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Rotate CCW" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 320,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("kbd", {
												className: "font-mono bg-slate-800 px-1.5 rounded text-cyan-300",
												children: "Z"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 321,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 319,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-slate-400 text-[11px]",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Hard Drop" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 324,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("kbd", {
												className: "font-mono bg-slate-800 px-1.5 rounded text-cyan-300",
												children: "Space"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 325,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 323,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex justify-between text-slate-400 text-[11px]",
											children: [/* @__PURE__ */ _jsxDEV("span", { children: "Hold Piece" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 328,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("kbd", {
												className: "font-mono bg-slate-800 px-1.5 rounded text-cyan-300",
												children: "C"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 329,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 327,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 313,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 310,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex lg:hidden items-center justify-between w-full max-w-[320px] mb-2 px-1",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-slate-400",
										children: "HOLD:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 337,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(HoldQueue, {
										holdPiece,
										canHold,
										theme: activeTheme,
										onHoldClick: hold
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 338,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 336,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] font-bold text-slate-400",
										children: "NEXT:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 342,
										columnNumber: 15
									}, this), /* @__PURE__ */ _jsxDEV(NextQueue, {
										queue: nextQueue.slice(0, 1),
										theme: activeTheme
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 343,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 341,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 335,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "relative flex flex-col items-center",
								children: [
									/* @__PURE__ */ _jsxDEV(TetrisBoard, {
										board,
										currentPiece,
										ghostY,
										theme: activeTheme,
										clearingRows,
										popups,
										shake: boardShake
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 349,
										columnNumber: 13
									}, this),
									gameStatus === "idle" && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/75 backdrop-blur-sm rounded-2xl p-6 text-center",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-2xl font-black text-white tracking-wide mb-1",
												children: "READY?"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 362,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-300 max-w-xs mb-5",
												children: "Clear lines, rack up combo chains, and set new high scores."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => startGame(selectedMode),
												className: "flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm shadow-xl shadow-cyan-500/25 active:scale-95 transition-all",
												children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-4 h-4 fill-current" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 370,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "START GAME" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 371,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 366,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 361,
										columnNumber: 15
									}, this),
									gameStatus === "paused" && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/80 backdrop-blur-sm rounded-2xl p-6 text-center",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-2xl font-black text-amber-400 tracking-wider mb-2",
												children: "PAUSED"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 378,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-300 mb-6",
												children: "Press [P] or click Resume to continue"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 379,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col gap-2 w-44",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													onClick: togglePause,
													className: "flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-all active:scale-95",
													children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-4 h-4 fill-current" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 385,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "RESUME" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 386,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 381,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => startGame(selectedMode),
													className: "flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all active:scale-95",
													children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 392,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "RESTART" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 393,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 388,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 380,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 377,
										columnNumber: 15
									}, this),
									gameStatus === "gameover" && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md rounded-2xl p-6 text-center animate-fade-in",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-2xl font-black text-rose-500 tracking-wide mb-1",
												children: "GAME OVER"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 401,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "my-3 p-3 rounded-xl bg-slate-900 border border-slate-800 w-48 text-left space-y-1",
												children: [
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex justify-between text-xs text-slate-400",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "Score:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 404,
															columnNumber: 21
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-mono font-bold text-white tabular-nums",
															children: stats.score.toLocaleString()
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 405,
															columnNumber: 21
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 403,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex justify-between text-xs text-slate-400",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "Lines:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 408,
															columnNumber: 21
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-mono text-cyan-400 tabular-nums",
															children: stats.lines
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 409,
															columnNumber: 21
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 407,
														columnNumber: 19
													}, this),
													/* @__PURE__ */ _jsxDEV("div", {
														className: "flex justify-between text-xs text-slate-400",
														children: [/* @__PURE__ */ _jsxDEV("span", { children: "Max Combo:" }, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 412,
															columnNumber: 21
														}, this), /* @__PURE__ */ _jsxDEV("span", {
															className: "font-mono text-amber-400 tabular-nums",
															children: ["x", stats.maxCombo + 1]
														}, void 0, true, {
															fileName: _jsxFileName,
															lineNumber: 413,
															columnNumber: 21
														}, this)]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 411,
														columnNumber: 19
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 402,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex flex-col gap-2 w-48",
												children: [/* @__PURE__ */ _jsxDEV("button", {
													onClick: () => startGame(selectedMode),
													className: "flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all",
													children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 422,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PLAY AGAIN" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 423,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 418,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("button", {
													onClick: () => setIsHighScoresModalOpen(true),
													className: "flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold",
													children: [/* @__PURE__ */ _jsxDEV(Trophy, { className: "w-3.5 h-3.5 text-amber-400" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 429,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Leaderboard" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 430,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 425,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 417,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 400,
										columnNumber: 15
									}, this),
									gameStatus === "victory" && /* @__PURE__ */ _jsxDEV("div", {
										className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/85 backdrop-blur-md rounded-2xl p-6 text-center animate-fade-in",
										children: [
											/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-10 h-10 text-amber-400 mb-2 animate-bounce" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 438,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-2xl font-black text-amber-400 tracking-wide mb-1",
												children: "VICTORY!"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 439,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-300 max-w-xs mb-3",
												children: selectedMode === "sprint" ? "40 Lines sprint conquered!" : "2-Minute Ultra completed!"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 440,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "my-2 p-3 rounded-xl bg-slate-900 border border-slate-800 w-48 text-left space-y-1",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-xs text-slate-400",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "Final Score:" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 446,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono font-bold text-white tabular-nums",
														children: stats.score.toLocaleString()
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 447,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 445,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "flex justify-between text-xs text-slate-400",
													children: [/* @__PURE__ */ _jsxDEV("span", { children: "Total Time:" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 450,
														columnNumber: 21
													}, this), /* @__PURE__ */ _jsxDEV("span", {
														className: "font-mono text-emerald-400 tabular-nums",
														children: [(stats.elapsedTime / 1e3).toFixed(2), "s"]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 451,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 449,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 444,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												onClick: () => startGame(selectedMode),
												className: "mt-3 flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-lg active:scale-95 transition-all w-48",
												children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-4 h-4" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 461,
													columnNumber: 19
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "PLAY AGAIN" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 462,
													columnNumber: 19
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 457,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 437,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-3 flex items-center gap-2",
										children: [gameStatus === "playing" ? /* @__PURE__ */ _jsxDEV("button", {
											onClick: togglePause,
											className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-slate-300 text-xs font-semibold transition-colors",
											children: [/* @__PURE__ */ _jsxDEV(Pause, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 474,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Pause [P]" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 475,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 470,
											columnNumber: 17
										}, this) : /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => startGame(selectedMode),
											className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-cyan-400 text-xs font-semibold transition-colors",
											children: [/* @__PURE__ */ _jsxDEV(Play, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 482,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Start [R]" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 483,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 478,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => startGame(selectedMode),
											className: "flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white text-xs font-semibold transition-colors",
											title: "Restart Game",
											children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 492,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reset" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 493,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 487,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 468,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col gap-3 w-full lg:w-48 shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "hidden lg:block",
									children: /* @__PURE__ */ _jsxDEV(NextQueue, {
										queue: nextQueue,
										theme: activeTheme
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 501,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 500,
									columnNumber: 13
								}, this), /* @__PURE__ */ _jsxDEV(ScoreBoard, {
									stats,
									gameMode: selectedMode,
									highScores,
									zenSpeed,
									onZenSpeedChange: setZenSpeed
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 504,
									columnNumber: 13
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 499,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 308,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-full lg:hidden mt-3",
						children: /* @__PURE__ */ _jsxDEV(MobileControls, {
							onMoveLeft: () => moveHorizontal(-1),
							onMoveRight: () => moveHorizontal(1),
							onSoftDrop: softDrop,
							onHardDrop: hardDrop,
							onRotateCW: () => rotate(true),
							onRotateCCW: () => rotate(false),
							onHold: hold
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 516,
							columnNumber: 11
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 515,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 252,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(GitHubExportModal, {
				isOpen: isGitHubModalOpen,
				onClose: () => setIsGitHubModalOpen(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 529,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(HighScoresModal, {
				isOpen: isHighScoresModalOpen,
				onClose: () => setIsHighScoresModalOpen(false),
				scores: highScores,
				onClearScores: handleClearScores
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 534,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(KeybindingsModal, {
				isOpen: isControlsModalOpen,
				onClose: () => setIsControlsModalOpen(false),
				keybindings: DEFAULT_KEYBINDINGS
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 541,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 198,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxRQUFRLG1CQUFtQjtBQUNoRSxPQUFPLGNBQWM7QUFDckIsU0FDRSxNQUNBLFdBQ0EsT0FDQSxRQUNBLFVBQ0EsUUFDQSxVQUNBLE9BQ0EsT0FDQSxLQUNBLGNBRUs7QUFHUCxTQUFTLFFBQVEsMkJBQTJCO0FBQzVDLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsaUJBQWlCO0FBQzFCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsdUJBQXVCO0FBQ2hDLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMseUJBQXlCOzs7QUFFbEMsZUFBZSxTQUFTLE1BQU07Q0FDNUIsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQW1CLFVBQVU7Q0FDckUsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBa0IsT0FBTztDQUNyRSxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUFTLEtBQUs7Q0FDaEUsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBUyxLQUFLO0NBQ3hFLE1BQU0sQ0FBQyxxQkFBcUIsMEJBQTBCLFNBQVMsS0FBSztDQUVwRSxNQUFNLGNBQWMsT0FBTztDQUUzQixNQUFNLEVBQ0osT0FDQSxjQUNBLFFBQ0EsV0FDQSxXQUNBLFNBQ0EsWUFDQSxPQUNBLFlBQ0EsY0FDQSxRQUNBLFlBQ0EsVUFDQSxhQUNBLFdBQ0EsYUFDQSxnQkFDQSxVQUNBLFVBQ0EsUUFDQSxTQUNFLFVBQVUsWUFBWTs7Q0FHMUIsZ0JBQWdCO0VBQ2QsSUFBSSxlQUFlLFdBQVc7R0FDNUIsU0FBUztJQUNQLGVBQWU7SUFDZixRQUFRO0lBQ1IsUUFBUSxFQUFFLEdBQUcsR0FBSTtHQUNuQixDQUFDO0VBQ0g7Q0FDRixHQUFHLENBQUMsVUFBVSxDQUFDOztDQUdmLE1BQU0saUJBQWlCLE9BQW9CLElBQUksSUFBSSxDQUFDO0NBQ3BELE1BQU0sY0FBYyxPQUFzQixJQUFJO0NBQzlDLE1BQU0saUJBQWlCLE9BQXNCLElBQUk7Q0FFakQsTUFBTSxnQkFBZ0IsYUFDbkIsTUFBcUI7O0VBRXBCLElBQUk7R0FBQztHQUFTO0dBQVc7R0FBYTtHQUFhO0VBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxJQUFJLEdBQUc7R0FDakYsRUFBRSxlQUFlO0VBQ25CO0VBRUEsSUFBSSxFQUFFLFVBQVU7R0FBQztHQUFTO0dBQVE7R0FBUTtFQUFNLENBQUMsQ0FBQyxTQUFTLEVBQUUsSUFBSSxHQUFHO0dBQ2xFO0VBQ0Y7RUFFQSxNQUFNLE9BQU8sRUFBRTtFQUNmLGVBQWUsUUFBUSxJQUFJLElBQUk7O0VBRy9CLElBQUksb0JBQW9CLE1BQU0sU0FBUyxJQUFJLEdBQUc7R0FDNUMsWUFBWTtHQUNaO0VBQ0Y7RUFDQSxJQUFJLG9CQUFvQixRQUFRLFNBQVMsSUFBSSxHQUFHO0dBQzlDLFVBQVUsWUFBWTtHQUN0QjtFQUNGO0VBRUEsSUFBSSxlQUFlLFdBQVc7O0VBRzlCLElBQUksb0JBQW9CLFNBQVMsU0FBUyxJQUFJLEdBQUc7R0FDL0MsU0FBUztHQUNUO0VBQ0Y7RUFDQSxJQUFJLG9CQUFvQixTQUFTLFNBQVMsSUFBSSxHQUFHO0dBQy9DLE9BQU8sSUFBSTtHQUNYO0VBQ0Y7RUFDQSxJQUFJLG9CQUFvQixVQUFVLFNBQVMsSUFBSSxHQUFHO0dBQ2hELE9BQU8sS0FBSztHQUNaO0VBQ0Y7RUFDQSxJQUFJLG9CQUFvQixLQUFLLFNBQVMsSUFBSSxHQUFHO0dBQzNDLEtBQUs7R0FDTDtFQUNGOztFQUdBLElBQUksb0JBQW9CLFNBQVMsU0FBUyxJQUFJLEdBQUc7R0FDL0MsZUFBZSxDQUFDLENBQUM7R0FDakIsSUFBSSxZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU87R0FDekQsSUFBSSxlQUFlLFNBQVMsY0FBYyxlQUFlLE9BQU87R0FFaEUsWUFBWSxVQUFVLE9BQU8saUJBQWlCO0lBQzVDLGVBQWUsVUFBVSxPQUFPLGtCQUFrQjtLQUNoRCxJQUFJLGVBQWUsUUFBUSxJQUFJLElBQUksR0FBRztNQUNwQyxlQUFlLENBQUMsQ0FBQztLQUNuQjtJQUNGLEdBQUcsRUFBRTtHQUNQLEdBQUcsR0FBRztFQUNSLE9BQU8sSUFBSSxvQkFBb0IsVUFBVSxTQUFTLElBQUksR0FBRztHQUN2RCxlQUFlLENBQUM7R0FDaEIsSUFBSSxZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU87R0FDekQsSUFBSSxlQUFlLFNBQVMsY0FBYyxlQUFlLE9BQU87R0FFaEUsWUFBWSxVQUFVLE9BQU8saUJBQWlCO0lBQzVDLGVBQWUsVUFBVSxPQUFPLGtCQUFrQjtLQUNoRCxJQUFJLGVBQWUsUUFBUSxJQUFJLElBQUksR0FBRztNQUNwQyxlQUFlLENBQUM7S0FDbEI7SUFDRixHQUFHLEVBQUU7R0FDUCxHQUFHLEdBQUc7RUFDUixPQUFPLElBQUksb0JBQW9CLFNBQVMsU0FBUyxJQUFJLEdBQUc7R0FDdEQsU0FBUztFQUNYO0NBQ0YsR0FDQTtFQUFDO0VBQVk7RUFBVTtFQUFNO0VBQWdCO0VBQVE7RUFBYztFQUFVO0VBQVc7Q0FBVyxDQUNyRztDQUVBLE1BQU0sY0FBYyxhQUFhLE1BQXFCO0VBQ3BELGVBQWUsUUFBUSxPQUFPLEVBQUUsSUFBSTtFQUVwQyxNQUFNLGlCQUFpQixvQkFBb0IsU0FBUyxTQUFTLEVBQUUsSUFBSTtFQUNuRSxNQUFNLGtCQUFrQixvQkFBb0IsVUFBVSxTQUFTLEVBQUUsSUFBSTtFQUVyRSxJQUFJLGtCQUFrQixpQkFBaUI7R0FDckMsSUFBSSxZQUFZLFNBQVM7SUFDdkIsYUFBYSxZQUFZLE9BQU87SUFDaEMsWUFBWSxVQUFVO0dBQ3hCO0dBQ0EsSUFBSSxlQUFlLFNBQVM7SUFDMUIsY0FBYyxlQUFlLE9BQU87SUFDcEMsZUFBZSxVQUFVO0dBQzNCO0VBQ0Y7Q0FDRixHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUNkLE9BQU8saUJBQWlCLFdBQVcsYUFBYTtFQUNoRCxPQUFPLGlCQUFpQixTQUFTLFdBQVc7RUFDNUMsYUFBYTtHQUNYLE9BQU8sb0JBQW9CLFdBQVcsYUFBYTtHQUNuRCxPQUFPLG9CQUFvQixTQUFTLFdBQVc7R0FDL0MsSUFBSSxZQUFZLFNBQVMsYUFBYSxZQUFZLE9BQU87R0FDekQsSUFBSSxlQUFlLFNBQVMsY0FBYyxlQUFlLE9BQU87RUFDbEU7Q0FDRixHQUFHLENBQUMsZUFBZSxXQUFXLENBQUM7O0NBRy9CLE1BQU0sb0JBQW9CLFNBQW1CO0VBQzNDLGdCQUFnQixJQUFJO0VBQ3BCLFVBQVUsSUFBSTtDQUNoQjtDQUVBLE1BQU0sMEJBQTBCO0VBQzlCLGFBQWEsV0FBVyxvQkFBb0I7RUFDNUMsT0FBTyxTQUFTLE9BQU87Q0FDekI7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFXLGlDQUFpQyxZQUFZLFdBQVc7WUFEckU7R0FJRSx3QkFBQyxVQUFEO0lBQVEsV0FBVTtjQUFsQjtLQUVFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXFFO01BRS9FOzs7O2dCQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUF1STtNQUVqSjs7OztjQUNIOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLHVCQUF1QixJQUFJO1FBQzFDLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2tCQUFDLFVBRTFCOzs7Ozs7T0FDUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSx5QkFBeUIsSUFBSTtRQUM1QyxXQUFVO2tCQUZaLENBSUUsd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7OztrQkFBQyxhQUV4Qjs7Ozs7O09BQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUscUJBQXFCLElBQUk7UUFDeEMsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLFVBQVc7Ozs7a0JBQUMsY0FFeEI7Ozs7OztNQUNMOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7Z0JBQ2hCLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLHFCQUFxQixJQUFJO09BQ3hDLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2lCQUNqQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2VBQ3RCOzs7OztjQUNMOzs7Ozs7SUFDQzs7Ozs7O0dBR1Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FFRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsVUFBRDtTQUNFLGVBQWUsaUJBQWlCLFVBQVU7U0FDMUMsV0FBVywrRUFDVCxpQkFBaUIsYUFDYixtRUFDQTttQkFMUixDQVFFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLGNBQWU7Ozs7bUJBQUMsVUFFM0I7Ozs7OztRQUNSLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGlCQUFpQixRQUFRO1NBQ3hDLFdBQVcsK0VBQ1QsaUJBQWlCLFdBQ2IseUVBQ0E7bUJBTFIsQ0FRRSx3QkFBQyxLQUFELEVBQUssV0FBVSxjQUFlOzs7O21CQUFDLGNBRXpCOzs7Ozs7UUFDUix3QkFBQyxVQUFEO1NBQ0UsZUFBZSxpQkFBaUIsT0FBTztTQUN2QyxXQUFXLCtFQUNULGlCQUFpQixVQUNiLG1FQUNBO21CQUxSLENBUUUsd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OzttQkFBQyxZQUUzQjs7Ozs7O1FBQ1Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsaUJBQWlCLEtBQUs7U0FDckMsV0FBVywrRUFDVCxpQkFBaUIsUUFDYix1RUFDQTttQkFMUixDQVFFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLGNBQWU7Ozs7bUJBQUMsS0FFNUI7Ozs7OztPQUNMOzs7OztnQkFHTCx3QkFBQyxlQUFEO09BQStCO09BQWdCLGVBQWU7TUFBb0I7Ozs7Y0FDL0U7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxXQUFEO1NBQXNCO1NBQW9CO1NBQVMsT0FBTztTQUFhLGFBQWE7UUFBTzs7OztrQkFFM0Ysd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUM7VUFBbUI7Ozs7O1VBQ3BFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7cUJBQ3JCLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFzRDtXQUFVOzs7O21CQUM1RTs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7cUJBQ3RCLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFzRDtXQUFNOzs7O21CQUN4RTs7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztxQkFDckIsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXNEO1dBQVU7Ozs7bUJBQzVFOzs7Ozs7VUFDTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztxQkFDdEIsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQXNEO1dBQU07Ozs7bUJBQ3hFOzs7Ozs7U0FDRjs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUM7U0FBVzs7OzttQkFDbEUsd0JBQUMsV0FBRDtVQUFzQjtVQUFvQjtVQUFTLE9BQU87VUFBYSxhQUFhO1NBQU87Ozs7aUJBQ3hGOzs7OztrQkFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF1QztTQUFXOzs7O21CQUNsRSx3QkFBQyxXQUFEO1VBQVcsT0FBTyxVQUFVLE1BQU0sR0FBRyxDQUFDO1VBQUcsT0FBTztTQUFjOzs7O2lCQUMzRDs7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsYUFBRDtVQUNTO1VBQ087VUFDTjtVQUNSLE9BQU87VUFDTztVQUNOO1VBQ1IsT0FBTztTQUNSOzs7OztTQUdBLGVBQWUsVUFDZCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFvRDtXQUFZOzs7OztXQUNoRix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBdUM7V0FFakQ7Ozs7O1dBQ0gsd0JBQUMsVUFBRDtZQUNFLGVBQWUsVUFBVSxZQUFZO1lBQ3JDLFdBQVU7c0JBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSx1QkFBd0I7Ozs7c0JBQ3hDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDaEI7Ozs7OztVQUNMOzs7Ozs7U0FHTixlQUFlLFlBQ2Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBeUQ7V0FBWTs7Ozs7V0FDckYsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQThCO1dBQXdDOzs7OztXQUNuRix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFVBQUQ7YUFDRSxTQUFTO2FBQ1QsV0FBVTt1QkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLHVCQUF3Qjs7Ozt1QkFDeEMsd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7cUJBQ1o7Ozs7O3NCQUNSLHdCQUFDLFVBQUQ7YUFDRSxlQUFlLFVBQVUsWUFBWTthQUNyQyxXQUFVO3VCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozt1QkFDaEMsd0JBQUMsUUFBRCxZQUFNLFVBQWE7Ozs7cUJBQ2I7Ozs7O29CQUNMOzs7Ozs7VUFDRjs7Ozs7O1NBR04sZUFBZSxjQUNkLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXVEO1dBQWU7Ozs7O1dBQ3RGLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sU0FBWTs7Ozt3QkFDbEIsd0JBQUMsUUFBRDtlQUFNLFdBQVU7eUJBQStDLE1BQU0sTUFBTSxlQUFlO2NBQVE7Ozs7c0JBQy9GOzs7Ozs7YUFDTCx3QkFBQyxPQUFEO2NBQUssV0FBVTt3QkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxTQUFZOzs7O3dCQUNsQix3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBd0MsTUFBTTtjQUFZOzs7O3NCQUN2RTs7Ozs7O2FBQ0wsd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sYUFBZ0I7Ozs7d0JBQ3RCLHdCQUFDLFFBQUQ7ZUFBTSxXQUFVO3lCQUFoQixDQUF3RCxLQUFFLE1BQU0sV0FBVyxDQUFROzs7OztzQkFDaEY7Ozs7OztZQUNGOzs7Ozs7V0FFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFVBQUQ7YUFDRSxlQUFlLFVBQVUsWUFBWTthQUNyQyxXQUFVO3VCQUZaLENBSUUsd0JBQUMsV0FBRCxFQUFXLFdBQVUsVUFBVzs7Ozt1QkFDaEMsd0JBQUMsUUFBRCxZQUFNLGFBQWdCOzs7O3FCQUNoQjs7Ozs7c0JBQ1Isd0JBQUMsVUFBRDthQUNFLGVBQWUseUJBQXlCLElBQUk7YUFDNUMsV0FBVTt1QkFGWixDQUlFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDZCQUE4Qjs7Ozt1QkFDaEQsd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O3FCQUNqQjs7Ozs7b0JBQ0w7Ozs7OztVQUNGOzs7Ozs7U0FHTixlQUFlLGFBQ2Qsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwrQ0FBZ0Q7Ozs7O1dBQ3BFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUF3RDtXQUFjOzs7OztXQUN0Rix3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFDVixpQkFBaUIsV0FBVywrQkFBK0I7V0FDM0Q7Ozs7O1dBRUgsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxlQUFrQjs7Ozt1QkFDeEIsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQStDLE1BQU0sTUFBTSxlQUFlO2FBQVE7Ozs7cUJBQy9GOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7Ozt1QkFDdkIsd0JBQUMsUUFBRDtjQUFNLFdBQVU7d0JBQWhCLEVBQ0ksTUFBTSxjQUFjLElBQUksQ0FBRSxRQUFRLENBQUMsR0FBRSxHQUNuQzs7Ozs7cUJBQ0g7Ozs7O29CQUNGOzs7Ozs7V0FFTCx3QkFBQyxVQUFEO1lBQ0UsZUFBZSxVQUFVLFlBQVk7WUFDckMsV0FBVTtzQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7c0JBQ2hDLHdCQUFDLFFBQUQsWUFBTSxhQUFnQjs7OztvQkFDaEI7Ozs7OztVQUNMOzs7Ozs7U0FJUCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNHLGVBQWUsWUFDZCx3QkFBQyxVQUFEO1dBQ0UsU0FBUztXQUNULFdBQVU7cUJBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxjQUFlOzs7O3FCQUNoQyx3QkFBQyxRQUFELFlBQU0sWUFBZTs7OzttQkFDZjs7Ozs7cUJBRVIsd0JBQUMsVUFBRDtXQUNFLGVBQWUsVUFBVSxZQUFZO1dBQ3JDLFdBQVU7cUJBRlosQ0FJRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O3FCQUMvQix3QkFBQyxRQUFELFlBQU0sWUFBZTs7OzttQkFDZjs7Ozs7b0JBR1Ysd0JBQUMsVUFBRDtXQUNFLGVBQWUsVUFBVSxZQUFZO1dBQ3JDLFdBQVU7V0FDVixPQUFNO3FCQUhSLENBS0Usd0JBQUMsV0FBRCxFQUFXLFdBQVUsY0FBZTs7OztxQkFDcEMsd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7bUJBQ1g7Ozs7O2tCQUNMOzs7Ozs7UUFDRjs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxXQUFEO1VBQVcsT0FBTztVQUFXLE9BQU87U0FBYzs7Ozs7UUFDL0M7Ozs7a0JBRUwsd0JBQUMsWUFBRDtTQUNTO1NBQ1AsVUFBVTtTQUNFO1NBQ0Y7U0FDVixrQkFBa0I7UUFDbkI7Ozs7Z0JBQ0U7Ozs7OztNQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDYix3QkFBQyxnQkFBRDtPQUNFLGtCQUFrQixlQUFlLENBQUMsQ0FBQztPQUNuQyxtQkFBbUIsZUFBZSxDQUFDO09BQ25DLFlBQVk7T0FDWixZQUFZO09BQ1osa0JBQWtCLE9BQU8sSUFBSTtPQUM3QixtQkFBbUIsT0FBTyxLQUFLO09BQy9CLFFBQVE7TUFDVDs7Ozs7S0FDRTs7Ozs7SUFDRDs7Ozs7O0dBR04sd0JBQUMsbUJBQUQ7SUFDRSxRQUFRO0lBQ1IsZUFBZSxxQkFBcUIsS0FBSztHQUMxQzs7Ozs7R0FFRCx3QkFBQyxpQkFBRDtJQUNFLFFBQVE7SUFDUixlQUFlLHlCQUF5QixLQUFLO0lBQzdDLFFBQVE7SUFDUixlQUFlO0dBQ2hCOzs7OztHQUVELHdCQUFDLGtCQUFEO0lBQ0UsUUFBUTtJQUNSLGVBQWUsdUJBQXVCLEtBQUs7SUFDM0MsYUFBYTtHQUNkOzs7OztFQUNFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNvbmZldHRpIGZyb20gJ2NhbnZhcy1jb25mZXR0aSc7XG5pbXBvcnQge1xuICBQbGF5LFxuICBSb3RhdGVDY3csXG4gIFBhdXNlLFxuICBUcm9waHksXG4gIEtleWJvYXJkLFxuICBHaXRodWIsXG4gIFNwYXJrbGVzLFxuICBGbGFtZSxcbiAgQ2xvY2ssXG4gIFphcCxcbiAgQ29mZmVlLFxuICBWb2x1bWUyLFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbXBvcnQgeyBHYW1lTW9kZSwgVGhlbWVJZCB9IGZyb20gJy4vdHlwZXMvdGV0cmlzJztcbmltcG9ydCB7IFRIRU1FUywgREVGQVVMVF9LRVlCSU5ESU5HUyB9IGZyb20gJy4vdXRpbHMvdGV0cmlzQ29uc3RhbnRzJztcbmltcG9ydCB7IHVzZVRldHJpcyB9IGZyb20gJy4vaG9va3MvdXNlVGV0cmlzJztcbmltcG9ydCB7IFRldHJpc0JvYXJkIH0gZnJvbSAnLi9jb21wb25lbnRzL1RldHJpc0JvYXJkJztcbmltcG9ydCB7IEhvbGRRdWV1ZSB9IGZyb20gJy4vY29tcG9uZW50cy9Ib2xkUXVldWUnO1xuaW1wb3J0IHsgTmV4dFF1ZXVlIH0gZnJvbSAnLi9jb21wb25lbnRzL05leHRRdWV1ZSc7XG5pbXBvcnQgeyBTY29yZUJvYXJkIH0gZnJvbSAnLi9jb21wb25lbnRzL1Njb3JlQm9hcmQnO1xuaW1wb3J0IHsgU291bmRDb250cm9scyB9IGZyb20gJy4vY29tcG9uZW50cy9Tb3VuZENvbnRyb2xzJztcbmltcG9ydCB7IFRoZW1lU2VsZWN0b3IgfSBmcm9tICcuL2NvbXBvbmVudHMvVGhlbWVTZWxlY3Rvcic7XG5pbXBvcnQgeyBNb2JpbGVDb250cm9scyB9IGZyb20gJy4vY29tcG9uZW50cy9Nb2JpbGVDb250cm9scyc7XG5pbXBvcnQgeyBIaWdoU2NvcmVzTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvSGlnaFNjb3Jlc01vZGFsJztcbmltcG9ydCB7IEtleWJpbmRpbmdzTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvS2V5YmluZGluZ3NNb2RhbCc7XG5pbXBvcnQgeyBHaXRIdWJFeHBvcnRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9HaXRIdWJFeHBvcnRNb2RhbCc7XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgY29uc3QgW3NlbGVjdGVkTW9kZSwgc2V0U2VsZWN0ZWRNb2RlXSA9IHVzZVN0YXRlPEdhbWVNb2RlPignbWFyYXRob24nKTtcbiAgY29uc3QgW2N1cnJlbnRUaGVtZUlkLCBzZXRDdXJyZW50VGhlbWVJZF0gPSB1c2VTdGF0ZTxUaGVtZUlkPignY3liZXInKTtcbiAgY29uc3QgW2lzR2l0SHViTW9kYWxPcGVuLCBzZXRJc0dpdEh1Yk1vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0hpZ2hTY29yZXNNb2RhbE9wZW4sIHNldElzSGlnaFNjb3Jlc01vZGFsT3Blbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtpc0NvbnRyb2xzTW9kYWxPcGVuLCBzZXRJc0NvbnRyb2xzTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBjb25zdCBhY3RpdmVUaGVtZSA9IFRIRU1FU1tjdXJyZW50VGhlbWVJZF07XG5cbiAgY29uc3Qge1xuICAgIGJvYXJkLFxuICAgIGN1cnJlbnRQaWVjZSxcbiAgICBnaG9zdFksXG4gICAgbmV4dFF1ZXVlLFxuICAgIGhvbGRQaWVjZSxcbiAgICBjYW5Ib2xkLFxuICAgIGdhbWVTdGF0dXMsXG4gICAgc3RhdHMsXG4gICAgaGlnaFNjb3JlcyxcbiAgICBjbGVhcmluZ1Jvd3MsXG4gICAgcG9wdXBzLFxuICAgIGJvYXJkU2hha2UsXG4gICAgemVuU3BlZWQsXG4gICAgc2V0WmVuU3BlZWQsXG4gICAgc3RhcnRHYW1lLFxuICAgIHRvZ2dsZVBhdXNlLFxuICAgIG1vdmVIb3Jpem9udGFsLFxuICAgIHNvZnREcm9wLFxuICAgIGhhcmREcm9wLFxuICAgIHJvdGF0ZSxcbiAgICBob2xkLFxuICB9ID0gdXNlVGV0cmlzKHNlbGVjdGVkTW9kZSk7XG5cbiAgLy8gVHJpZ2dlciBjb25mZXR0aSBvbiB2aWN0b3J5IChlLmcuIFNwcmludCBjb21wbGV0ZWQgb3IgVWx0cmEgZmluaXNoZWQpXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGdhbWVTdGF0dXMgPT09ICd2aWN0b3J5Jykge1xuICAgICAgY29uZmV0dGkoe1xuICAgICAgICBwYXJ0aWNsZUNvdW50OiAxMDAsXG4gICAgICAgIHNwcmVhZDogNzAsXG4gICAgICAgIG9yaWdpbjogeyB5OiAwLjYgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW2dhbWVTdGF0dXNdKTtcblxuICAvLyBLZXlib2FyZCBFdmVudCBNYW5hZ2VtZW50IHdpdGggREFTICYgQVJSXG4gIGNvbnN0IGtleXNQcmVzc2VkUmVmID0gdXNlUmVmPFNldDxzdHJpbmc+PihuZXcgU2V0KCkpO1xuICBjb25zdCBkYXNUaW1lclJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKTtcbiAgY29uc3QgYXJySW50ZXJ2YWxSZWYgPSB1c2VSZWY8bnVtYmVyIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgaGFuZGxlS2V5RG93biA9IHVzZUNhbGxiYWNrKFxuICAgIChlOiBLZXlib2FyZEV2ZW50KSA9PiB7XG4gICAgICAvLyBQcmV2ZW50IGJyb3dzZXIgc2Nyb2xsIG9uIGdhbWUga2V5c1xuICAgICAgaWYgKFsnU3BhY2UnLCAnQXJyb3dVcCcsICdBcnJvd0Rvd24nLCAnQXJyb3dMZWZ0JywgJ0Fycm93UmlnaHQnXS5pbmNsdWRlcyhlLmNvZGUpKSB7XG4gICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKGUucmVwZWF0ICYmIFsnU3BhY2UnLCAnS2V5QycsICdLZXlQJywgJ0tleVInXS5pbmNsdWRlcyhlLmNvZGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgY29uc3QgY29kZSA9IGUuY29kZTtcbiAgICAgIGtleXNQcmVzc2VkUmVmLmN1cnJlbnQuYWRkKGNvZGUpO1xuXG4gICAgICAvLyBHbG9iYWwgY29udHJvbCBzaG9ydGN1dHNcbiAgICAgIGlmIChERUZBVUxUX0tFWUJJTkRJTkdTLnBhdXNlLmluY2x1ZGVzKGNvZGUpKSB7XG4gICAgICAgIHRvZ2dsZVBhdXNlKCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChERUZBVUxUX0tFWUJJTkRJTkdTLnJlc3RhcnQuaW5jbHVkZXMoY29kZSkpIHtcbiAgICAgICAgc3RhcnRHYW1lKHNlbGVjdGVkTW9kZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgaWYgKGdhbWVTdGF0dXMgIT09ICdwbGF5aW5nJykgcmV0dXJuO1xuXG4gICAgICAvLyBTaW5nbGUgYWN0aW9uIHRyaWdnZXJzXG4gICAgICBpZiAoREVGQVVMVF9LRVlCSU5ESU5HUy5oYXJkRHJvcC5pbmNsdWRlcyhjb2RlKSkge1xuICAgICAgICBoYXJkRHJvcCgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoREVGQVVMVF9LRVlCSU5ESU5HUy5yb3RhdGVDVy5pbmNsdWRlcyhjb2RlKSkge1xuICAgICAgICByb3RhdGUodHJ1ZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChERUZBVUxUX0tFWUJJTkRJTkdTLnJvdGF0ZUNDVy5pbmNsdWRlcyhjb2RlKSkge1xuICAgICAgICByb3RhdGUoZmFsc2UpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoREVGQVVMVF9LRVlCSU5ESU5HUy5ob2xkLmluY2x1ZGVzKGNvZGUpKSB7XG4gICAgICAgIGhvbGQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBNb3ZlbWVudCB3aXRoIERBUyAoRGVsYXllZCBBdXRvIFNoaWZ0KVxuICAgICAgaWYgKERFRkFVTFRfS0VZQklORElOR1MubW92ZUxlZnQuaW5jbHVkZXMoY29kZSkpIHtcbiAgICAgICAgbW92ZUhvcml6b250YWwoLTEpO1xuICAgICAgICBpZiAoZGFzVGltZXJSZWYuY3VycmVudCkgY2xlYXJUaW1lb3V0KGRhc1RpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICBpZiAoYXJySW50ZXJ2YWxSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbChhcnJJbnRlcnZhbFJlZi5jdXJyZW50KTtcblxuICAgICAgICBkYXNUaW1lclJlZi5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGFyckludGVydmFsUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGtleXNQcmVzc2VkUmVmLmN1cnJlbnQuaGFzKGNvZGUpKSB7XG4gICAgICAgICAgICAgIG1vdmVIb3Jpem9udGFsKC0xKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LCAzNSk7XG4gICAgICAgIH0sIDE1MCk7XG4gICAgICB9IGVsc2UgaWYgKERFRkFVTFRfS0VZQklORElOR1MubW92ZVJpZ2h0LmluY2x1ZGVzKGNvZGUpKSB7XG4gICAgICAgIG1vdmVIb3Jpem9udGFsKDEpO1xuICAgICAgICBpZiAoZGFzVGltZXJSZWYuY3VycmVudCkgY2xlYXJUaW1lb3V0KGRhc1RpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgICBpZiAoYXJySW50ZXJ2YWxSZWYuY3VycmVudCkgY2xlYXJJbnRlcnZhbChhcnJJbnRlcnZhbFJlZi5jdXJyZW50KTtcblxuICAgICAgICBkYXNUaW1lclJlZi5jdXJyZW50ID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIGFyckludGVydmFsUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKGtleXNQcmVzc2VkUmVmLmN1cnJlbnQuaGFzKGNvZGUpKSB7XG4gICAgICAgICAgICAgIG1vdmVIb3Jpem9udGFsKDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sIDM1KTtcbiAgICAgICAgfSwgMTUwKTtcbiAgICAgIH0gZWxzZSBpZiAoREVGQVVMVF9LRVlCSU5ESU5HUy5zb2Z0RHJvcC5pbmNsdWRlcyhjb2RlKSkge1xuICAgICAgICBzb2Z0RHJvcCgpO1xuICAgICAgfVxuICAgIH0sXG4gICAgW2dhbWVTdGF0dXMsIGhhcmREcm9wLCBob2xkLCBtb3ZlSG9yaXpvbnRhbCwgcm90YXRlLCBzZWxlY3RlZE1vZGUsIHNvZnREcm9wLCBzdGFydEdhbWUsIHRvZ2dsZVBhdXNlXVxuICApO1xuXG4gIGNvbnN0IGhhbmRsZUtleVVwID0gdXNlQ2FsbGJhY2soKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICBrZXlzUHJlc3NlZFJlZi5jdXJyZW50LmRlbGV0ZShlLmNvZGUpO1xuXG4gICAgY29uc3QgaXNMZWZ0UmVsZWFzZWQgPSBERUZBVUxUX0tFWUJJTkRJTkdTLm1vdmVMZWZ0LmluY2x1ZGVzKGUuY29kZSk7XG4gICAgY29uc3QgaXNSaWdodFJlbGVhc2VkID0gREVGQVVMVF9LRVlCSU5ESU5HUy5tb3ZlUmlnaHQuaW5jbHVkZXMoZS5jb2RlKTtcblxuICAgIGlmIChpc0xlZnRSZWxlYXNlZCB8fCBpc1JpZ2h0UmVsZWFzZWQpIHtcbiAgICAgIGlmIChkYXNUaW1lclJlZi5jdXJyZW50KSB7XG4gICAgICAgIGNsZWFyVGltZW91dChkYXNUaW1lclJlZi5jdXJyZW50KTtcbiAgICAgICAgZGFzVGltZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgICBpZiAoYXJySW50ZXJ2YWxSZWYuY3VycmVudCkge1xuICAgICAgICBjbGVhckludGVydmFsKGFyckludGVydmFsUmVmLmN1cnJlbnQpO1xuICAgICAgICBhcnJJbnRlcnZhbFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICB9XG4gIH0sIFtdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdrZXlkb3duJywgaGFuZGxlS2V5RG93bik7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ2tleXVwJywgaGFuZGxlS2V5VXApO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigna2V5ZG93bicsIGhhbmRsZUtleURvd24pO1xuICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2tleXVwJywgaGFuZGxlS2V5VXApO1xuICAgICAgaWYgKGRhc1RpbWVyUmVmLmN1cnJlbnQpIGNsZWFyVGltZW91dChkYXNUaW1lclJlZi5jdXJyZW50KTtcbiAgICAgIGlmIChhcnJJbnRlcnZhbFJlZi5jdXJyZW50KSBjbGVhckludGVydmFsKGFyckludGVydmFsUmVmLmN1cnJlbnQpO1xuICAgIH07XG4gIH0sIFtoYW5kbGVLZXlEb3duLCBoYW5kbGVLZXlVcF0pO1xuXG4gIC8vIE1vZGUgU2VsZWN0aW9uIEhhbmRsZXJcbiAgY29uc3QgaGFuZGxlU2VsZWN0TW9kZSA9IChtb2RlOiBHYW1lTW9kZSkgPT4ge1xuICAgIHNldFNlbGVjdGVkTW9kZShtb2RlKTtcbiAgICBzdGFydEdhbWUobW9kZSk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ2xlYXJTY29yZXMgPSAoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ3RldHJpc19oaWdoX3Njb3JlcycpO1xuICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YG1pbi1oLXNjcmVlbiBiZy1ncmFkaWVudC10by1iICR7YWN0aXZlVGhlbWUuYmFja2dyb3VuZH0gdGV4dC1zbGF0ZS0xMDAgZmxleCBmbGV4LWNvbCBzZWxlY3Rpb246YmctY3lhbi01MDAvMzAgZm9udC1zYW5zYH1cbiAgICA+XG4gICAgICB7LyogVW5pdmVyc2FsIFRvcCBCYXIgQ29udHJhY3Q6IFpvbmUgMSAoV29yZG1hcmspIC0gWm9uZSAyIChOYXYgTGlua3MpIC0gWm9uZSAzICgxIFByaW1hcnkgQ1RBKSAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC04IHB4LTYgcHktMy41IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAvODAgYmctc2xhdGUtOTUwLzQwIGJhY2tkcm9wLWJsdXItbWQgc3RpY2t5IHRvcC0wIHotNDBcIj5cbiAgICAgICAgey8qIFpvbmUgMTogQnJhbmQgV29yZG1hcmsgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgc2hyaW5rLTBcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXRpZ2h0IHRleHQtd2hpdGUgd2hpdGVzcGFjZS1ub3dyYXBcIj5cbiAgICAgICAgICAgIFRldHJpcyBQcm8gQXJjYWRlXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmUtYmxvY2sgdGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtY3lhbi00MDAgZm9udC1ib2xkIGJnLWN5YW4tOTUwLzYwIGJvcmRlciBib3JkZXItY3lhbi04MDAvNjAgcHgtMiBweS0wLjUgcm91bmRlZC1tZFwiPlxuICAgICAgICAgICAgU1JTIHYyLjRcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBab25lIDI6IE5hdmlnYXRpb24gTGlua3MgKi99XG4gICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmZsZXggaXRlbXMtY2VudGVyIGdhcC02IHRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0NvbnRyb2xzTW9kYWxPcGVuKHRydWUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9ycyB3aGl0ZXNwYWNlLW5vd3JhcCBzaHJpbmstMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICBDb250cm9sc1xuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzSGlnaFNjb3Jlc01vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImhvdmVyOnRleHQtd2hpdGUgdHJhbnNpdGlvbi1jb2xvcnMgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFRyb3BoeSBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIExlYWRlcmJvYXJkXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNHaXRIdWJNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJob3Zlcjp0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzIHdoaXRlc3BhY2Utbm93cmFwIHNocmluay0wIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1jeWFuLTQwMFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEdpdGh1YiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIEdpdEh1YiBHdWlkZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L25hdj5cblxuICAgICAgICB7LyogWm9uZSAzOiBQcmltYXJ5IEFjdGlvbiAmIEF1ZGlvIGNvbnRyb2xzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zIHNocmluay0wXCI+XG4gICAgICAgICAgPFNvdW5kQ29udHJvbHMgLz5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0dpdEh1Yk1vZGFsT3Blbih0cnVlKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1jeWFuLTYwMCB0by1ibHVlLTYwMCBob3Zlcjpmcm9tLWN5YW4tNTAwIGhvdmVyOnRvLWJsdWUtNTAwIHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgc2hhZG93LW1kIHNoYWRvdy1jeWFuLTYwMC8yMCBhY3RpdmU6c2NhbGUtOTUgd2hpdGVzcGFjZS1ub3dyYXAgc2hyaW5rLTBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxHaXRodWIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+RXhwb3J0IHRvIEdpdEh1Yjwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2hlYWRlcj5cblxuICAgICAgey8qIE1haW4gQ29udGFpbmVyICovfVxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiZmxleC0xIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktc3RhcnQgcC0zIG1kOnAtNiBtYXgtdy02eGwgdy1mdWxsIG14LWF1dG9cIj5cbiAgICAgICAgey8qIEdhbWUgTW9kZSBCYXIgJiBUaGVtZSBTZWxlY3RvciBUb29sYmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIG1iLTQgcGItMyBib3JkZXItYiBib3JkZXItc2xhdGUtODAwLzYwXCI+XG4gICAgICAgICAgey8qIE1vZGUgU2VsZWN0b3IgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHAtMSBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bCB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdE1vZGUoJ21hcmF0aG9uJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIHNlbGVjdGVkTW9kZSA9PT0gJ21hcmF0aG9uJ1xuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtODAwIHRleHQtY3lhbi0zMDAgc2hhZG93LXNtIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPEZsYW1lIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgTWFyYXRob25cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZWxlY3RNb2RlKCdzcHJpbnQnKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGZvbnQtbWVkaXVtIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgc2VsZWN0ZWRNb2RlID09PSAnc3ByaW50J1xuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtODAwIHRleHQtZW1lcmFsZC0zMDAgc2hhZG93LXNtIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIFNwcmludCAoNDBMKVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdE1vZGUoJ3VsdHJhJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC1sZyBmb250LW1lZGl1bSB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIHNlbGVjdGVkTW9kZSA9PT0gJ3VsdHJhJ1xuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtODAwIHRleHQtcm9zZS0zMDAgc2hhZG93LXNtIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENsb2NrIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgVWx0cmEgKDJtKVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlbGVjdE1vZGUoJ3plbicpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBzZWxlY3RlZE1vZGUgPT09ICd6ZW4nXG4gICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS04MDAgdGV4dC1wdXJwbGUtMzAwIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvMzAnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPENvZmZlZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgIFplblxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGhlbWUgU2VsZWN0b3IgKi99XG4gICAgICAgICAgPFRoZW1lU2VsZWN0b3IgY3VycmVudFRoZW1lSWQ9e2N1cnJlbnRUaGVtZUlkfSBvblNlbGVjdFRoZW1lPXtzZXRDdXJyZW50VGhlbWVJZH0gLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEdhbWUgQXJlbmEgTGF5b3V0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBmbGV4IGZsZXgtY29sIGxnOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBsZzppdGVtcy1zdGFydCBqdXN0aWZ5LWNlbnRlciBnYXAtNCBtZDpnYXAtOFwiPlxuICAgICAgICAgIHsvKiBMZWZ0IFdpbmc6IEhvbGQgUXVldWUgJiBDb250cm9scyBRdWljayBUaXAgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJoaWRkZW4gbGc6ZmxleCBmbGV4LWNvbCBnYXAtNCB3LTQwIHNocmluay0wXCI+XG4gICAgICAgICAgICA8SG9sZFF1ZXVlIGhvbGRQaWVjZT17aG9sZFBpZWNlfSBjYW5Ib2xkPXtjYW5Ib2xkfSB0aGVtZT17YWN0aXZlVGhlbWV9IG9uSG9sZENsaWNrPXtob2xkfSAvPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMy41IHJvdW5kZWQtMnhsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBiYWNrZHJvcC1ibHVyLW1kIHNoYWRvdy1sZyB0ZXh0LXhzIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYmxvY2tcIj5LRVkgU0hPUlRDVVRTPC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+Um90YXRlIENXPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxrYmQgY2xhc3NOYW1lPVwiZm9udC1tb25vIGJnLXNsYXRlLTgwMCBweC0xLjUgcm91bmRlZCB0ZXh0LWN5YW4tMzAwXCI+4oaRIC8gWDwva2JkPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuPlJvdGF0ZSBDQ1c8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGtiZCBjbGFzc05hbWU9XCJmb250LW1vbm8gYmctc2xhdGUtODAwIHB4LTEuNSByb3VuZGVkIHRleHQtY3lhbi0zMDBcIj5aPC9rYmQ+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+SGFyZCBEcm9wPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxrYmQgY2xhc3NOYW1lPVwiZm9udC1tb25vIGJnLXNsYXRlLTgwMCBweC0xLjUgcm91bmRlZCB0ZXh0LWN5YW4tMzAwXCI+U3BhY2U8L2tiZD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS00MDAgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Ib2xkIFBpZWNlPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxrYmQgY2xhc3NOYW1lPVwiZm9udC1tb25vIGJnLXNsYXRlLTgwMCBweC0xLjUgcm91bmRlZCB0ZXh0LWN5YW4tMzAwXCI+Qzwva2JkPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIE1vYmlsZSBUb3AgUm93OiBDb21wYWN0IEhvbGQgJiBOZXh0IGZvciBTbWFsbCBTY3JlZW5zICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBsZzpoaWRkZW4gaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB3LWZ1bGwgbWF4LXctWzMyMHB4XSBtYi0yIHB4LTFcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwXCI+SE9MRDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxIb2xkUXVldWUgaG9sZFBpZWNlPXtob2xkUGllY2V9IGNhbkhvbGQ9e2NhbkhvbGR9IHRoZW1lPXthY3RpdmVUaGVtZX0gb25Ib2xkQ2xpY2s9e2hvbGR9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDBcIj5ORVhUOjwvc3Bhbj5cbiAgICAgICAgICAgICAgPE5leHRRdWV1ZSBxdWV1ZT17bmV4dFF1ZXVlLnNsaWNlKDAsIDEpfSB0aGVtZT17YWN0aXZlVGhlbWV9IC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBDZW50ZXIgQXJlbmE6IDEweDIwIE1hdHJpeCAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICA8VGV0cmlzQm9hcmRcbiAgICAgICAgICAgICAgYm9hcmQ9e2JvYXJkfVxuICAgICAgICAgICAgICBjdXJyZW50UGllY2U9e2N1cnJlbnRQaWVjZX1cbiAgICAgICAgICAgICAgZ2hvc3RZPXtnaG9zdFl9XG4gICAgICAgICAgICAgIHRoZW1lPXthY3RpdmVUaGVtZX1cbiAgICAgICAgICAgICAgY2xlYXJpbmdSb3dzPXtjbGVhcmluZ1Jvd3N9XG4gICAgICAgICAgICAgIHBvcHVwcz17cG9wdXBzfVxuICAgICAgICAgICAgICBzaGFrZT17Ym9hcmRTaGFrZX1cbiAgICAgICAgICAgIC8+XG5cbiAgICAgICAgICAgIHsvKiBJbi1HYW1lIFN0YXRlIE92ZXJsYXlzICovfVxuICAgICAgICAgICAge2dhbWVTdGF0dXMgPT09ICdpZGxlJyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTMwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzc1IGJhY2tkcm9wLWJsdXItc20gcm91bmRlZC0yeGwgcC02IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXdoaXRlIHRyYWNraW5nLXdpZGUgbWItMVwiPlJFQURZPzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIG1heC13LXhzIG1iLTVcIj5cbiAgICAgICAgICAgICAgICAgIENsZWFyIGxpbmVzLCByYWNrIHVwIGNvbWJvIGNoYWlucywgYW5kIHNldCBuZXcgaGlnaCBzY29yZXMuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0R2FtZShzZWxlY3RlZE1vZGUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNiBweS0zIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWN5YW4tNTAwIHRvLWJsdWUtNjAwIGhvdmVyOmZyb20tY3lhbi00MDAgaG92ZXI6dG8tYmx1ZS01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC1zbSBzaGFkb3cteGwgc2hhZG93LWN5YW4tNTAwLzI1IGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFBsYXkgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLWN1cnJlbnRcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+U1RBUlQgR0FNRTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7Z2FtZVN0YXR1cyA9PT0gJ3BhdXNlZCcgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgei0zMCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLXNtIHJvdW5kZWQtMnhsIHAtNiB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDAgdHJhY2tpbmctd2lkZXIgbWItMlwiPlBBVVNFRDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIG1iLTZcIj5QcmVzcyBbUF0gb3IgY2xpY2sgUmVzdW1lIHRvIGNvbnRpbnVlPC9wPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiB3LTQ0XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e3RvZ2dsZVBhdXNlfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSByb3VuZGVkLXhsIGJnLWN5YW4tNjAwIGhvdmVyOmJnLWN5YW4tNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQteHMgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxQbGF5IGNsYXNzTmFtZT1cInctNCBoLTQgZmlsbC1jdXJyZW50XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UkVTVU1FPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0R2FtZShzZWxlY3RlZE1vZGUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgZm9udC1ib2xkIHRleHQteHMgdHJhbnNpdGlvbi1hbGwgYWN0aXZlOnNjYWxlLTk1XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UkVTVEFSVDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHtnYW1lU3RhdHVzID09PSAnZ2FtZW92ZXInICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIHotMzAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctYmxhY2svODUgYmFja2Ryb3AtYmx1ci1tZCByb3VuZGVkLTJ4bCBwLTYgdGV4dC1jZW50ZXIgYW5pbWF0ZS1mYWRlLWluXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXJvc2UtNTAwIHRyYWNraW5nLXdpZGUgbWItMVwiPkdBTUUgT1ZFUjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTMgcC0zIHJvdW5kZWQteGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHctNDggdGV4dC1sZWZ0IHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlNjb3JlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRhYnVsYXItbnVtc1wiPntzdGF0cy5zY29yZS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkxpbmVzOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtY3lhbi00MDAgdGFidWxhci1udW1zXCI+e3N0YXRzLmxpbmVzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPk1heCBDb21ibzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LWFtYmVyLTQwMCB0YWJ1bGFyLW51bXNcIj54e3N0YXRzLm1heENvbWJvICsgMX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBnYXAtMiB3LTQ4XCI+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHN0YXJ0R2FtZShzZWxlY3RlZE1vZGUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiBweC01IHB5LTIuNSByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTYwMCB0by1hbWJlci02MDAgaG92ZXI6ZnJvbS1yb3NlLTUwMCBob3Zlcjp0by1hbWJlci01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBzaGFkb3ctbGcgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFJvdGF0ZUNjdyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UExBWSBBR0FJTjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRJc0hpZ2hTY29yZXNNb2RhbE9wZW4odHJ1ZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTQgcHktMiByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgdGV4dC14cyBmb250LXNlbWlib2xkXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFRyb3BoeSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWFtYmVyLTQwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkxlYWRlcmJvYXJkPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAge2dhbWVTdGF0dXMgPT09ICd2aWN0b3J5JyAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB6LTMwIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLWJsYWNrLzg1IGJhY2tkcm9wLWJsdXItbWQgcm91bmRlZC0yeGwgcC02IHRleHQtY2VudGVyIGFuaW1hdGUtZmFkZS1pblwiPlxuICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgdGV4dC1hbWJlci00MDAgbWItMiBhbmltYXRlLWJvdW5jZVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LWFtYmVyLTQwMCB0cmFja2luZy13aWRlIG1iLTFcIj5WSUNUT1JZITwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIG1heC13LXhzIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgIHtzZWxlY3RlZE1vZGUgPT09ICdzcHJpbnQnID8gJzQwIExpbmVzIHNwcmludCBjb25xdWVyZWQhJyA6ICcyLU1pbnV0ZSBVbHRyYSBjb21wbGV0ZWQhJ31cbiAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgcC0zIHJvdW5kZWQteGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHctNDggdGV4dC1sZWZ0IHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkZpbmFsIFNjb3JlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIHRhYnVsYXItbnVtc1wiPntzdGF0cy5zY29yZS50b0xvY2FsZVN0cmluZygpfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlRvdGFsIFRpbWU6PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1lbWVyYWxkLTQwMCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7KHN0YXRzLmVsYXBzZWRUaW1lIC8gMTAwMCkudG9GaXhlZCgyKX1zXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc3RhcnRHYW1lKHNlbGVjdGVkTW9kZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0zIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIHB4LTUgcHktMi41IHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtNjAwIHRvLXRlYWwtNjAwIGhvdmVyOmZyb20tZW1lcmFsZC01MDAgaG92ZXI6dG8tdGVhbC01MDAgdGV4dC13aGl0ZSBmb250LWJvbGQgdGV4dC14cyBzaGFkb3ctbGcgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tYWxsIHctNDhcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5QTEFZIEFHQUlOPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBJbi1HYW1lIEFjdGlvbiBCYXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTMgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAge2dhbWVTdGF0dXMgPT09ICdwbGF5aW5nJyA/IChcbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXt0b2dnbGVQYXVzZX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgcHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQYXVzZSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5QYXVzZSBbUF08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc3RhcnRHYW1lKHNlbGVjdGVkTW9kZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgdGV4dC1jeWFuLTQwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxQbGF5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlN0YXJ0IFtSXTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc3RhcnRHYW1lKHNlbGVjdGVkTW9kZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgdGV4dC14cyBmb250LXNlbWlib2xkIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICB0aXRsZT1cIlJlc3RhcnQgR2FtZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Um90YXRlQ2N3IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5SZXNldDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBSaWdodCBXaW5nOiBOZXh0IFF1ZXVlICYgVGVsZW1ldHJ5IFNjb3JlYm9hcmQgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zIHctZnVsbCBsZzp3LTQ4IHNocmluay0wXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBsZzpibG9ja1wiPlxuICAgICAgICAgICAgICA8TmV4dFF1ZXVlIHF1ZXVlPXtuZXh0UXVldWV9IHRoZW1lPXthY3RpdmVUaGVtZX0gLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8U2NvcmVCb2FyZFxuICAgICAgICAgICAgICBzdGF0cz17c3RhdHN9XG4gICAgICAgICAgICAgIGdhbWVNb2RlPXtzZWxlY3RlZE1vZGV9XG4gICAgICAgICAgICAgIGhpZ2hTY29yZXM9e2hpZ2hTY29yZXN9XG4gICAgICAgICAgICAgIHplblNwZWVkPXt6ZW5TcGVlZH1cbiAgICAgICAgICAgICAgb25aZW5TcGVlZENoYW5nZT17c2V0WmVuU3BlZWR9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTW9iaWxlIE9uLVNjcmVlbiBUb3VjaCBDb250cm9scyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgbGc6aGlkZGVuIG10LTNcIj5cbiAgICAgICAgICA8TW9iaWxlQ29udHJvbHNcbiAgICAgICAgICAgIG9uTW92ZUxlZnQ9eygpID0+IG1vdmVIb3Jpem9udGFsKC0xKX1cbiAgICAgICAgICAgIG9uTW92ZVJpZ2h0PXsoKSA9PiBtb3ZlSG9yaXpvbnRhbCgxKX1cbiAgICAgICAgICAgIG9uU29mdERyb3A9e3NvZnREcm9wfVxuICAgICAgICAgICAgb25IYXJkRHJvcD17aGFyZERyb3B9XG4gICAgICAgICAgICBvblJvdGF0ZUNXPXsoKSA9PiByb3RhdGUodHJ1ZSl9XG4gICAgICAgICAgICBvblJvdGF0ZUNDVz17KCkgPT4gcm90YXRlKGZhbHNlKX1cbiAgICAgICAgICAgIG9uSG9sZD17aG9sZH1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvbWFpbj5cblxuICAgICAgey8qIE1vZGFscyAqL31cbiAgICAgIDxHaXRIdWJFeHBvcnRNb2RhbFxuICAgICAgICBpc09wZW49e2lzR2l0SHViTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0dpdEh1Yk1vZGFsT3BlbihmYWxzZSl9XG4gICAgICAvPlxuXG4gICAgICA8SGlnaFNjb3Jlc01vZGFsXG4gICAgICAgIGlzT3Blbj17aXNIaWdoU2NvcmVzTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0hpZ2hTY29yZXNNb2RhbE9wZW4oZmFsc2UpfVxuICAgICAgICBzY29yZXM9e2hpZ2hTY29yZXN9XG4gICAgICAgIG9uQ2xlYXJTY29yZXM9e2hhbmRsZUNsZWFyU2NvcmVzfVxuICAgICAgLz5cblxuICAgICAgPEtleWJpbmRpbmdzTW9kYWxcbiAgICAgICAgaXNPcGVuPXtpc0NvbnRyb2xzTW9kYWxPcGVufVxuICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRJc0NvbnRyb2xzTW9kYWxPcGVuKGZhbHNlKX1cbiAgICAgICAga2V5YmluZGluZ3M9e0RFRkFVTFRfS0VZQklORElOR1N9XG4gICAgICAvPlxuICAgIDwvZGl2PlxuICApO1xufVxuIl19