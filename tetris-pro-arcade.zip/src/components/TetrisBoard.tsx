const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { BOARD_WIDTH, BOARD_HEIGHT, BUFFER_ROWS, TETROMINOES } from "/src/utils/tetrisConstants.ts";
var _jsxFileName = "/app/applet/src/components/TetrisBoard.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const TetrisBoard = ({ board, currentPiece, ghostY, theme, clearingRows, popups, shake }) => {
	// Construct 10x20 visual grid from row BUFFER_ROWS (2) to 21
	const activeCells = new Map();
	const ghostCells = new Set();
	if (currentPiece) {
		// Current piece blocks
		const coords = TETROMINOES[currentPiece.type][currentPiece.rotation];
		for (const c of coords) {
			const ax = currentPiece.position.x + c.x;
			const ay = currentPiece.position.y + c.y;
			activeCells.set(`${ax},${ay}`, currentPiece.type);
		}
		// Ghost piece blocks
		for (const c of coords) {
			const gx = currentPiece.position.x + c.x;
			const gy = ghostY + c.y;
			ghostCells.add(`${gx},${gy}`);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `relative transition-transform duration-100 ${shake ? "scale-[1.015] translate-y-0.5" : ""}`,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `relative p-2 md:p-3 rounded-2xl border ${theme.boardBorder} shadow-2xl backdrop-blur-md overflow-hidden`,
			style: { backgroundColor: theme.boardBg },
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "pointer-events-none absolute inset-0 opacity-[0.06] z-20",
					style: { backgroundImage: "repeating-linear-gradient(0deg, #000 0px, #000 1px, transparent 2px, transparent 4px)" }
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-10 gap-0.5 relative z-10",
					style: {
						width: "min(78vw, 320px)",
						height: "min(156vw, 640px)"
					},
					children: Array.from({ length: BOARD_HEIGHT }).map((_, rIndex) => {
						const actualY = rIndex + BUFFER_ROWS;
						const isClearing = clearingRows.includes(actualY);
						return Array.from({ length: BOARD_WIDTH }).map((_, xIndex) => {
							const cellKey = `${xIndex},${actualY}`;
							const lockedType = board[actualY]?.[xIndex];
							const activeType = activeCells.get(cellKey);
							const isGhost = ghostCells.has(cellKey) && !activeType && !lockedType;
							const cellType = activeType || lockedType;
							const colorInfo = cellType ? theme.colors[cellType] : null;
							return /* @__PURE__ */ _jsxDEV("div", {
								className: `relative rounded-[3px] transition-all duration-75 flex items-center justify-center ${isClearing ? "bg-white scale-110 shadow-[0_0_15px_#ffffff] z-30 opacity-95 duration-100" : ""}`,
								style: {
									backgroundColor: isClearing ? "#ffffff" : colorInfo ? colorInfo.primary : isGhost ? "transparent" : "rgba(255, 255, 255, 0.02)",
									boxShadow: isClearing ? "0 0 15px #fff" : colorInfo?.glow ? `0 0 10px ${colorInfo.glow}` : undefined,
									border: isGhost && currentPiece ? `1.5px dashed ${theme.colors[currentPiece.type].border}` : colorInfo ? `1px solid ${colorInfo.border}` : `1px solid ${theme.gridLine}`,
									opacity: isGhost ? theme.ghostOpacity : 1
								},
								children: [colorInfo && !isClearing && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0.5 rounded-[2px] bg-gradient-to-br from-white/30 via-transparent to-black/25 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 112,
									columnNumber: 21
								}, this), colorInfo && !isClearing && /* @__PURE__ */ _jsxDEV("div", { className: "w-1.5 h-1.5 rounded-full bg-white/20 pointer-events-none" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 116,
									columnNumber: 21
								}, this)]
							}, cellKey, true, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 17
							}, this);
						});
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "absolute inset-x-0 top-1/3 flex flex-col items-center pointer-events-none z-30 gap-2",
					children: popups.map((popup) => /* @__PURE__ */ _jsxDEV("div", {
						className: "animate-bounce text-center px-4 py-1.5 rounded-full font-black tracking-wider text-sm md:text-base text-white shadow-lg bg-slate-900/90 border border-cyan-400/50 backdrop-blur-md",
						style: {
							textShadow: "0 0 12px rgba(6, 182, 212, 0.8)",
							color: popup.color || "#38bdf8"
						},
						children: [/* @__PURE__ */ _jsxDEV("span", { children: popup.text }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 15
						}, this), popup.points > 0 && /* @__PURE__ */ _jsxDEV("span", {
							className: "ml-2 font-mono text-amber-300 text-xs",
							children: ["+", popup.points]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 137,
							columnNumber: 17
						}, this)]
					}, popup.id, true, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsYUFBYSxjQUFjLGFBQWEsbUJBQW1COzs7QUFZcEUsT0FBTyxNQUFNLGVBQTJDLEVBQ3RELE9BQ0EsY0FDQSxRQUNBLE9BQ0EsY0FDQSxRQUNBLFlBQ0k7O0NBRUosTUFBTSxjQUFjLElBQUksSUFBMkI7Q0FDbkQsTUFBTSxhQUFhLElBQUksSUFBWTtDQUVuQyxJQUFJLGNBQWM7O0VBRWhCLE1BQU0sU0FBUyxZQUFZLGFBQWEsS0FBSyxDQUFDLGFBQWE7RUFDM0QsS0FBSyxNQUFNLEtBQUssUUFBUTtHQUN0QixNQUFNLEtBQUssYUFBYSxTQUFTLElBQUksRUFBRTtHQUN2QyxNQUFNLEtBQUssYUFBYSxTQUFTLElBQUksRUFBRTtHQUN2QyxZQUFZLElBQUksR0FBRyxHQUFHLEdBQUcsTUFBTSxhQUFhLElBQUk7RUFDbEQ7O0VBR0EsS0FBSyxNQUFNLEtBQUssUUFBUTtHQUN0QixNQUFNLEtBQUssYUFBYSxTQUFTLElBQUksRUFBRTtHQUN2QyxNQUFNLEtBQUssU0FBUyxFQUFFO0dBQ3RCLFdBQVcsSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJO0VBQzlCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFXLDhDQUE4QyxRQUFRLGtDQUFrQztZQUV0Ryx3QkFBQyxPQUFEO0dBQ0UsV0FBVywwQ0FBMEMsTUFBTSxZQUFZO0dBQ3ZFLE9BQU8sRUFBRSxpQkFBaUIsTUFBTSxRQUFRO2FBRjFDO0lBS0Usd0JBQUMsT0FBRDtLQUNFLFdBQVU7S0FDVixPQUFPLEVBQ0wsaUJBQWlCLHdGQUNuQjtJQUNEOzs7OztJQUdELHdCQUFDLE9BQUQ7S0FDRSxXQUFVO0tBQ1YsT0FBTztNQUNMLE9BQU87TUFDUCxRQUFRO0tBQ1Y7ZUFFQyxNQUFNLEtBQUssRUFBRSxRQUFRLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFdBQVc7TUFDdkQsTUFBTSxVQUFVLFNBQVM7TUFDekIsTUFBTSxhQUFhLGFBQWEsU0FBUyxPQUFPO01BRWhELE9BQU8sTUFBTSxLQUFLLEVBQUUsUUFBUSxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxXQUFXO09BQzVELE1BQU0sVUFBVSxHQUFHLE9BQU8sR0FBRztPQUM3QixNQUFNLGFBQWEsTUFBTSxRQUFRLEdBQUc7T0FDcEMsTUFBTSxhQUFhLFlBQVksSUFBSSxPQUFPO09BQzFDLE1BQU0sVUFBVSxXQUFXLElBQUksT0FBTyxLQUFLLENBQUMsY0FBYyxDQUFDO09BRTNELE1BQU0sV0FBVyxjQUFjO09BQy9CLE1BQU0sWUFBWSxXQUFXLE1BQU0sT0FBTyxZQUFZO09BRXRELE9BQ0Usd0JBQUMsT0FBRDtRQUVFLFdBQVcsc0ZBQ1QsYUFDSSw4RUFDQTtRQUVOLE9BQU87U0FDTCxpQkFBaUIsYUFDYixZQUNBLFlBQ0EsVUFBVSxVQUNWLFVBQ0EsZ0JBQ0E7U0FDSixXQUFXLGFBQ1Asa0JBQ0EsV0FBVyxPQUNYLFlBQVksVUFBVSxTQUN0QjtTQUNKLFFBQVEsV0FBVyxlQUNmLGdCQUFnQixNQUFNLE9BQU8sYUFBYSxLQUFLLENBQUMsV0FDaEQsWUFDQSxhQUFhLFVBQVUsV0FDdkIsYUFBYSxNQUFNO1NBQ3ZCLFNBQVMsVUFBVSxNQUFNLGVBQWU7UUFDMUM7a0JBMUJGLENBNkJHLGFBQWEsQ0FBQyxjQUNiLHdCQUFDLE9BQUQsRUFBSyxXQUFVLG1IQUFvSDs7OztrQkFHcEksYUFBYSxDQUFDLGNBQ2Isd0JBQUMsT0FBRCxFQUFLLFdBQVUsMkRBQTREOzs7O2dCQUUxRTtVQW5DRTs7OztjQW1DRjtNQUVULENBQUM7S0FDSCxDQUFDO0lBQ0U7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixPQUFPLEtBQUssVUFDWCx3QkFBQyxPQUFEO01BRUUsV0FBVTtNQUNWLE9BQU87T0FDTCxZQUFZO09BQ1osT0FBTyxNQUFNLFNBQVM7TUFDeEI7Z0JBTkYsQ0FRRSx3QkFBQyxRQUFELFlBQU8sTUFBTSxLQUFXOzs7O2dCQUN2QixNQUFNLFNBQVMsS0FDZCx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEIsQ0FBd0QsS0FBRSxNQUFNLE1BQWE7Ozs7O2NBRTVFO1FBWEUsTUFBTTs7OztZQVdSLENBQ047SUFDRTs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGV0cmlzQm9hcmQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBCb2FyZCwgUGllY2UsIFRoZW1lQ29uZmlnLCBBY3Rpb25Qb3B1cCwgVGV0cm9taW5vVHlwZSB9IGZyb20gJy4uL3R5cGVzL3RldHJpcyc7XG5pbXBvcnQgeyBCT0FSRF9XSURUSCwgQk9BUkRfSEVJR0hULCBCVUZGRVJfUk9XUywgVEVUUk9NSU5PRVMgfSBmcm9tICcuLi91dGlscy90ZXRyaXNDb25zdGFudHMnO1xuXG5pbnRlcmZhY2UgVGV0cmlzQm9hcmRQcm9wcyB7XG4gIGJvYXJkOiBCb2FyZDtcbiAgY3VycmVudFBpZWNlOiBQaWVjZSB8IG51bGw7XG4gIGdob3N0WTogbnVtYmVyO1xuICB0aGVtZTogVGhlbWVDb25maWc7XG4gIGNsZWFyaW5nUm93czogbnVtYmVyW107XG4gIHBvcHVwczogQWN0aW9uUG9wdXBbXTtcbiAgc2hha2U6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBUZXRyaXNCb2FyZDogUmVhY3QuRkM8VGV0cmlzQm9hcmRQcm9wcz4gPSAoe1xuICBib2FyZCxcbiAgY3VycmVudFBpZWNlLFxuICBnaG9zdFksXG4gIHRoZW1lLFxuICBjbGVhcmluZ1Jvd3MsXG4gIHBvcHVwcyxcbiAgc2hha2UsXG59KSA9PiB7XG4gIC8vIENvbnN0cnVjdCAxMHgyMCB2aXN1YWwgZ3JpZCBmcm9tIHJvdyBCVUZGRVJfUk9XUyAoMikgdG8gMjFcbiAgY29uc3QgYWN0aXZlQ2VsbHMgPSBuZXcgTWFwPHN0cmluZywgVGV0cm9taW5vVHlwZT4oKTtcbiAgY29uc3QgZ2hvc3RDZWxscyA9IG5ldyBTZXQ8c3RyaW5nPigpO1xuXG4gIGlmIChjdXJyZW50UGllY2UpIHtcbiAgICAvLyBDdXJyZW50IHBpZWNlIGJsb2Nrc1xuICAgIGNvbnN0IGNvb3JkcyA9IFRFVFJPTUlOT0VTW2N1cnJlbnRQaWVjZS50eXBlXVtjdXJyZW50UGllY2Uucm90YXRpb25dO1xuICAgIGZvciAoY29uc3QgYyBvZiBjb29yZHMpIHtcbiAgICAgIGNvbnN0IGF4ID0gY3VycmVudFBpZWNlLnBvc2l0aW9uLnggKyBjLng7XG4gICAgICBjb25zdCBheSA9IGN1cnJlbnRQaWVjZS5wb3NpdGlvbi55ICsgYy55O1xuICAgICAgYWN0aXZlQ2VsbHMuc2V0KGAke2F4fSwke2F5fWAsIGN1cnJlbnRQaWVjZS50eXBlKTtcbiAgICB9XG5cbiAgICAvLyBHaG9zdCBwaWVjZSBibG9ja3NcbiAgICBmb3IgKGNvbnN0IGMgb2YgY29vcmRzKSB7XG4gICAgICBjb25zdCBneCA9IGN1cnJlbnRQaWVjZS5wb3NpdGlvbi54ICsgYy54O1xuICAgICAgY29uc3QgZ3kgPSBnaG9zdFkgKyBjLnk7XG4gICAgICBnaG9zdENlbGxzLmFkZChgJHtneH0sJHtneX1gKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPXtgcmVsYXRpdmUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMTAwICR7c2hha2UgPyAnc2NhbGUtWzEuMDE1XSB0cmFuc2xhdGUteS0wLjUnIDogJyd9YH0+XG4gICAgICB7LyogT3V0ZXIgQXJjYWRlIENhYmluZXQgRW5jbG9zdXJlICovfVxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9e2ByZWxhdGl2ZSBwLTIgbWQ6cC0zIHJvdW5kZWQtMnhsIGJvcmRlciAke3RoZW1lLmJvYXJkQm9yZGVyfSBzaGFkb3ctMnhsIGJhY2tkcm9wLWJsdXItbWQgb3ZlcmZsb3ctaGlkZGVuYH1cbiAgICAgICAgc3R5bGU9e3sgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5ib2FyZEJnIH19XG4gICAgICA+XG4gICAgICAgIHsvKiBTdWJ0bGUgU2NhbmxpbmUgT3ZlcmxheSBmb3IgUmV0cm8vQXJjYWRlIGZlZWwgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIGluc2V0LTAgb3BhY2l0eS1bMC4wNl0gei0yMFwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogJ3JlcGVhdGluZy1saW5lYXItZ3JhZGllbnQoMGRlZywgIzAwMCAwcHgsICMwMDAgMXB4LCB0cmFuc3BhcmVudCAycHgsIHRyYW5zcGFyZW50IDRweCknLFxuICAgICAgICAgIH19XG4gICAgICAgIC8+XG5cbiAgICAgICAgey8qIDEwIHggMjAgTWF0cml4IEdyaWQgKi99XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xMCBnYXAtMC41IHJlbGF0aXZlIHotMTBcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICB3aWR0aDogJ21pbig3OHZ3LCAzMjBweCknLFxuICAgICAgICAgICAgaGVpZ2h0OiAnbWluKDE1NnZ3LCA2NDBweCknLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogQk9BUkRfSEVJR0hUIH0pLm1hcCgoXywgckluZGV4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBhY3R1YWxZID0gckluZGV4ICsgQlVGRkVSX1JPV1M7XG4gICAgICAgICAgICBjb25zdCBpc0NsZWFyaW5nID0gY2xlYXJpbmdSb3dzLmluY2x1ZGVzKGFjdHVhbFkpO1xuXG4gICAgICAgICAgICByZXR1cm4gQXJyYXkuZnJvbSh7IGxlbmd0aDogQk9BUkRfV0lEVEggfSkubWFwKChfLCB4SW5kZXgpID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgY2VsbEtleSA9IGAke3hJbmRleH0sJHthY3R1YWxZfWA7XG4gICAgICAgICAgICAgIGNvbnN0IGxvY2tlZFR5cGUgPSBib2FyZFthY3R1YWxZXT8uW3hJbmRleF07XG4gICAgICAgICAgICAgIGNvbnN0IGFjdGl2ZVR5cGUgPSBhY3RpdmVDZWxscy5nZXQoY2VsbEtleSk7XG4gICAgICAgICAgICAgIGNvbnN0IGlzR2hvc3QgPSBnaG9zdENlbGxzLmhhcyhjZWxsS2V5KSAmJiAhYWN0aXZlVHlwZSAmJiAhbG9ja2VkVHlwZTtcblxuICAgICAgICAgICAgICBjb25zdCBjZWxsVHlwZSA9IGFjdGl2ZVR5cGUgfHwgbG9ja2VkVHlwZTtcbiAgICAgICAgICAgICAgY29uc3QgY29sb3JJbmZvID0gY2VsbFR5cGUgPyB0aGVtZS5jb2xvcnNbY2VsbFR5cGVdIDogbnVsbDtcblxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17Y2VsbEtleX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHJvdW5kZWQtWzNweF0gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tNzUgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgaXNDbGVhcmluZ1xuICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXdoaXRlIHNjYWxlLTExMCBzaGFkb3ctWzBfMF8xNXB4XyNmZmZmZmZdIHotMzAgb3BhY2l0eS05NSBkdXJhdGlvbi0xMDAnXG4gICAgICAgICAgICAgICAgICAgICAgOiAnJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGlzQ2xlYXJpbmdcbiAgICAgICAgICAgICAgICAgICAgICA/ICcjZmZmZmZmJ1xuICAgICAgICAgICAgICAgICAgICAgIDogY29sb3JJbmZvXG4gICAgICAgICAgICAgICAgICAgICAgPyBjb2xvckluZm8ucHJpbWFyeVxuICAgICAgICAgICAgICAgICAgICAgIDogaXNHaG9zdFxuICAgICAgICAgICAgICAgICAgICAgID8gJ3RyYW5zcGFyZW50J1xuICAgICAgICAgICAgICAgICAgICAgIDogJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4wMiknLFxuICAgICAgICAgICAgICAgICAgICBib3hTaGFkb3c6IGlzQ2xlYXJpbmdcbiAgICAgICAgICAgICAgICAgICAgICA/ICcwIDAgMTVweCAjZmZmJ1xuICAgICAgICAgICAgICAgICAgICAgIDogY29sb3JJbmZvPy5nbG93XG4gICAgICAgICAgICAgICAgICAgICAgPyBgMCAwIDEwcHggJHtjb2xvckluZm8uZ2xvd31gXG4gICAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogaXNHaG9zdCAmJiBjdXJyZW50UGllY2VcbiAgICAgICAgICAgICAgICAgICAgICA/IGAxLjVweCBkYXNoZWQgJHt0aGVtZS5jb2xvcnNbY3VycmVudFBpZWNlLnR5cGVdLmJvcmRlcn1gXG4gICAgICAgICAgICAgICAgICAgICAgOiBjb2xvckluZm9cbiAgICAgICAgICAgICAgICAgICAgICA/IGAxcHggc29saWQgJHtjb2xvckluZm8uYm9yZGVyfWBcbiAgICAgICAgICAgICAgICAgICAgICA6IGAxcHggc29saWQgJHt0aGVtZS5ncmlkTGluZX1gLFxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiBpc0dob3N0ID8gdGhlbWUuZ2hvc3RPcGFjaXR5IDogMSxcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgey8qIEludGVybmFsIGdsb3NzeSBiZXZlbCBoaWdobGlnaHQgZm9yIHNvbGlkIGJsb2NrcyAqL31cbiAgICAgICAgICAgICAgICAgIHtjb2xvckluZm8gJiYgIWlzQ2xlYXJpbmcgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAuNSByb3VuZGVkLVsycHhdIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUvMzAgdmlhLXRyYW5zcGFyZW50IHRvLWJsYWNrLzI1IHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIHsvKiBDZW50ZXIgY29yZSBoaWdobGlnaHQgKi99XG4gICAgICAgICAgICAgICAgICB7Y29sb3JJbmZvICYmICFpc0NsZWFyaW5nICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEuNSBoLTEuNSByb3VuZGVkLWZ1bGwgYmctd2hpdGUvMjAgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBGbG9hdGluZyBBY3Rpb24gUG9wdXBzIChlLmcuLCBURVRSSVMhLCBULVNQSU4gRE9VQkxFISkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQteC0wIHRvcC0xLzMgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgcG9pbnRlci1ldmVudHMtbm9uZSB6LTMwIGdhcC0yXCI+XG4gICAgICAgICAge3BvcHVwcy5tYXAoKHBvcHVwKSA9PiAoXG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIGtleT17cG9wdXAuaWR9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFuaW1hdGUtYm91bmNlIHRleHQtY2VudGVyIHB4LTQgcHktMS41IHJvdW5kZWQtZnVsbCBmb250LWJsYWNrIHRyYWNraW5nLXdpZGVyIHRleHQtc20gbWQ6dGV4dC1iYXNlIHRleHQtd2hpdGUgc2hhZG93LWxnIGJnLXNsYXRlLTkwMC85MCBib3JkZXIgYm9yZGVyLWN5YW4tNDAwLzUwIGJhY2tkcm9wLWJsdXItbWRcIlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIHRleHRTaGFkb3c6ICcwIDAgMTJweCByZ2JhKDYsIDE4MiwgMjEyLCAwLjgpJyxcbiAgICAgICAgICAgICAgICBjb2xvcjogcG9wdXAuY29sb3IgfHwgJyMzOGJkZjgnLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3Bhbj57cG9wdXAudGV4dH08L3NwYW4+XG4gICAgICAgICAgICAgIHtwb3B1cC5wb2ludHMgPiAwICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC0yIGZvbnQtbW9ubyB0ZXh0LWFtYmVyLTMwMCB0ZXh0LXhzXCI+K3twb3B1cC5wb2ludHN9PC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19