const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { Volume2, VolumeX, Music } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
import { sound } from "/src/utils/soundEffects.ts";
var _jsxFileName = "/app/applet/src/components/SoundControls.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const SoundControls = () => {
	const [muted, setMuted] = useState(sound.getMute());
	const [bgmPlaying, setBgmPlaying] = useState(sound.getIsBgmPlaying());
	const [sfxVol, setSfxVol] = useState(sound.getSfxVolume());
	const [bgmVol, setBgmVol] = useState(sound.getBgmVolume());
	useEffect(() => {
		sound.setMute(muted);
	}, [muted]);
	const handleToggleBgm = () => {
		const isPlaying = sound.toggleBgm();
		setBgmPlaying(isPlaying);
	};
	const handleSfxChange = (v) => {
		setSfxVol(v);
		sound.setSfxVolume(v);
	};
	const handleBgmChange = (v) => {
		setBgmVol(v);
		sound.setBgmVolume(v);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ _jsxDEV("button", {
			onClick: () => setMuted(!muted),
			className: `p-2 rounded-xl border transition-all ${muted ? "bg-rose-950/40 border-rose-500/40 text-rose-400" : "bg-slate-900/60 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"}`,
			title: muted ? "Unmute Audio" : "Mute Audio",
			"aria-label": "Toggle mute",
			children: muted ? /* @__PURE__ */ _jsxDEV(VolumeX, { className: "w-4 h-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 18
			}, this) : /* @__PURE__ */ _jsxDEV(Volume2, { className: "w-4 h-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 43,
				columnNumber: 52
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("button", {
			onClick: handleToggleBgm,
			className: `flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-medium transition-all ${bgmPlaying && !muted ? "bg-cyan-950/50 border-cyan-500/50 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]" : "bg-slate-900/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"}`,
			title: "Toggle 8-bit Tetris Theme Melody",
			children: [/* @__PURE__ */ _jsxDEV(Music, { className: `w-3.5 h-3.5 ${bgmPlaying && !muted ? "animate-spin" : ""}` }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "8-BIT BGM" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsU0FBUyxTQUFTLGFBQW1CO0FBQzlDLFNBQVMsYUFBYTs7O0FBRXRCLE9BQU8sTUFBTSxzQkFBZ0M7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLE1BQU0sUUFBUSxDQUFDO0NBQ2xELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLE1BQU0sZ0JBQWdCLENBQUM7Q0FDcEUsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFTLE1BQU0sYUFBYSxDQUFDO0NBQ3pELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxNQUFNLGFBQWEsQ0FBQztDQUV6RCxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsS0FBSztDQUNyQixHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsTUFBTSx3QkFBd0I7RUFDNUIsTUFBTSxZQUFZLE1BQU0sVUFBVTtFQUNsQyxjQUFjLFNBQVM7Q0FDekI7Q0FFQSxNQUFNLG1CQUFtQixNQUFjO0VBQ3JDLFVBQVUsQ0FBQztFQUNYLE1BQU0sYUFBYSxDQUFDO0NBQ3RCO0NBRUEsTUFBTSxtQkFBbUIsTUFBYztFQUNyQyxVQUFVLENBQUM7RUFDWCxNQUFNLGFBQWEsQ0FBQztDQUN0QjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLFVBQUQ7R0FDRSxlQUFlLFNBQVMsQ0FBQyxLQUFLO0dBQzlCLFdBQVcsd0NBQ1QsUUFDSSxvREFDQTtHQUVOLE9BQU8sUUFBUSxpQkFBaUI7R0FDaEMsY0FBVzthQUVWLFFBQVEsd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7OztjQUFJLHdCQUFDLFNBQUQsRUFBUyxXQUFVLFVBQVc7Ozs7O0VBQ25FOzs7O1lBR1Isd0JBQUMsVUFBRDtHQUNFLFNBQVM7R0FDVCxXQUFXLDhGQUNULGNBQWMsQ0FBQyxRQUNYLDBGQUNBO0dBRU4sT0FBTTthQVBSLENBU0Usd0JBQUMsT0FBRCxFQUFPLFdBQVcsZUFBZSxjQUFjLENBQUMsUUFBUSxpQkFBaUIsS0FBTzs7OzthQUNoRix3QkFBQyxRQUFELFlBQU0sWUFBZTs7OztXQUNmOzs7OztVQUNMOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTb3VuZENvbnRyb2xzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFZvbHVtZTIsIFZvbHVtZVgsIE11c2ljLCBEaXNjIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHNvdW5kIH0gZnJvbSAnLi4vdXRpbHMvc291bmRFZmZlY3RzJztcblxuZXhwb3J0IGNvbnN0IFNvdW5kQ29udHJvbHM6IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCBbbXV0ZWQsIHNldE11dGVkXSA9IHVzZVN0YXRlKHNvdW5kLmdldE11dGUoKSk7XG4gIGNvbnN0IFtiZ21QbGF5aW5nLCBzZXRCZ21QbGF5aW5nXSA9IHVzZVN0YXRlKHNvdW5kLmdldElzQmdtUGxheWluZygpKTtcbiAgY29uc3QgW3NmeFZvbCwgc2V0U2Z4Vm9sXSA9IHVzZVN0YXRlKHNvdW5kLmdldFNmeFZvbHVtZSgpKTtcbiAgY29uc3QgW2JnbVZvbCwgc2V0QmdtVm9sXSA9IHVzZVN0YXRlKHNvdW5kLmdldEJnbVZvbHVtZSgpKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNvdW5kLnNldE11dGUobXV0ZWQpO1xuICB9LCBbbXV0ZWRdKTtcblxuICBjb25zdCBoYW5kbGVUb2dnbGVCZ20gPSAoKSA9PiB7XG4gICAgY29uc3QgaXNQbGF5aW5nID0gc291bmQudG9nZ2xlQmdtKCk7XG4gICAgc2V0QmdtUGxheWluZyhpc1BsYXlpbmcpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNmeENoYW5nZSA9ICh2OiBudW1iZXIpID0+IHtcbiAgICBzZXRTZnhWb2wodik7XG4gICAgc291bmQuc2V0U2Z4Vm9sdW1lKHYpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUJnbUNoYW5nZSA9ICh2OiBudW1iZXIpID0+IHtcbiAgICBzZXRCZ21Wb2wodik7XG4gICAgc291bmQuc2V0QmdtVm9sdW1lKHYpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgey8qIFNGWCBNdXRlIEJ1dHRvbiAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TXV0ZWQoIW11dGVkKX1cbiAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgYm9yZGVyIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgbXV0ZWRcbiAgICAgICAgICAgID8gJ2JnLXJvc2UtOTUwLzQwIGJvcmRlci1yb3NlLTUwMC80MCB0ZXh0LXJvc2UtNDAwJ1xuICAgICAgICAgICAgOiAnYmctc2xhdGUtOTAwLzYwIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgaG92ZXI6dGV4dC13aGl0ZSBob3Zlcjpib3JkZXItc2xhdGUtNzAwJ1xuICAgICAgICB9YH1cbiAgICAgICAgdGl0bGU9e211dGVkID8gJ1VubXV0ZSBBdWRpbycgOiAnTXV0ZSBBdWRpbyd9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgbXV0ZVwiXG4gICAgICA+XG4gICAgICAgIHttdXRlZCA/IDxWb2x1bWVYIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPiA6IDxWb2x1bWUyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPn1cbiAgICAgIDwvYnV0dG9uPlxuXG4gICAgICB7LyogOC1iaXQgU3ludGggQkdNIFRvZ2dsZSAqL31cbiAgICAgIDxidXR0b25cbiAgICAgICAgb25DbGljaz17aGFuZGxlVG9nZ2xlQmdtfVxuICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICBiZ21QbGF5aW5nICYmICFtdXRlZFxuICAgICAgICAgICAgPyAnYmctY3lhbi05NTAvNTAgYm9yZGVyLWN5YW4tNTAwLzUwIHRleHQtY3lhbi0zMDAgc2hhZG93LVswXzBfMTBweF9yZ2JhKDYsMTgyLDIxMiwwLjMpXSdcbiAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMC82MCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgIH1gfVxuICAgICAgICB0aXRsZT1cIlRvZ2dsZSA4LWJpdCBUZXRyaXMgVGhlbWUgTWVsb2R5XCJcbiAgICAgID5cbiAgICAgICAgPE11c2ljIGNsYXNzTmFtZT17YHctMy41IGgtMy41ICR7YmdtUGxheWluZyAmJiAhbXV0ZWQgPyAnYW5pbWF0ZS1zcGluJyA6ICcnfWB9IC8+XG4gICAgICAgIDxzcGFuPjgtQklUIEJHTTwvc3Bhbj5cbiAgICAgIDwvYnV0dG9uPlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==