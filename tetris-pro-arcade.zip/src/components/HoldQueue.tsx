const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { PiecePreview } from "/src/components/PiecePreview.tsx";
var _jsxFileName = "/app/applet/src/components/HoldQueue.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const HoldQueue = ({ holdPiece, canHold, theme, onHoldClick }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		onClick: onHoldClick,
		className: `flex flex-col items-center p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg select-none cursor-pointer transition-all hover:border-slate-700 active:scale-95`,
		title: "Click or press 'C' to Hold",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between w-full mb-2",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-[11px] font-bold uppercase tracking-wider text-slate-400",
					children: "HOLD"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "text-[10px] text-slate-500 font-mono",
					children: "KEY [C]"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(PiecePreview, {
				type: holdPiece,
				theme,
				size: "md",
				disabled: !canHold
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			!canHold && /* @__PURE__ */ _jsxDEV("span", {
				className: "mt-1 text-[10px] text-amber-500/80 font-medium",
				children: "LOCKED"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 19,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsb0JBQW9COzs7QUFTN0IsT0FBTyxNQUFNLGFBQXVDLEVBQ2xELFdBQ0EsU0FDQSxPQUNBLGtCQUNJO0NBQ0osT0FDRSx3QkFBQyxPQUFEO0VBQ0UsU0FBUztFQUNULFdBQVc7RUFDWCxPQUFNO1lBSFI7R0FLRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRDtLQUFNLFdBQVU7ZUFBZ0U7SUFBVTs7OztjQUMxRix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUF1QztJQUFhOzs7O1lBQ2pFOzs7Ozs7R0FFTCx3QkFBQyxjQUFEO0lBQWMsTUFBTTtJQUFrQjtJQUFPLE1BQUs7SUFBSyxVQUFVLENBQUM7R0FBVTs7Ozs7R0FFM0UsQ0FBQyxXQUNBLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQWlEO0dBQVk7Ozs7O0VBRTVFOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIb2xkUXVldWUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUZXRyb21pbm9UeXBlLCBUaGVtZUNvbmZpZyB9IGZyb20gJy4uL3R5cGVzL3RldHJpcyc7XG5pbXBvcnQgeyBQaWVjZVByZXZpZXcgfSBmcm9tICcuL1BpZWNlUHJldmlldyc7XG5cbmludGVyZmFjZSBIb2xkUXVldWVQcm9wcyB7XG4gIGhvbGRQaWVjZTogVGV0cm9taW5vVHlwZSB8IG51bGw7XG4gIGNhbkhvbGQ6IGJvb2xlYW47XG4gIHRoZW1lOiBUaGVtZUNvbmZpZztcbiAgb25Ib2xkQ2xpY2s/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgSG9sZFF1ZXVlOiBSZWFjdC5GQzxIb2xkUXVldWVQcm9wcz4gPSAoe1xuICBob2xkUGllY2UsXG4gIGNhbkhvbGQsXG4gIHRoZW1lLFxuICBvbkhvbGRDbGljayxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBvbkNsaWNrPXtvbkhvbGRDbGlja31cbiAgICAgIGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHAtMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGcgc2VsZWN0LW5vbmUgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbi1hbGwgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCBhY3RpdmU6c2NhbGUtOTVgfVxuICAgICAgdGl0bGU9XCJDbGljayBvciBwcmVzcyAnQycgdG8gSG9sZFwiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIG1iLTJcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPkhPTEQ8L3NwYW4+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPktFWSBbQ108L3NwYW4+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPFBpZWNlUHJldmlldyB0eXBlPXtob2xkUGllY2V9IHRoZW1lPXt0aGVtZX0gc2l6ZT1cIm1kXCIgZGlzYWJsZWQ9eyFjYW5Ib2xkfSAvPlxuXG4gICAgICB7IWNhbkhvbGQgJiYgKFxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtdC0xIHRleHQtWzEwcHhdIHRleHQtYW1iZXItNTAwLzgwIGZvbnQtbWVkaXVtXCI+TE9DS0VEPC9zcGFuPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=