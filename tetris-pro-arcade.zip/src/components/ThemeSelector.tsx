const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { THEMES } from "/src/utils/tetrisConstants.ts";
import { Palette } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
var _jsxFileName = "/app/applet/src/components/ThemeSelector.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const ThemeSelector = ({ currentThemeId, onSelectTheme }) => {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex items-center gap-1.5 p-1 bg-slate-900/60 border border-slate-800 rounded-xl",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "px-2 text-slate-500 flex items-center",
			children: /* @__PURE__ */ _jsxDEV(Palette, { className: "w-3.5 h-3.5" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this), Object.keys(THEMES).map((themeKey) => {
			const theme = THEMES[themeKey];
			const isActive = currentThemeId === themeKey;
			return /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => onSelectTheme(themeKey),
				className: `px-2.5 py-1 text-xs font-medium rounded-lg transition-all ${isActive ? "bg-slate-800 text-cyan-300 shadow-sm border border-cyan-500/30" : "text-slate-400 hover:text-white hover:bg-slate-800/50"}`,
				children: theme.name.split(" ")[0]
			}, themeKey, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 11
			}, this);
		})]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsY0FBYztBQUN2QixTQUFTLGVBQWU7OztBQU94QixPQUFPLE1BQU0saUJBQStDLEVBQzFELGdCQUNBLG9CQUNJO0NBQ0osT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDYix3QkFBQyxTQUFELEVBQVMsV0FBVSxjQUFlOzs7OztFQUMvQjs7OztZQUNILE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBZSxLQUFLLGFBQWE7R0FDcEQsTUFBTSxRQUFRLE9BQU87R0FDckIsTUFBTSxXQUFXLG1CQUFtQjtHQUNwQyxPQUNFLHdCQUFDLFVBQUQ7SUFFRSxlQUFlLGNBQWMsUUFBUTtJQUNyQyxXQUFXLDZEQUNULFdBQ0ksbUVBQ0E7Y0FHTCxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQztHQUNqQixHQVREOzs7O1VBU0M7RUFFWixDQUFDLENBQ0U7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRoZW1lU2VsZWN0b3IudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUaGVtZUlkIH0gZnJvbSAnLi4vdHlwZXMvdGV0cmlzJztcbmltcG9ydCB7IFRIRU1FUyB9IGZyb20gJy4uL3V0aWxzL3RldHJpc0NvbnN0YW50cyc7XG5pbXBvcnQgeyBQYWxldHRlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIFRoZW1lU2VsZWN0b3JQcm9wcyB7XG4gIGN1cnJlbnRUaGVtZUlkOiBUaGVtZUlkO1xuICBvblNlbGVjdFRoZW1lOiAoaWQ6IFRoZW1lSWQpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBUaGVtZVNlbGVjdG9yOiBSZWFjdC5GQzxUaGVtZVNlbGVjdG9yUHJvcHM+ID0gKHtcbiAgY3VycmVudFRoZW1lSWQsXG4gIG9uU2VsZWN0VGhlbWUsXG59KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHAtMSBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC14bFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0yIHRleHQtc2xhdGUtNTAwIGZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgIDxQYWxldHRlIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgeyhPYmplY3Qua2V5cyhUSEVNRVMpIGFzIFRoZW1lSWRbXSkubWFwKCh0aGVtZUtleSkgPT4ge1xuICAgICAgICBjb25zdCB0aGVtZSA9IFRIRU1FU1t0aGVtZUtleV07XG4gICAgICAgIGNvbnN0IGlzQWN0aXZlID0gY3VycmVudFRoZW1lSWQgPT09IHRoZW1lS2V5O1xuICAgICAgICByZXR1cm4gKFxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIGtleT17dGhlbWVLZXl9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvblNlbGVjdFRoZW1lKHRoZW1lS2V5KX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHRleHQteHMgZm9udC1tZWRpdW0gcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBpc0FjdGl2ZVxuICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LWN5YW4tMzAwIHNoYWRvdy1zbSBib3JkZXIgYm9yZGVyLWN5YW4tNTAwLzMwJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtODAwLzUwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge3RoZW1lLm5hbWUuc3BsaXQoJyAnKVswXX1cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKTtcbiAgICAgIH0pfVxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==