const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
var _jsxFileName = "/app/applet/src/components/ScoreBoard.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const ScoreBoard = ({ stats, gameMode, highScores, zenSpeed, onZenSpeedChange }) => {
	// Format milliseconds into MM:SS.ms
	const formatTime = (ms) => {
		const totalSecs = Math.floor(ms / 1e3);
		const minutes = Math.floor(totalSecs / 60);
		const seconds = totalSecs % 60;
		const centiseconds = Math.floor(ms % 1e3 / 10);
		return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}.${centiseconds.toString().padStart(2, "0")}`;
	};
	const formatCountdown = (secs) => {
		if (secs === undefined) return "02:00";
		const m = Math.floor(secs / 60);
		const s = secs % 60;
		return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
	};
	// Find high score for this mode
	const currentModeHighScore = highScores.find((h) => h.mode === gameMode)?.score || 0;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col gap-3 w-full",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-1",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "SCORE" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-slate-500 font-mono",
						children: ["TOP: ", currentModeHighScore.toLocaleString()]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "font-mono text-2xl font-black text-white tabular-nums tracking-tight",
					children: stats.score.toLocaleString()
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 41,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-0.5",
						children: "LEVEL"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "font-mono text-xl font-bold text-cyan-400 tabular-nums",
						children: stats.level
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "block text-[11px] text-slate-400 font-bold uppercase tracking-wider mb-0.5",
						children: "LINES"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "font-mono text-xl font-bold text-amber-400 tabular-nums",
						children: stats.lines
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			gameMode === "sprint" && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-2xl bg-slate-900/60 border border-emerald-500/30 backdrop-blur-md shadow-lg",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-[11px] text-emerald-400 font-bold uppercase tracking-wider mb-1",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "SPRINT (40L)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "font-mono tabular-nums text-white",
						children: [stats.remainingLines, " LEFT"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "font-mono text-lg font-bold text-white tabular-nums",
					children: formatTime(stats.elapsedTime)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this),
			gameMode === "ultra" && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-2xl bg-slate-900/60 border border-rose-500/30 backdrop-blur-md shadow-lg",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between text-[11px] text-rose-400 font-bold uppercase tracking-wider mb-1",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "ULTRA TIMER" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[10px] text-rose-300 font-mono",
						children: "2 MINS"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "font-mono text-2xl font-black text-rose-400 tabular-nums animate-pulse",
					children: formatCountdown(stats.remainingTime)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 82,
				columnNumber: 9
			}, this),
			gameMode === "zen" && onZenSpeedChange && /* @__PURE__ */ _jsxDEV("div", {
				className: "p-3 rounded-2xl bg-slate-900/60 border border-purple-500/30 backdrop-blur-md shadow-lg",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center justify-between text-[11px] text-purple-400 font-bold uppercase tracking-wider mb-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "ZEN GRAVITY" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "font-mono text-[10px] text-purple-300",
							children: [zenSpeed, "ms"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "range",
						min: "50",
						max: "1200",
						step: "50",
						value: zenSpeed,
						onChange: (e) => onZenSpeedChange(Number(e.target.value)),
						className: "w-full accent-purple-400 cursor-pointer h-1.5 bg-slate-700 rounded-lg"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-between text-[9px] text-slate-500 font-mono mt-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Fast (50ms)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Relaxed (1200ms)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 9
			}, this),
			(stats.currentCombo > 0 || stats.backToBack) && /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between px-3 py-2 rounded-xl bg-cyan-950/40 border border-cyan-500/40 text-xs",
				children: [stats.currentCombo > 0 && /* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono font-bold text-cyan-300",
					children: ["COMBO x", stats.currentCombo + 1]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 119,
					columnNumber: 13
				}, this), stats.backToBack && /* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono font-bold text-amber-300 text-[11px]",
					children: "B2B ACTIVE"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFXbEIsT0FBTyxNQUFNLGNBQXlDLEVBQ3BELE9BQ0EsVUFDQSxZQUNBLFVBQ0EsdUJBQ0k7O0NBRUosTUFBTSxjQUFjLE9BQXVCO0VBQ3pDLE1BQU0sWUFBWSxLQUFLLE1BQU0sS0FBSyxHQUFJO0VBQ3RDLE1BQU0sVUFBVSxLQUFLLE1BQU0sWUFBWSxFQUFFO0VBQ3pDLE1BQU0sVUFBVSxZQUFZO0VBQzVCLE1BQU0sZUFBZSxLQUFLLE1BQU8sS0FBSyxNQUFRLEVBQUU7RUFDaEQsT0FBTyxHQUFHLFFBQVEsU0FBUyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxHQUFHLFFBQVEsU0FBUyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsRUFBRSxHQUFHLGFBQWEsU0FBUyxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUc7Q0FDakk7Q0FFQSxNQUFNLG1CQUFtQixTQUEwQjtFQUNqRCxJQUFJLFNBQVMsV0FBVyxPQUFPO0VBQy9CLE1BQU0sSUFBSSxLQUFLLE1BQU0sT0FBTyxFQUFFO0VBQzlCLE1BQU0sSUFBSSxPQUFPO0VBQ2pCLE9BQU8sR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBQ3pFOztDQUdBLE1BQU0sdUJBQXVCLFdBQVcsTUFBTSxNQUFNLEVBQUUsU0FBUyxRQUFRLENBQUMsRUFBRSxTQUFTO0NBRW5GLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFFBQVc7Ozs7ZUFDakIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCLENBQXVELFNBQU0scUJBQXFCLGVBQWUsQ0FBUTs7Ozs7YUFDdEc7Ozs7O2NBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixNQUFNLE1BQU0sZUFBZTtJQUN6Qjs7OztZQUNGOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUE2RTtLQUFXOzs7O2VBQ3hHLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLE1BQU07S0FDSjs7OzthQUNGOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBNkU7S0FBVzs7OztlQUN4Ryx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixNQUFNO0tBQ0o7Ozs7YUFDRjs7Ozs7WUFDRjs7Ozs7O0dBR0osYUFBYSxZQUNaLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2VBQ3hCLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUFxRCxNQUFNLGdCQUFlLE9BQVc7Ozs7O2FBQ2xGOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osV0FBVyxNQUFNLFdBQVc7SUFDMUI7Ozs7WUFDRjs7Ozs7O0dBR04sYUFBYSxXQUNaLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O2VBQ3ZCLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzQztLQUFZOzs7O2FBQy9EOzs7OztjQUNMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZ0JBQWdCLE1BQU0sYUFBYTtJQUNqQzs7OztZQUNGOzs7Ozs7R0FHTixhQUFhLFNBQVMsb0JBQ3JCLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztnQkFDdkIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQXlELFVBQVMsSUFBUTs7Ozs7Y0FDdkU7Ozs7OztLQUNMLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsS0FBSTtNQUNKLEtBQUk7TUFDSixNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTSxpQkFBaUIsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO01BQ3hELFdBQVU7S0FDWDs7Ozs7S0FDRCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztnQkFDdkIsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztjQUN6Qjs7Ozs7O0lBQ0Y7Ozs7OztJQUlMLE1BQU0sZUFBZSxLQUFLLE1BQU0sZUFDaEMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNHLE1BQU0sZUFBZSxLQUNwQix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFoQixDQUFvRCxXQUMxQyxNQUFNLGVBQWUsQ0FDekI7Ozs7O2NBRVAsTUFBTSxjQUNMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWlEO0lBRTNEOzs7O1lBRUw7Ozs7OztFQUVKOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTY29yZUJvYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgR2FtZVN0YXRzLCBHYW1lTW9kZSwgSGlnaFNjb3JlRW50cnkgfSBmcm9tICcuLi90eXBlcy90ZXRyaXMnO1xuXG5pbnRlcmZhY2UgU2NvcmVCb2FyZFByb3BzIHtcbiAgc3RhdHM6IEdhbWVTdGF0cztcbiAgZ2FtZU1vZGU6IEdhbWVNb2RlO1xuICBoaWdoU2NvcmVzOiBIaWdoU2NvcmVFbnRyeVtdO1xuICB6ZW5TcGVlZDogbnVtYmVyO1xuICBvblplblNwZWVkQ2hhbmdlPzogKHNwZWVkOiBudW1iZXIpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTY29yZUJvYXJkOiBSZWFjdC5GQzxTY29yZUJvYXJkUHJvcHM+ID0gKHtcbiAgc3RhdHMsXG4gIGdhbWVNb2RlLFxuICBoaWdoU2NvcmVzLFxuICB6ZW5TcGVlZCxcbiAgb25aZW5TcGVlZENoYW5nZSxcbn0pID0+IHtcbiAgLy8gRm9ybWF0IG1pbGxpc2Vjb25kcyBpbnRvIE1NOlNTLm1zXG4gIGNvbnN0IGZvcm1hdFRpbWUgPSAobXM6IG51bWJlcik6IHN0cmluZyA9PiB7XG4gICAgY29uc3QgdG90YWxTZWNzID0gTWF0aC5mbG9vcihtcyAvIDEwMDApO1xuICAgIGNvbnN0IG1pbnV0ZXMgPSBNYXRoLmZsb29yKHRvdGFsU2VjcyAvIDYwKTtcbiAgICBjb25zdCBzZWNvbmRzID0gdG90YWxTZWNzICUgNjA7XG4gICAgY29uc3QgY2VudGlzZWNvbmRzID0gTWF0aC5mbG9vcigobXMgJSAxMDAwKSAvIDEwKTtcbiAgICByZXR1cm4gYCR7bWludXRlcy50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJyl9OiR7c2Vjb25kcy50b1N0cmluZygpLnBhZFN0YXJ0KDIsICcwJyl9LiR7Y2VudGlzZWNvbmRzLnRvU3RyaW5nKCkucGFkU3RhcnQoMiwgJzAnKX1gO1xuICB9O1xuXG4gIGNvbnN0IGZvcm1hdENvdW50ZG93biA9IChzZWNzPzogbnVtYmVyKTogc3RyaW5nID0+IHtcbiAgICBpZiAoc2VjcyA9PT0gdW5kZWZpbmVkKSByZXR1cm4gJzAyOjAwJztcbiAgICBjb25zdCBtID0gTWF0aC5mbG9vcihzZWNzIC8gNjApO1xuICAgIGNvbnN0IHMgPSBzZWNzICUgNjA7XG4gICAgcmV0dXJuIGAke20udG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfToke3MudG9TdHJpbmcoKS5wYWRTdGFydCgyLCAnMCcpfWA7XG4gIH07XG5cbiAgLy8gRmluZCBoaWdoIHNjb3JlIGZvciB0aGlzIG1vZGVcbiAgY29uc3QgY3VycmVudE1vZGVIaWdoU2NvcmUgPSBoaWdoU2NvcmVzLmZpbmQoKGgpID0+IGgubW9kZSA9PT0gZ2FtZU1vZGUpPy5zY29yZSB8fCAwO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0zIHctZnVsbFwiPlxuICAgICAgey8qIFByaW1hcnkgU2NvcmUgJiBCZXN0ICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMuNSByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGdcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0xXCI+XG4gICAgICAgICAgPHNwYW4+U0NPUkU8L3NwYW4+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vXCI+VE9QOiB7Y3VycmVudE1vZGVIaWdoU2NvcmUudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtd2hpdGUgdGFidWxhci1udW1zIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAge3N0YXRzLnNjb3JlLnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBMZXZlbCAmIExpbmVzICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTkwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBiYWNrZHJvcC1ibHVyLW1kIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMC41XCI+TEVWRUw8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14bCBmb250LWJvbGQgdGV4dC1jeWFuLTQwMCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgIHtzdGF0cy5sZXZlbH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItc2xhdGUtODAwLzgwIGJhY2tkcm9wLWJsdXItbWQgc2hhZG93LWxnXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBtYi0wLjVcIj5MSU5FUzwvc3Bhbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgIHtzdGF0cy5saW5lc31cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIEdhbWUgTW9kZSBTcGVjaWZpYyBUZWxlbWV0cnkgKi99XG4gICAgICB7Z2FtZU1vZGUgPT09ICdzcHJpbnQnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvMzAgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LWVtZXJhbGQtNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlxuICAgICAgICAgICAgPHNwYW4+U1BSSU5UICg0MEwpPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtcyB0ZXh0LXdoaXRlXCI+e3N0YXRzLnJlbWFpbmluZ0xpbmVzfSBMRUZUPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGUgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICB7Zm9ybWF0VGltZShzdGF0cy5lbGFwc2VkVGltZSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2dhbWVNb2RlID09PSAndWx0cmEnICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItcm9zZS01MDAvMzAgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXJvc2UtNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgbWItMVwiPlxuICAgICAgICAgICAgPHNwYW4+VUxUUkEgVElNRVI8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXJvc2UtMzAwIGZvbnQtbW9ub1wiPjIgTUlOUzwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtcm9zZS00MDAgdGFidWxhci1udW1zIGFuaW1hdGUtcHVsc2VcIj5cbiAgICAgICAgICAgIHtmb3JtYXRDb3VudGRvd24oc3RhdHMucmVtYWluaW5nVGltZSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2dhbWVNb2RlID09PSAnemVuJyAmJiBvblplblNwZWVkQ2hhbmdlICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgcm91bmRlZC0yeGwgYmctc2xhdGUtOTAwLzYwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMC8zMCBiYWNrZHJvcC1ibHVyLW1kIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzExcHhdIHRleHQtcHVycGxlLTQwMCBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIG1iLTFcIj5cbiAgICAgICAgICAgIDxzcGFuPlpFTiBHUkFWSVRZPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQtWzEwcHhdIHRleHQtcHVycGxlLTMwMFwiPnt6ZW5TcGVlZH1tczwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgIHR5cGU9XCJyYW5nZVwiXG4gICAgICAgICAgICBtaW49XCI1MFwiXG4gICAgICAgICAgICBtYXg9XCIxMjAwXCJcbiAgICAgICAgICAgIHN0ZXA9XCI1MFwiXG4gICAgICAgICAgICB2YWx1ZT17emVuU3BlZWR9XG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IG9uWmVuU3BlZWRDaGFuZ2UoTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYWNjZW50LXB1cnBsZS00MDAgY3Vyc29yLXBvaW50ZXIgaC0xLjUgYmctc2xhdGUtNzAwIHJvdW5kZWQtbGdcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVs5cHhdIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ubyBtdC0xXCI+XG4gICAgICAgICAgICA8c3Bhbj5GYXN0ICg1MG1zKTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuPlJlbGF4ZWQgKDEyMDBtcyk8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAgey8qIENvbWJvICYgQjJCIHN0cmVhayAqL31cbiAgICAgIHsoc3RhdHMuY3VycmVudENvbWJvID4gMCB8fCBzdGF0cy5iYWNrVG9CYWNrKSAmJiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTMgcHktMiByb3VuZGVkLXhsIGJnLWN5YW4tOTUwLzQwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNDAgdGV4dC14c1wiPlxuICAgICAgICAgIHtzdGF0cy5jdXJyZW50Q29tYm8gPiAwICYmIChcbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1jeWFuLTMwMFwiPlxuICAgICAgICAgICAgICBDT01CTyB4e3N0YXRzLmN1cnJlbnRDb21ibyArIDF9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICB7c3RhdHMuYmFja1RvQmFjayAmJiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtYW1iZXItMzAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgIEIyQiBBQ1RJVkVcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19