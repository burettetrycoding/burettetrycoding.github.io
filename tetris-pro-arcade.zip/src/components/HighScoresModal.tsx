const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { X, Trophy, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
var _jsxFileName = "/app/applet/src/components/HighScoresModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const HighScoresModal = ({ isOpen, onClose, scores, onClearScores }) => {
	const [filterMode, setFilterMode] = useState("all");
	if (!isOpen) return null;
	const filteredScores = filterMode === "all" ? scores : scores.filter((s) => s.mode === filterMode);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-6 py-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 rounded-xl bg-amber-500/10 text-amber-400",
							children: /* @__PURE__ */ _jsxDEV(Trophy, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-white",
							children: "Arcade Hall of Fame"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Local high scores & record runs"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 35,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-1.5 px-6 py-3 border-b border-slate-800 bg-slate-950/40 text-xs",
					children: [
						"all",
						"marathon",
						"sprint",
						"ultra"
					].map((m) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setFilterMode(m),
						className: `px-3 py-1.5 rounded-lg font-medium capitalize transition-colors ${filterMode === m ? "bg-slate-800 text-amber-400 shadow-sm border border-amber-500/30" : "text-slate-400 hover:text-white"}`,
						children: m === "all" ? "All Modes" : m
					}, m, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 49,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6",
					children: filteredScores.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "text-center py-12 text-slate-500 text-sm",
						children: "No recorded scores yet. Start playing to set a high score!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: filteredScores.map((entry, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 transition-colors",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: `font-mono text-xs font-bold w-6 text-center ${idx === 0 ? "text-amber-400" : idx === 1 ? "text-slate-300" : idx === 2 ? "text-amber-600" : "text-slate-600"}`,
									children: ["#", idx + 1]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "font-mono font-bold text-white text-sm tabular-nums",
									children: entry.score.toLocaleString()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-500 flex items-center gap-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "uppercase font-semibold text-cyan-400",
											children: entry.mode
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 97,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 98,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: [entry.lines, " lines"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 99,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "·" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 100,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: ["Lvl ", entry.level] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 101,
											columnNumber: 25
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 23
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 92,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[11px] font-mono text-slate-500",
								children: entry.date
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 106,
								columnNumber: 19
							}, this)]
						}, entry.id, true, {
							fileName: _jsxFileName,
							lineNumber: 74,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950",
					children: [filteredScores.length > 0 ? /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClearScores,
						className: "flex items-center gap-1.5 text-xs text-rose-400 hover:text-rose-300 font-medium transition-colors",
						children: [/* @__PURE__ */ _jsxDEV(Trash2, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Clear History" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("div", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 116,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLEdBQUcsUUFBUSxjQUFjOzs7QUFVbEMsT0FBTyxNQUFNLG1CQUFtRCxFQUM5RCxRQUNBLFNBQ0EsUUFDQSxvQkFDSTtDQUNKLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUEyQixLQUFLO0NBRXBFLElBQUksQ0FBQyxRQUFRLE9BQU87Q0FFcEIsTUFBTSxpQkFBaUIsZUFBZSxRQUNsQyxTQUNBLE9BQU8sUUFBUSxNQUFNLEVBQUUsU0FBUyxVQUFVO0NBRTlDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsUUFBRCxFQUFRLFdBQVUsVUFBVzs7Ozs7TUFDMUI7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQztNQUF1Qjs7OztnQkFDdEUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BQWtDOzs7O2NBQ3JFOzs7O2NBQ0Y7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0tBQ2xCOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1g7TUFBQztNQUFPO01BQVk7TUFBVTtLQUFPLENBQUMsQ0FBVyxLQUFLLE1BQ3RELHdCQUFDLFVBQUQ7TUFFRSxlQUFlLGNBQWMsQ0FBQztNQUM5QixXQUFXLG1FQUNULGVBQWUsSUFDWCxxRUFDQTtnQkFHTCxNQUFNLFFBQVEsY0FBYztLQUN2QixHQVREOzs7O1lBU0MsQ0FDVDtJQUNFOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osZUFBZSxXQUFXLElBQ3pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUEyQztLQUVyRDs7OztnQkFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixlQUFlLEtBQUssT0FBTyxRQUMxQix3QkFBQyxPQUFEO09BRUUsV0FBVTtpQkFGWixDQUlFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUNFLFdBQVcsK0NBQ1QsUUFBUSxJQUNKLG1CQUNBLFFBQVEsSUFDUixtQkFDQSxRQUFRLElBQ1IsbUJBQ0E7bUJBUlIsQ0FVQyxLQUNHLE1BQU0sQ0FDSjs7Ozs7a0JBQ04sd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLE1BQU0sTUFBTSxlQUFlO1FBQ3pCOzs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXlDLE1BQU07VUFBVzs7Ozs7VUFDMUUsd0JBQUMsUUFBRCxZQUFNLElBQU87Ozs7O1VBQ2Isd0JBQUMsUUFBRCxhQUFPLE1BQU0sT0FBTSxRQUFZOzs7OztVQUMvQix3QkFBQyxRQUFELFlBQU0sSUFBTzs7Ozs7VUFDYix3QkFBQyxRQUFELGFBQU0sUUFBSyxNQUFNLEtBQVk7Ozs7O1NBQzFCOzs7OztnQkFDRjs7OztnQkFDRjs7Ozs7aUJBRUwsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2IsTUFBTTtPQUNIOzs7O2VBQ0g7U0FsQ0UsTUFBTTs7OzthQWtDUixDQUNOO0tBQ0U7Ozs7O0lBRUo7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNHLGVBQWUsU0FBUyxJQUN2Qix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRlosQ0FJRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2dCQUNqQyx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2NBQ25COzs7OztnQkFFUix3QkFBQyxPQUFELENBQU07Ozs7ZUFFUix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSGlnaFNjb3Jlc01vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBYLCBUcm9waHksIFRyYXNoMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyBIaWdoU2NvcmVFbnRyeSwgR2FtZU1vZGUgfSBmcm9tICcuLi90eXBlcy90ZXRyaXMnO1xuXG5pbnRlcmZhY2UgSGlnaFNjb3Jlc01vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIHNjb3JlczogSGlnaFNjb3JlRW50cnlbXTtcbiAgb25DbGVhclNjb3JlczogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEhpZ2hTY29yZXNNb2RhbDogUmVhY3QuRkM8SGlnaFNjb3Jlc01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBzY29yZXMsXG4gIG9uQ2xlYXJTY29yZXMsXG59KSA9PiB7XG4gIGNvbnN0IFtmaWx0ZXJNb2RlLCBzZXRGaWx0ZXJNb2RlXSA9IHVzZVN0YXRlPEdhbWVNb2RlIHwgJ2FsbCc+KCdhbGwnKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgZmlsdGVyZWRTY29yZXMgPSBmaWx0ZXJNb2RlID09PSAnYWxsJ1xuICAgID8gc2NvcmVzXG4gICAgOiBzY29yZXMuZmlsdGVyKChzKSA9PiBzLm1vZGUgPT09IGZpbHRlck1vZGUpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcC00IGJnLWJsYWNrLzgwIGJhY2tkcm9wLWJsdXItbWQgYW5pbWF0ZS1mYWRlLWluXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctZnVsbCBtYXgtdy1sZyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgc2hhZG93LTJ4bCBvdmVyZmxvdy1oaWRkZW4gZmxleCBmbGV4LWNvbCBtYXgtaC1bODV2aF1cIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLWFtYmVyLTUwMC8xMCB0ZXh0LWFtYmVyLTQwMFwiPlxuICAgICAgICAgICAgICA8VHJvcGh5IGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+QXJjYWRlIEhhbGwgb2YgRmFtZTwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5Mb2NhbCBoaWdoIHNjb3JlcyAmIHJlY29yZCBydW5zPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRmlsdGVyIFRhYnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC02IHB5LTMgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTAvNDAgdGV4dC14c1wiPlxuICAgICAgICAgIHsoWydhbGwnLCAnbWFyYXRob24nLCAnc3ByaW50JywgJ3VsdHJhJ10gYXMgY29uc3QpLm1hcCgobSkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e219XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlck1vZGUobSl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQtbGcgZm9udC1tZWRpdW0gY2FwaXRhbGl6ZSB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICAgIGZpbHRlck1vZGUgPT09IG1cbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LWFtYmVyLTQwMCBzaGFkb3ctc20gYm9yZGVyIGJvcmRlci1hbWJlci01MDAvMzAnXG4gICAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge20gPT09ICdhbGwnID8gJ0FsbCBNb2RlcycgOiBtfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTY29yZXMgTGlzdCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNlwiPlxuICAgICAgICAgIHtmaWx0ZXJlZFNjb3Jlcy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHB5LTEyIHRleHQtc2xhdGUtNTAwIHRleHQtc21cIj5cbiAgICAgICAgICAgICAgTm8gcmVjb3JkZWQgc2NvcmVzIHlldC4gU3RhcnQgcGxheWluZyB0byBzZXQgYSBoaWdoIHNjb3JlIVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIHtmaWx0ZXJlZFNjb3Jlcy5tYXAoKGVudHJ5LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e2VudHJ5LmlkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC84MCBob3Zlcjpib3JkZXItc2xhdGUtNzAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHctNiB0ZXh0LWNlbnRlciAke1xuICAgICAgICAgICAgICAgICAgICAgICAgaWR4ID09PSAwXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3RleHQtYW1iZXItNDAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGlkeCA9PT0gMVxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICd0ZXh0LXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpZHggPT09IDJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgPyAndGV4dC1hbWJlci02MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNjAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgI3tpZHggKyAxfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1ib2xkIHRleHQtd2hpdGUgdGV4dC1zbSB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtlbnRyeS5zY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LXNlbWlib2xkIHRleHQtY3lhbi00MDBcIj57ZW50cnkubW9kZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntlbnRyeS5saW5lc30gbGluZXM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Ctzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkx2bCB7ZW50cnkubGV2ZWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LW1vbm8gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2VudHJ5LmRhdGV9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcHgtNiBweS0zIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgYmctc2xhdGUtOTUwXCI+XG4gICAgICAgICAge2ZpbHRlcmVkU2NvcmVzLmxlbmd0aCA+IDAgPyAoXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xlYXJTY29yZXN9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC14cyB0ZXh0LXJvc2UtNDAwIGhvdmVyOnRleHQtcm9zZS0zMDAgZm9udC1tZWRpdW0gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VHJhc2gyIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+Q2xlYXIgSGlzdG9yeTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IC8+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ2xvc2VcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=