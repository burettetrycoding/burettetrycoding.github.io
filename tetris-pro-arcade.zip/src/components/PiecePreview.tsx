const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { TETROMINOES } from "/src/utils/tetrisConstants.ts";
var _jsxFileName = "/app/applet/src/components/PiecePreview.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const PiecePreview = ({ type, theme, size = "md", disabled = false }) => {
	const cellSize = size === "sm" ? "w-4 h-4" : "w-5 h-5";
	const containerSize = size === "sm" ? "w-20 h-16" : "w-24 h-20";
	if (!type) {
		return /* @__PURE__ */ _jsxDEV("div", {
			className: `${containerSize} flex items-center justify-center rounded-xl bg-slate-900/40 border border-slate-800/60`,
			children: /* @__PURE__ */ _jsxDEV("span", {
				className: "text-xs text-slate-600 font-mono",
				children: "-"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 7
		}, this);
	}
	// Get initial rotation coords
	const coords = TETROMINOES[type][0];
	const color = theme.colors[type];
	// Calculate bounding box to center properly
	let minX = 4, maxX = 0, minY = 4, maxY = 0;
	coords.forEach((c) => {
		if (c.x < minX) minX = c.x;
		if (c.x > maxX) maxX = c.x;
		if (c.y < minY) minY = c.y;
		if (c.y > maxY) maxY = c.y;
	});
	const width = maxX - minX + 1;
	const height = maxY - minY + 1;
	// Center inside 4x4 matrix
	const startX = Math.floor((4 - width) / 2) - minX;
	const startY = Math.floor((4 - height) / 2) - minY;
	const pieceSet = new Set(coords.map((c) => `${c.x + startX},${c.y + startY}`));
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `${containerSize} flex items-center justify-center rounded-xl bg-slate-900/40 border border-slate-800/80 p-1.5 transition-all ${disabled ? "opacity-40 grayscale" : "opacity-100"}`,
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-4 grid-rows-4 gap-0.5",
			children: Array.from({ length: 4 }).map((_, y) => Array.from({ length: 4 }).map((_, x) => {
				const isFilled = pieceSet.has(`${x},${y}`);
				return /* @__PURE__ */ _jsxDEV("div", {
					className: `${cellSize} rounded-[2px] relative transition-colors`,
					style: {
						backgroundColor: isFilled ? color.primary : "transparent",
						border: isFilled ? `1px solid ${color.border}` : "1px solid transparent",
						boxShadow: isFilled && color.glow ? `0 0 6px ${color.glow}` : undefined
					},
					children: isFilled && /* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0.5 rounded-[1px] bg-gradient-to-br from-white/30 to-transparent pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 19
					}, this)
				}, `${x}-${y}`, false, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 15
				}, this);
			}))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsbUJBQW1COzs7QUFTNUIsT0FBTyxNQUFNLGdCQUE2QyxFQUN4RCxNQUNBLE9BQ0EsT0FBTyxNQUNQLFdBQVcsWUFDUDtDQUNKLE1BQU0sV0FBVyxTQUFTLE9BQU8sWUFBWTtDQUM3QyxNQUFNLGdCQUFnQixTQUFTLE9BQU8sY0FBYztDQUVwRCxJQUFJLENBQUMsTUFBTTtFQUNULE9BQ0Usd0JBQUMsT0FBRDtHQUFLLFdBQVcsR0FBRyxjQUFjO2FBQy9CLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQW1DO0dBQU87Ozs7O0VBQ3ZEOzs7OztDQUVUOztDQUdBLE1BQU0sU0FBUyxZQUFZLEtBQUssQ0FBQztDQUNqQyxNQUFNLFFBQVEsTUFBTSxPQUFPOztDQUczQixJQUFJLE9BQU8sR0FBRyxPQUFPLEdBQUcsT0FBTyxHQUFHLE9BQU87Q0FDekMsT0FBTyxTQUFTLE1BQU07RUFDcEIsSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEVBQUU7RUFDekIsSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEVBQUU7RUFDekIsSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEVBQUU7RUFDekIsSUFBSSxFQUFFLElBQUksTUFBTSxPQUFPLEVBQUU7Q0FDM0IsQ0FBQztDQUVELE1BQU0sUUFBUSxPQUFPLE9BQU87Q0FDNUIsTUFBTSxTQUFTLE9BQU8sT0FBTzs7Q0FHN0IsTUFBTSxTQUFTLEtBQUssT0FBTyxJQUFJLFNBQVMsQ0FBQyxJQUFJO0NBQzdDLE1BQU0sU0FBUyxLQUFLLE9BQU8sSUFBSSxVQUFVLENBQUMsSUFBSTtDQUU5QyxNQUFNLFdBQVcsSUFBSSxJQUFJLE9BQU8sS0FBSyxNQUFNLEdBQUcsRUFBRSxJQUFJLE9BQU8sR0FBRyxFQUFFLElBQUksUUFBUSxDQUFDO0NBRTdFLE9BQ0Usd0JBQUMsT0FBRDtFQUNFLFdBQVcsR0FBRyxjQUFjLCtHQUMxQixXQUFXLHlCQUF5QjtZQUd0Qyx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLE1BQU0sS0FBSyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsTUFDakMsTUFBTSxLQUFLLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUFNO0lBQ3RDLE1BQU0sV0FBVyxTQUFTLElBQUksR0FBRyxFQUFFLEdBQUcsR0FBRztJQUN6QyxPQUNFLHdCQUFDLE9BQUQ7S0FFRSxXQUFXLEdBQUcsU0FBUztLQUN2QixPQUFPO01BQ0wsaUJBQWlCLFdBQVcsTUFBTSxVQUFVO01BQzVDLFFBQVEsV0FBVyxhQUFhLE1BQU0sV0FBVztNQUNqRCxXQUFXLFlBQVksTUFBTSxPQUFPLFdBQVcsTUFBTSxTQUFTO0tBQ2hFO2VBRUMsWUFDQyx3QkFBQyxPQUFELEVBQUssV0FBVSxzR0FBdUc7Ozs7O0lBRXJILEdBWEUsR0FBRyxFQUFFLEdBQUc7Ozs7V0FXVjtHQUVULENBQUMsQ0FDSDtFQUNHOzs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBpZWNlUHJldmlldy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRldHJvbWlub1R5cGUsIFRoZW1lQ29uZmlnIH0gZnJvbSAnLi4vdHlwZXMvdGV0cmlzJztcbmltcG9ydCB7IFRFVFJPTUlOT0VTIH0gZnJvbSAnLi4vdXRpbHMvdGV0cmlzQ29uc3RhbnRzJztcblxuaW50ZXJmYWNlIFBpZWNlUHJldmlld1Byb3BzIHtcbiAgdHlwZTogVGV0cm9taW5vVHlwZSB8IG51bGw7XG4gIHRoZW1lOiBUaGVtZUNvbmZpZztcbiAgc2l6ZT86ICdzbScgfCAnbWQnO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjb25zdCBQaWVjZVByZXZpZXc6IFJlYWN0LkZDPFBpZWNlUHJldmlld1Byb3BzPiA9ICh7XG4gIHR5cGUsXG4gIHRoZW1lLFxuICBzaXplID0gJ21kJyxcbiAgZGlzYWJsZWQgPSBmYWxzZSxcbn0pID0+IHtcbiAgY29uc3QgY2VsbFNpemUgPSBzaXplID09PSAnc20nID8gJ3ctNCBoLTQnIDogJ3ctNSBoLTUnO1xuICBjb25zdCBjb250YWluZXJTaXplID0gc2l6ZSA9PT0gJ3NtJyA/ICd3LTIwIGgtMTYnIDogJ3ctMjQgaC0yMCc7XG5cbiAgaWYgKCF0eXBlKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjb250YWluZXJTaXplfSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLXhsIGJnLXNsYXRlLTkwMC80MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMC82MGB9PlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGZvbnQtbW9ub1wiPi08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICApO1xuICB9XG5cbiAgLy8gR2V0IGluaXRpYWwgcm90YXRpb24gY29vcmRzXG4gIGNvbnN0IGNvb3JkcyA9IFRFVFJPTUlOT0VTW3R5cGVdWzBdO1xuICBjb25zdCBjb2xvciA9IHRoZW1lLmNvbG9yc1t0eXBlXTtcblxuICAvLyBDYWxjdWxhdGUgYm91bmRpbmcgYm94IHRvIGNlbnRlciBwcm9wZXJseVxuICBsZXQgbWluWCA9IDQsIG1heFggPSAwLCBtaW5ZID0gNCwgbWF4WSA9IDA7XG4gIGNvb3Jkcy5mb3JFYWNoKChjKSA9PiB7XG4gICAgaWYgKGMueCA8IG1pblgpIG1pblggPSBjLng7XG4gICAgaWYgKGMueCA+IG1heFgpIG1heFggPSBjLng7XG4gICAgaWYgKGMueSA8IG1pblkpIG1pblkgPSBjLnk7XG4gICAgaWYgKGMueSA+IG1heFkpIG1heFkgPSBjLnk7XG4gIH0pO1xuXG4gIGNvbnN0IHdpZHRoID0gbWF4WCAtIG1pblggKyAxO1xuICBjb25zdCBoZWlnaHQgPSBtYXhZIC0gbWluWSArIDE7XG5cbiAgLy8gQ2VudGVyIGluc2lkZSA0eDQgbWF0cml4XG4gIGNvbnN0IHN0YXJ0WCA9IE1hdGguZmxvb3IoKDQgLSB3aWR0aCkgLyAyKSAtIG1pblg7XG4gIGNvbnN0IHN0YXJ0WSA9IE1hdGguZmxvb3IoKDQgLSBoZWlnaHQpIC8gMikgLSBtaW5ZO1xuXG4gIGNvbnN0IHBpZWNlU2V0ID0gbmV3IFNldChjb29yZHMubWFwKChjKSA9PiBgJHtjLnggKyBzdGFydFh9LCR7Yy55ICsgc3RhcnRZfWApKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YCR7Y29udGFpbmVyU2l6ZX0gZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC14bCBiZy1zbGF0ZS05MDAvNDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgcC0xLjUgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgZGlzYWJsZWQgPyAnb3BhY2l0eS00MCBncmF5c2NhbGUnIDogJ29wYWNpdHktMTAwJ1xuICAgICAgfWB9XG4gICAgPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy00IGdyaWQtcm93cy00IGdhcC0wLjVcIj5cbiAgICAgICAge0FycmF5LmZyb20oeyBsZW5ndGg6IDQgfSkubWFwKChfLCB5KSA9PlxuICAgICAgICAgIEFycmF5LmZyb20oeyBsZW5ndGg6IDQgfSkubWFwKChfLCB4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpc0ZpbGxlZCA9IHBpZWNlU2V0LmhhcyhgJHt4fSwke3l9YCk7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtgJHt4fS0ke3l9YH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Ake2NlbGxTaXplfSByb3VuZGVkLVsycHhdIHJlbGF0aXZlIHRyYW5zaXRpb24tY29sb3JzYH1cbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBpc0ZpbGxlZCA/IGNvbG9yLnByaW1hcnkgOiAndHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBpc0ZpbGxlZCA/IGAxcHggc29saWQgJHtjb2xvci5ib3JkZXJ9YCA6ICcxcHggc29saWQgdHJhbnNwYXJlbnQnLFxuICAgICAgICAgICAgICAgICAgYm94U2hhZG93OiBpc0ZpbGxlZCAmJiBjb2xvci5nbG93ID8gYDAgMCA2cHggJHtjb2xvci5nbG93fWAgOiB1bmRlZmluZWQsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtpc0ZpbGxlZCAmJiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAuNSByb3VuZGVkLVsxcHhdIGJnLWdyYWRpZW50LXRvLWJyIGZyb20td2hpdGUvMzAgdG8tdHJhbnNwYXJlbnQgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pXG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=