const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { X, Keyboard, HelpCircle } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
var _jsxFileName = "/app/applet/src/components/KeybindingsModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const KeybindingsModal = ({ isOpen, onClose, keybindings }) => {
	if (!isOpen) return null;
	const controlRows = [
		{
			label: "Move Left",
			keys: ["←", "A"],
			desc: "Shifts active tetromino left (holds DAS)"
		},
		{
			label: "Move Right",
			keys: ["→", "D"],
			desc: "Shifts active tetromino right (holds DAS)"
		},
		{
			label: "Soft Drop",
			keys: ["↓", "S"],
			desc: "Accelerates piece downwards (+1 pt/cell)"
		},
		{
			label: "Hard Drop",
			keys: ["Space"],
			desc: "Instant drop and lock with camera shake (+2 pts/cell)"
		},
		{
			label: "Rotate Clockwise (CW)",
			keys: [
				"↑",
				"X",
				"W"
			],
			desc: "Standard 90° CW turn with SRS kicks"
		},
		{
			label: "Rotate Counter-Clockwise (CCW)",
			keys: ["Z", "Ctrl"],
			desc: "Standard 90° CCW turn with SRS kicks"
		},
		{
			label: "Hold Piece",
			keys: ["C", "Shift"],
			desc: "Stash or swap current tetromino"
		},
		{
			label: "Pause / Resume",
			keys: ["P", "Esc"],
			desc: "Freezes game matrix & timer"
		},
		{
			label: "Restart Game",
			keys: ["R"],
			desc: "Instantly resets current matrix"
		}
	];
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-6 py-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 rounded-xl bg-cyan-500/10 text-cyan-400",
							children: /* @__PURE__ */ _jsxDEV(Keyboard, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 37,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 36,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-base font-bold text-white",
							children: "Controls & Guidelines"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 40,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Tournament guideline keyboard layout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 41,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 39,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6 space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: controlRows.map((row) => /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs font-semibold text-white",
								children: row.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[10px] text-slate-400",
								children: row.desc
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-1.5 shrink-0",
								children: row.keys.map((k) => /* @__PURE__ */ _jsxDEV("kbd", {
									className: "px-2.5 py-1 text-xs font-mono font-bold bg-slate-800 border border-slate-700 rounded-lg text-cyan-300 shadow-sm",
									children: k
								}, k, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 17
							}, this)]
						}, row.label, true, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 text-xs text-slate-400 space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-3.5 h-3.5 text-cyan-400" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 15
								}, this), " Advanced SRS Tips:"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								"• ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "T-Spins" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 17
								}, this),
								": Rotate the T-piece into tight 3-corner pockets for massive points!"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: [
								"• ",
								/* @__PURE__ */ _jsxDEV("strong", { children: "Back-to-Back (B2B)" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 17
								}, this),
								": Clearing consecutive 4-line Tetrises or T-Spins awards a 1.5x score multiplier!"
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-end px-6 py-3 border-t border-slate-800 bg-slate-950",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsR0FBRyxVQUFVLGtCQUFrQjs7O0FBU3hDLE9BQU8sTUFBTSxvQkFBcUQsRUFDaEUsUUFDQSxTQUNBLGtCQUNJO0NBQ0osSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLGNBQWM7RUFDbEI7R0FBRSxPQUFPO0dBQWEsTUFBTSxDQUFDLEtBQUssR0FBRztHQUFHLE1BQU07RUFBMkM7RUFDekY7R0FBRSxPQUFPO0dBQWMsTUFBTSxDQUFDLEtBQUssR0FBRztHQUFHLE1BQU07RUFBNEM7RUFDM0Y7R0FBRSxPQUFPO0dBQWEsTUFBTSxDQUFDLEtBQUssR0FBRztHQUFHLE1BQU07RUFBMkM7RUFDekY7R0FBRSxPQUFPO0dBQWEsTUFBTSxDQUFDLE9BQU87R0FBRyxNQUFNO0VBQXdEO0VBQ3JHO0dBQUUsT0FBTztHQUF5QixNQUFNO0lBQUM7SUFBSztJQUFLO0dBQUc7R0FBRyxNQUFNO0VBQXNDO0VBQ3JHO0dBQUUsT0FBTztHQUFrQyxNQUFNLENBQUMsS0FBSyxNQUFNO0dBQUcsTUFBTTtFQUF1QztFQUM3RztHQUFFLE9BQU87R0FBYyxNQUFNLENBQUMsS0FBSyxPQUFPO0dBQUcsTUFBTTtFQUFrQztFQUNyRjtHQUFFLE9BQU87R0FBa0IsTUFBTSxDQUFDLEtBQUssS0FBSztHQUFHLE1BQU07RUFBOEI7RUFDbkY7R0FBRSxPQUFPO0dBQWdCLE1BQU0sQ0FBQyxHQUFHO0dBQUcsTUFBTTtFQUFrQztDQUNoRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7TUFDNUI7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFpQztNQUF5Qjs7OztnQkFDeEUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BQXVDOzs7O2NBQzFFOzs7O2NBQ0Y7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0tBQ2xCOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFDWixZQUFZLEtBQUssUUFDaEIsd0JBQUMsT0FBRDtPQUVFLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQW9DLElBQUk7T0FBVzs7OztpQkFDbEUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQThCLElBQUk7T0FBVTs7OztlQUN4RDs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixJQUFJLEtBQUssS0FBSyxNQUNiLHdCQUFDLE9BQUQ7U0FFRSxXQUFVO21CQUVUO1FBQ0UsR0FKRTs7OztlQUlGLENBQ047T0FDRTs7OztlQUNGO1NBbEJFLElBQUk7Ozs7YUFrQk4sQ0FDTjtLQUNFOzs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSw0QkFBNkI7Ozs7a0JBQUMscUJBQ2hEOzs7Ozs7T0FDTix3QkFBQyxLQUFEO1FBQUc7UUFDQyx3QkFBQyxVQUFELFlBQVEsVUFBZTs7Ozs7UUFBQztPQUN6Qjs7Ozs7T0FDSCx3QkFBQyxLQUFEO1FBQUc7UUFDQyx3QkFBQyxVQUFELFlBQVEscUJBQTBCOzs7OztRQUFDO09BQ3BDOzs7OztNQUNBOzs7OzthQUNGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNMOzs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJLZXliaW5kaW5nc01vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgWCwgS2V5Ym9hcmQsIEhlbHBDaXJjbGUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgS2V5QmluZGluZ3MgfSBmcm9tICcuLi90eXBlcy90ZXRyaXMnO1xuXG5pbnRlcmZhY2UgS2V5YmluZGluZ3NNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBrZXliaW5kaW5nczogS2V5QmluZGluZ3M7XG59XG5cbmV4cG9ydCBjb25zdCBLZXliaW5kaW5nc01vZGFsOiBSZWFjdC5GQzxLZXliaW5kaW5nc01vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBrZXliaW5kaW5ncyxcbn0pID0+IHtcbiAgaWYgKCFpc09wZW4pIHJldHVybiBudWxsO1xuXG4gIGNvbnN0IGNvbnRyb2xSb3dzID0gW1xuICAgIHsgbGFiZWw6ICdNb3ZlIExlZnQnLCBrZXlzOiBbJ+KGkCcsICdBJ10sIGRlc2M6ICdTaGlmdHMgYWN0aXZlIHRldHJvbWlubyBsZWZ0IChob2xkcyBEQVMpJyB9LFxuICAgIHsgbGFiZWw6ICdNb3ZlIFJpZ2h0Jywga2V5czogWyfihpInLCAnRCddLCBkZXNjOiAnU2hpZnRzIGFjdGl2ZSB0ZXRyb21pbm8gcmlnaHQgKGhvbGRzIERBUyknIH0sXG4gICAgeyBsYWJlbDogJ1NvZnQgRHJvcCcsIGtleXM6IFsn4oaTJywgJ1MnXSwgZGVzYzogJ0FjY2VsZXJhdGVzIHBpZWNlIGRvd253YXJkcyAoKzEgcHQvY2VsbCknIH0sXG4gICAgeyBsYWJlbDogJ0hhcmQgRHJvcCcsIGtleXM6IFsnU3BhY2UnXSwgZGVzYzogJ0luc3RhbnQgZHJvcCBhbmQgbG9jayB3aXRoIGNhbWVyYSBzaGFrZSAoKzIgcHRzL2NlbGwpJyB9LFxuICAgIHsgbGFiZWw6ICdSb3RhdGUgQ2xvY2t3aXNlIChDVyknLCBrZXlzOiBbJ+KGkScsICdYJywgJ1cnXSwgZGVzYzogJ1N0YW5kYXJkIDkwwrAgQ1cgdHVybiB3aXRoIFNSUyBraWNrcycgfSxcbiAgICB7IGxhYmVsOiAnUm90YXRlIENvdW50ZXItQ2xvY2t3aXNlIChDQ1cpJywga2V5czogWydaJywgJ0N0cmwnXSwgZGVzYzogJ1N0YW5kYXJkIDkwwrAgQ0NXIHR1cm4gd2l0aCBTUlMga2lja3MnIH0sXG4gICAgeyBsYWJlbDogJ0hvbGQgUGllY2UnLCBrZXlzOiBbJ0MnLCAnU2hpZnQnXSwgZGVzYzogJ1N0YXNoIG9yIHN3YXAgY3VycmVudCB0ZXRyb21pbm8nIH0sXG4gICAgeyBsYWJlbDogJ1BhdXNlIC8gUmVzdW1lJywga2V5czogWydQJywgJ0VzYyddLCBkZXNjOiAnRnJlZXplcyBnYW1lIG1hdHJpeCAmIHRpbWVyJyB9LFxuICAgIHsgbGFiZWw6ICdSZXN0YXJ0IEdhbWUnLCBrZXlzOiBbJ1InXSwgZGVzYzogJ0luc3RhbnRseSByZXNldHMgY3VycmVudCBtYXRyaXgnIH0sXG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctYmxhY2svODAgYmFja2Ryb3AtYmx1ci1tZCBhbmltYXRlLWZhZGUtaW5cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIG1heC13LWxnIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlbiBmbGV4IGZsZXgtY29sIG1heC1oLVs4NXZoXVwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctY3lhbi01MDAvMTAgdGV4dC1jeWFuLTQwMFwiPlxuICAgICAgICAgICAgICA8S2V5Ym9hcmQgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LWJhc2UgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5Db250cm9scyAmIEd1aWRlbGluZXM8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+VG91cm5hbWVudCBndWlkZWxpbmUga2V5Ym9hcmQgbGF5b3V0PC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHAtNiBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMlwiPlxuICAgICAgICAgICAge2NvbnRyb2xSb3dzLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e3Jvdy5sYWJlbH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcC0yLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtd2hpdGVcIj57cm93LmxhYmVsfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPntyb3cuZGVzY308L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAge3Jvdy5rZXlzLm1hcCgoaykgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8a2JkXG4gICAgICAgICAgICAgICAgICAgICAga2V5PXtrfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xIHRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCBiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC1sZyB0ZXh0LWN5YW4tMzAwIHNoYWRvdy1zbVwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7a31cbiAgICAgICAgICAgICAgICAgICAgPC9rYmQ+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgdGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBzcGFjZS15LTFcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxIZWxwQ2lyY2xlIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtY3lhbi00MDBcIiAvPiBBZHZhbmNlZCBTUlMgVGlwczpcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICDigKIgPHN0cm9uZz5ULVNwaW5zPC9zdHJvbmc+OiBSb3RhdGUgdGhlIFQtcGllY2UgaW50byB0aWdodCAzLWNvcm5lciBwb2NrZXRzIGZvciBtYXNzaXZlIHBvaW50cyFcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxwPlxuICAgICAgICAgICAgICDigKIgPHN0cm9uZz5CYWNrLXRvLUJhY2sgKEIyQik8L3N0cm9uZz46IENsZWFyaW5nIGNvbnNlY3V0aXZlIDQtbGluZSBUZXRyaXNlcyBvciBULVNwaW5zIGF3YXJkcyBhIDEuNXggc2NvcmUgbXVsdGlwbGllciFcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZvb3RlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBweC02IHB5LTMgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMCBiZy1zbGF0ZS05NTBcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNCBweS0xLjUgcm91bmRlZC1sZyBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC13aGl0ZSB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgQ2xvc2VcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=