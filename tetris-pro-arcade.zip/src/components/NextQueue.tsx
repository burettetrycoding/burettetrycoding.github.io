const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { PiecePreview } from "/src/components/PiecePreview.tsx";
var _jsxFileName = "/app/applet/src/components/NextQueue.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const NextQueue = ({ queue, theme }) => {
	const displayQueue = queue.slice(0, 4);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "flex flex-col items-center p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-md shadow-lg select-none",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between w-full mb-2",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "text-[11px] font-bold uppercase tracking-wider text-slate-400",
				children: "NEXT"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-[10px] text-slate-500 font-mono",
				children: "QUEUE"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col gap-2",
			children: displayQueue.map((pieceType, index) => /* @__PURE__ */ _jsxDEV(PiecePreview, {
				type: pieceType,
				theme,
				size: index === 0 ? "md" : "sm"
			}, `next-${index}-${pieceType}`, false, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsb0JBQW9COzs7QUFPN0IsT0FBTyxNQUFNLGFBQXVDLEVBQUUsT0FBTyxZQUFZO0NBQ3ZFLE1BQU0sZUFBZSxNQUFNLE1BQU0sR0FBRyxDQUFDO0NBRXJDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FDRSx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFnRTtHQUFVOzs7O2FBQzFGLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO2NBQXVDO0dBQVc7Ozs7V0FDL0Q7Ozs7O1lBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFDWixhQUFhLEtBQUssV0FBVyxVQUM1Qix3QkFBQyxjQUFEO0lBRUUsTUFBTTtJQUNDO0lBQ1AsTUFBTSxVQUFVLElBQUksT0FBTztHQUM1QixHQUpNLFFBQVEsTUFBTSxHQUFHOzs7O1VBSXZCLENBQ0Y7RUFDRTs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOZXh0UXVldWUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBUZXRyb21pbm9UeXBlLCBUaGVtZUNvbmZpZyB9IGZyb20gJy4uL3R5cGVzL3RldHJpcyc7XG5pbXBvcnQgeyBQaWVjZVByZXZpZXcgfSBmcm9tICcuL1BpZWNlUHJldmlldyc7XG5cbmludGVyZmFjZSBOZXh0UXVldWVQcm9wcyB7XG4gIHF1ZXVlOiBUZXRyb21pbm9UeXBlW107XG4gIHRoZW1lOiBUaGVtZUNvbmZpZztcbn1cblxuZXhwb3J0IGNvbnN0IE5leHRRdWV1ZTogUmVhY3QuRkM8TmV4dFF1ZXVlUHJvcHM+ID0gKHsgcXVldWUsIHRoZW1lIH0pID0+IHtcbiAgY29uc3QgZGlzcGxheVF1ZXVlID0gcXVldWUuc2xpY2UoMCwgNCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIHAtMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05MDAvNjAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAvODAgYmFja2Ryb3AtYmx1ci1tZCBzaGFkb3ctbGcgc2VsZWN0LW5vbmVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHctZnVsbCBtYi0yXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5ORVhUPC9zcGFuPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW1vbm9cIj5RVUVVRTwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgZ2FwLTJcIj5cbiAgICAgICAge2Rpc3BsYXlRdWV1ZS5tYXAoKHBpZWNlVHlwZSwgaW5kZXgpID0+IChcbiAgICAgICAgICA8UGllY2VQcmV2aWV3XG4gICAgICAgICAgICBrZXk9e2BuZXh0LSR7aW5kZXh9LSR7cGllY2VUeXBlfWB9XG4gICAgICAgICAgICB0eXBlPXtwaWVjZVR5cGV9XG4gICAgICAgICAgICB0aGVtZT17dGhlbWV9XG4gICAgICAgICAgICBzaXplPXtpbmRleCA9PT0gMCA/ICdtZCcgOiAnc20nfVxuICAgICAgICAgIC8+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19