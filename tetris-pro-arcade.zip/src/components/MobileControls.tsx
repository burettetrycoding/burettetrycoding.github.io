const React = __vite__cjsImport0_react; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { ArrowLeft, ArrowRight, ArrowDown, ChevronsDown, RotateCw, RotateCcw } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
var _jsxFileName = "/app/applet/src/components/MobileControls.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const MobileControls = ({ onMoveLeft, onMoveRight, onSoftDrop, onHardDrop, onRotateCW, onRotateCCW, onHold }) => {
	const repeatTimerRef = useRef(null);
	const triggerHaptic = () => {
		if (typeof window !== "undefined" && "vibrate" in navigator) {
			try {
				navigator.vibrate(15);
			} catch {}
		}
	};
	const startRepeating = (action) => {
		triggerHaptic();
		action();
		repeatTimerRef.current = window.setInterval(() => {
			action();
		}, 85);
	};
	const stopRepeating = () => {
		if (repeatTimerRef.current) {
			window.clearInterval(repeatTimerRef.current);
			repeatTimerRef.current = null;
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "w-full flex items-center justify-between gap-2 max-w-md mx-auto select-none pt-2 pb-1 touch-none",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col items-center gap-1.5",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onPointerDown: () => startRepeating(onMoveLeft),
						onPointerUp: stopRepeating,
						onPointerLeave: stopRepeating,
						className: "w-13 h-13 rounded-2xl bg-slate-800/80 active:bg-cyan-500/30 border border-slate-700/80 flex items-center justify-center text-white active:scale-90 transition-transform shadow-md",
						"aria-label": "Move Left",
						children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-6 h-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onPointerDown: () => startRepeating(onMoveRight),
						onPointerUp: stopRepeating,
						onPointerLeave: stopRepeating,
						className: "w-13 h-13 rounded-2xl bg-slate-800/80 active:bg-cyan-500/30 border border-slate-700/80 flex items-center justify-center text-white active:scale-90 transition-transform shadow-md",
						"aria-label": "Move Right",
						children: /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-6 h-6" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 75,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onPointerDown: () => startRepeating(onSoftDrop),
					onPointerUp: stopRepeating,
					onPointerLeave: stopRepeating,
					className: "w-28 h-11 rounded-2xl bg-slate-800/80 active:bg-cyan-500/30 border border-slate-700/80 flex items-center justify-center text-white active:scale-90 transition-transform shadow-md",
					"aria-label": "Soft Drop",
					children: /* @__PURE__ */ _jsxDEV(ArrowDown, { className: "w-5 h-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 94,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex flex-col items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						triggerHaptic();
						onHardDrop();
					},
					className: "w-14 h-14 rounded-2xl bg-cyan-600/80 active:bg-cyan-400 border border-cyan-400/50 flex flex-col items-center justify-center text-white active:scale-90 transition-transform shadow-lg shadow-cyan-500/20",
					"aria-label": "Hard Drop",
					children: [/* @__PURE__ */ _jsxDEV(ChevronsDown, { className: "w-6 h-6" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[9px] font-black tracking-tight",
						children: "DROP"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 100,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						triggerHaptic();
						onHold();
					},
					className: "px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-xs font-bold text-slate-300 active:scale-90 transition-transform",
					children: "HOLD"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 112,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						triggerHaptic();
						onRotateCCW();
					},
					className: "w-13 h-13 rounded-2xl bg-slate-800/80 active:bg-cyan-500/30 border border-slate-700/80 flex flex-col items-center justify-center text-white active:scale-90 transition-transform shadow-md",
					"aria-label": "Rotate Counter-Clockwise",
					children: [/* @__PURE__ */ _jsxDEV(RotateCcw, { className: "w-5 h-5 text-purple-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[8px] font-bold text-slate-400 mt-0.5",
						children: "CCW"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 126,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						triggerHaptic();
						onRotateCW();
					},
					className: "w-14 h-14 rounded-2xl bg-slate-800/80 active:bg-cyan-500/30 border border-cyan-500/40 flex flex-col items-center justify-center text-white active:scale-90 transition-transform shadow-md",
					"aria-label": "Rotate Clockwise",
					children: [/* @__PURE__ */ _jsxDEV(RotateCw, { className: "w-6 h-6 text-cyan-400" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 147,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-[8px] font-bold text-cyan-300 mt-0.5",
						children: "CW"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGNBQWM7QUFDOUIsU0FDRSxXQUNBLFlBQ0EsV0FDQSxjQUNBLFVBQ0EsaUJBRUs7OztBQVlQLE9BQU8sTUFBTSxrQkFBaUQsRUFDNUQsWUFDQSxhQUNBLFlBQ0EsWUFDQSxZQUNBLGFBQ0EsYUFDSTtDQUNKLE1BQU0saUJBQWlCLE9BQXNCLElBQUk7Q0FFakQsTUFBTSxzQkFBc0I7RUFDMUIsSUFBSSxPQUFPLFdBQVcsZUFBZSxhQUFhLFdBQVc7R0FDM0QsSUFBSTtJQUNGLFVBQVUsUUFBUSxFQUFFO0dBQ3RCLFFBQVEsQ0FFUjtFQUNGO0NBQ0Y7Q0FFQSxNQUFNLGtCQUFrQixXQUF1QjtFQUM3QyxjQUFjO0VBQ2QsT0FBTztFQUNQLGVBQWUsVUFBVSxPQUFPLGtCQUFrQjtHQUNoRCxPQUFPO0VBQ1QsR0FBRyxFQUFFO0NBQ1A7Q0FFQSxNQUFNLHNCQUFzQjtFQUMxQixJQUFJLGVBQWUsU0FBUztHQUMxQixPQUFPLGNBQWMsZUFBZSxPQUFPO0dBQzNDLGVBQWUsVUFBVTtFQUMzQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxVQUFEO01BQ0UscUJBQXFCLGVBQWUsVUFBVTtNQUM5QyxhQUFhO01BQ2IsZ0JBQWdCO01BQ2hCLFdBQVU7TUFDVixjQUFXO2dCQUVYLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7O0tBQzFCOzs7O2VBR1Isd0JBQUMsVUFBRDtNQUNFLHFCQUFxQixlQUFlLFdBQVc7TUFDL0MsYUFBYTtNQUNiLGdCQUFnQjtNQUNoQixXQUFVO01BQ1YsY0FBVztnQkFFWCx3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7OztLQUMzQjs7OzthQUNMOzs7OztjQUdMLHdCQUFDLFVBQUQ7S0FDRSxxQkFBcUIsZUFBZSxVQUFVO0tBQzlDLGFBQWE7S0FDYixnQkFBZ0I7S0FDaEIsV0FBVTtLQUNWLGNBQVc7ZUFFWCx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7OztJQUMxQjs7OztZQUNMOzs7Ozs7R0FHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsVUFBRDtLQUNFLGVBQWU7TUFDYixjQUFjO01BQ2QsV0FBVztLQUNiO0tBQ0EsV0FBVTtLQUNWLGNBQVc7ZUFOYixDQVFFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7ZUFDbkMsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQXVDO0tBQVU7Ozs7YUFDM0Q7Ozs7O2NBRVIsd0JBQUMsVUFBRDtLQUNFLGVBQWU7TUFDYixjQUFjO01BQ2QsT0FBTztLQUNUO0tBQ0EsV0FBVTtlQUNYO0lBRU87Ozs7WUFDTDs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUVFLHdCQUFDLFVBQUQ7S0FDRSxlQUFlO01BQ2IsY0FBYztNQUNkLFlBQVk7S0FDZDtLQUNBLFdBQVU7S0FDVixjQUFXO2VBTmIsQ0FRRSx3QkFBQyxXQUFELEVBQVcsV0FBVSwwQkFBMkI7Ozs7ZUFDaEQsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQTZDO0tBQVM7Ozs7YUFDaEU7Ozs7O2NBR1Isd0JBQUMsVUFBRDtLQUNFLGVBQWU7TUFDYixjQUFjO01BQ2QsV0FBVztLQUNiO0tBQ0EsV0FBVTtLQUNWLGNBQVc7ZUFOYixDQVFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLHdCQUF5Qjs7OztlQUM3Qyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBNEM7S0FBUTs7OzthQUM5RDs7Ozs7WUFDTDs7Ozs7O0VBQ0Y7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1vYmlsZUNvbnRyb2xzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlUmVmIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHtcbiAgQXJyb3dMZWZ0LFxuICBBcnJvd1JpZ2h0LFxuICBBcnJvd0Rvd24sXG4gIENoZXZyb25zRG93bixcbiAgUm90YXRlQ3csXG4gIFJvdGF0ZUNjdyxcbiAgUmVmcmVzaEN3LFxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuXG5pbnRlcmZhY2UgTW9iaWxlQ29udHJvbHNQcm9wcyB7XG4gIG9uTW92ZUxlZnQ6ICgpID0+IHZvaWQ7XG4gIG9uTW92ZVJpZ2h0OiAoKSA9PiB2b2lkO1xuICBvblNvZnREcm9wOiAoKSA9PiB2b2lkO1xuICBvbkhhcmREcm9wOiAoKSA9PiB2b2lkO1xuICBvblJvdGF0ZUNXOiAoKSA9PiB2b2lkO1xuICBvblJvdGF0ZUNDVzogKCkgPT4gdm9pZDtcbiAgb25Ib2xkOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgTW9iaWxlQ29udHJvbHM6IFJlYWN0LkZDPE1vYmlsZUNvbnRyb2xzUHJvcHM+ID0gKHtcbiAgb25Nb3ZlTGVmdCxcbiAgb25Nb3ZlUmlnaHQsXG4gIG9uU29mdERyb3AsXG4gIG9uSGFyZERyb3AsXG4gIG9uUm90YXRlQ1csXG4gIG9uUm90YXRlQ0NXLFxuICBvbkhvbGQsXG59KSA9PiB7XG4gIGNvbnN0IHJlcGVhdFRpbWVyUmVmID0gdXNlUmVmPG51bWJlciB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IHRyaWdnZXJIYXB0aWMgPSAoKSA9PiB7XG4gICAgaWYgKHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmICd2aWJyYXRlJyBpbiBuYXZpZ2F0b3IpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIG5hdmlnYXRvci52aWJyYXRlKDE1KTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICAvLyBpZ25vcmVcbiAgICAgIH1cbiAgICB9XG4gIH07XG5cbiAgY29uc3Qgc3RhcnRSZXBlYXRpbmcgPSAoYWN0aW9uOiAoKSA9PiB2b2lkKSA9PiB7XG4gICAgdHJpZ2dlckhhcHRpYygpO1xuICAgIGFjdGlvbigpO1xuICAgIHJlcGVhdFRpbWVyUmVmLmN1cnJlbnQgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgYWN0aW9uKCk7XG4gICAgfSwgODUpO1xuICB9O1xuXG4gIGNvbnN0IHN0b3BSZXBlYXRpbmcgPSAoKSA9PiB7XG4gICAgaWYgKHJlcGVhdFRpbWVyUmVmLmN1cnJlbnQpIHtcbiAgICAgIHdpbmRvdy5jbGVhckludGVydmFsKHJlcGVhdFRpbWVyUmVmLmN1cnJlbnQpO1xuICAgICAgcmVwZWF0VGltZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yIG1heC13LW1kIG14LWF1dG8gc2VsZWN0LW5vbmUgcHQtMiBwYi0xIHRvdWNoLW5vbmVcIj5cbiAgICAgIHsvKiBMZWZ0IENsdXN0ZXI6IEQtUGFkICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICB7LyogTW92ZSBMZWZ0ICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uUG9pbnRlckRvd249eygpID0+IHN0YXJ0UmVwZWF0aW5nKG9uTW92ZUxlZnQpfVxuICAgICAgICAgICAgb25Qb2ludGVyVXA9e3N0b3BSZXBlYXRpbmd9XG4gICAgICAgICAgICBvblBvaW50ZXJMZWF2ZT17c3RvcFJlcGVhdGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTMgaC0xMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS04MDAvODAgYWN0aXZlOmJnLWN5YW4tNTAwLzMwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzgwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgYWN0aXZlOnNjYWxlLTkwIHRyYW5zaXRpb24tdHJhbnNmb3JtIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiTW92ZSBMZWZ0XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIE1vdmUgUmlnaHQgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25Qb2ludGVyRG93bj17KCkgPT4gc3RhcnRSZXBlYXRpbmcob25Nb3ZlUmlnaHQpfVxuICAgICAgICAgICAgb25Qb2ludGVyVXA9e3N0b3BSZXBlYXRpbmd9XG4gICAgICAgICAgICBvblBvaW50ZXJMZWF2ZT17c3RvcFJlcGVhdGluZ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTMgaC0xMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS04MDAvODAgYWN0aXZlOmJnLWN5YW4tNTAwLzMwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwLzgwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtd2hpdGUgYWN0aXZlOnNjYWxlLTkwIHRyYW5zaXRpb24tdHJhbnNmb3JtIHNoYWRvdy1tZFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiTW92ZSBSaWdodFwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTb2Z0IERyb3AgKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvblBvaW50ZXJEb3duPXsoKSA9PiBzdGFydFJlcGVhdGluZyhvblNvZnREcm9wKX1cbiAgICAgICAgICBvblBvaW50ZXJVcD17c3RvcFJlcGVhdGluZ31cbiAgICAgICAgICBvblBvaW50ZXJMZWF2ZT17c3RvcFJlcGVhdGluZ31cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LTI4IGgtMTEgcm91bmRlZC0yeGwgYmctc2xhdGUtODAwLzgwIGFjdGl2ZTpiZy1jeWFuLTUwMC8zMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGFjdGl2ZTpzY2FsZS05MCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBzaGFkb3ctbWRcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJTb2Z0IERyb3BcIlxuICAgICAgICA+XG4gICAgICAgICAgPEFycm93RG93biBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIE1pZGRsZTogSGFyZCBEcm9wICYgSG9sZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHRyaWdnZXJIYXB0aWMoKTtcbiAgICAgICAgICAgIG9uSGFyZERyb3AoKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy1jeWFuLTYwMC84MCBhY3RpdmU6YmctY3lhbi00MDAgYm9yZGVyIGJvcmRlci1jeWFuLTQwMC81MCBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXdoaXRlIGFjdGl2ZTpzY2FsZS05MCB0cmFuc2l0aW9uLXRyYW5zZm9ybSBzaGFkb3ctbGcgc2hhZG93LWN5YW4tNTAwLzIwXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiSGFyZCBEcm9wXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxDaGV2cm9uc0Rvd24gY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bOXB4XSBmb250LWJsYWNrIHRyYWNraW5nLXRpZ2h0XCI+RFJPUDwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHRyaWdnZXJIYXB0aWMoKTtcbiAgICAgICAgICAgIG9uSG9sZCgpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDAgYWN0aXZlOnNjYWxlLTkwIHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcbiAgICAgICAgPlxuICAgICAgICAgIEhPTERcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAgey8qIFJpZ2h0IENsdXN0ZXI6IFJvdGF0aW9ucyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgey8qIFJvdGF0ZSBDQ1cgKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICB0cmlnZ2VySGFwdGljKCk7XG4gICAgICAgICAgICBvblJvdGF0ZUNDVygpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy0xMyBoLTEzIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTgwMC84MCBhY3RpdmU6YmctY3lhbi01MDAvMzAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAvODAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBhY3RpdmU6c2NhbGUtOTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gc2hhZG93LW1kXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUm90YXRlIENvdW50ZXItQ2xvY2t3aXNlXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwidy01IGgtNSB0ZXh0LXB1cnBsZS00MDBcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzhweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG10LTAuNVwiPkNDVzwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgey8qIFJvdGF0ZSBDVyAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgIHRyaWdnZXJIYXB0aWMoKTtcbiAgICAgICAgICAgIG9uUm90YXRlQ1coKTtcbiAgICAgICAgICB9fVxuICAgICAgICAgIGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS04MDAvODAgYWN0aXZlOmJnLWN5YW4tNTAwLzMwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNDAgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBhY3RpdmU6c2NhbGUtOTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gc2hhZG93LW1kXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUm90YXRlIENsb2Nrd2lzZVwiXG4gICAgICAgID5cbiAgICAgICAgICA8Um90YXRlQ3cgY2xhc3NOYW1lPVwidy02IGgtNiB0ZXh0LWN5YW4tNDAwXCIgLz5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVs4cHhdIGZvbnQtYm9sZCB0ZXh0LWN5YW4tMzAwIG10LTAuNVwiPkNXPC9zcGFuPlxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==