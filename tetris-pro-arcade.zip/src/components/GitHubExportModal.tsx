const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const JSZip = __vite__cjsImport2_jszip;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=434622ad";
import { X, Download, Copy, Check, Github, Terminal, BookOpen, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=2df0b3ac";
import __vite__cjsImport2_jszip from "/node_modules/.vite/deps/jszip.js?v=308cbaa0";
var _jsxFileName = "/app/applet/src/components/GitHubExportModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=434622ad";
export const GitHubExportModal = ({ isOpen, onClose }) => {
	const [activeTab, setActiveTab] = useState("quickstart");
	const [copiedSection, setCopiedSection] = useState(null);
	const [isZipping, setIsZipping] = useState(false);
	if (!isOpen) return null;
	const copyToClipboard = (text, sectionId) => {
		navigator.clipboard.writeText(text);
		setCopiedSection(sectionId);
		setTimeout(() => setCopiedSection(null), 2e3);
	};
	const gitCommands = `# 1. Initialize local repository
git init

# 2. Stage all project files
git add .

# 3. Commit the arcade game
git commit -m "feat: complete Tetris Pro Arcade release"

# 4. Set default branch to main
git branch -M main

# 5. Link your GitHub remote (replace with your repo URL)
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/tetris-pro-arcade.git

# 6. Push to GitHub!
git push -u origin main`;
	const readmeContent = `# Tetris Pro Arcade 🕹️

> A tournament-grade, responsive Tetris arcade game built with React 19, TypeScript, Vite, and Tailwind CSS. Features Super Rotation System (SRS), Web Audio API chiptune synthesizer, 7-bag randomizer, multiple game modes, and customizable retro arcade themes.

![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)
![React 19](https://img.shields.io/badge/React-19-61dafb.svg)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0-3178c6.svg)
![Vite](https://img.shields.io/badge/Vite-6.0-646cff.svg)

---

## 🎮 Key Features

- **Standard Guideline Compliance**:
  - Full Super Rotation System (SRS) with wall kicks for all pieces (including complex I-piece kicks).
  - Authentic 7-Bag Randomizer (eliminates piece droughts).
  - Ghost Piece projection guide.
  - Hold Piece mechanism (with 1 swap lock).
  - Next Queue showing upcoming 4-5 pieces.
  - T-Spin detection (3-corner rule) with score bonuses.
  - Back-to-Back (B2B) Tetris and Combo streaks.

- **Game Modes**:
  - **Marathon**: Classic endless level progression with standard gravity ramp up to Level 20.
  - **Sprint (40 Lines)**: Race against the millisecond clock to clear 40 lines.
  - **Ultra (2-Minute Blitz)**: Score maximum points before the 120-second buzzer sounds.
  - **Zen / Practice**: Relaxed play with customizable gravity speed slider and infinite clears.

- **Pure Web Audio Synthesizer**:
  - Zero external MP3 or audio dependencies.
  - Real-time synthesized 8-bit sound effects (Move, Rotate, Hard Drop thud, Soft Drop, Hold chime, Tetris fanfare, Level-up, Game Over).
  - Authentic 8-bit chiptune background music (Korobeiniki / Tetris Theme A) with independent lead and bassline channels.

- **Arcade Themes**:
  - *Cyberpunk Neon* (Luminescent glow on ultra-dark glass)
  - *1989 Arcade* (Nostalgic Soviet arcade primaries)
  - *GameBoy 1989* (Authentic 4-shade greenish LCD dot-matrix)
  - *Midnight Minimal* (Clean contemporary graphite slate)
  - *Vaporwave Sunset* (Dreamy synthwave lilac & coral)

- **Input & Accessibility**:
  - Responsive keyboard controls with DAS (Delayed Auto Shift) & ARR (Auto Repeat Rate).
  - On-screen touch D-Pad and rotation controls for mobile & tablet gameplay.
  - High score persistence with \`localStorage\`.

---

## ⌨️ Controls

| Action | Primary Key | Secondary Key |
| :--- | :--- | :--- |
| **Move Left** | \`ArrowLeft\` | \`A\` |
| **Move Right** | \`ArrowRight\` | \`D\` |
| **Soft Drop** | \`ArrowDown\` | \`S\` |
| **Hard Drop** | \`Space\` | - |
| **Rotate Clockwise (CW)** | \`ArrowUp\` | \`X\` / \`W\` |
| **Rotate Counter-Clockwise (CCW)** | \`Z\` | \`Left Ctrl\` |
| **Hold Piece** | \`C\` | \`Left Shift\` |
| **Pause / Resume** | \`P\` | \`Escape\` |
| **Restart Game** | \`R\` | - |

---

## 🚀 Getting Started

### Prerequisites

- Node.js (version 18 or higher recommended)
- npm or pnpm

### Installation

\`\`\`bash
# 1. Clone your repository
git clone https://github.com/<YOUR_GITHUB_USERNAME>/tetris-pro-arcade.git

# 2. Enter directory
cd tetris-pro-arcade

# 3. Install dependencies
npm install

# 4. Start local development server
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) (or the port Vite outputs) in your browser.

---

## 🌐 Deploy to GitHub Pages (Free)

1. In \`vite.config.ts\`, add your repo name as base:
   \`\`\`typescript
   export default defineConfig({
     base: '/tetris-pro-arcade/',
     // ...
   });
   \`\`\`
2. Build for production:
   \`\`\`bash
   npm run build
   \`\`\`
3. Push to a \`gh-pages\` branch or enable **GitHub Pages** from repository Settings -> Pages -> Source: GitHub Actions.

---

## 📄 License

This project is licensed under the MIT License - feel free to modify and share!
`;
	// One-click zip downloader
	const handleDownloadZip = async () => {
		setIsZipping(true);
		try {
			const zip = new JSZip();
			// README & Configs
			zip.file("README.md", readmeContent);
			zip.file(".gitignore", `node_modules\ndist\n.DS_Store\n*.local\n.env\n`);
			zip.file("LICENSE", `MIT License\n\nCopyright (c) 2026\n\nPermission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files...`);
			// package.json
			const pkgJson = {
				name: "tetris-pro-arcade",
				private: true,
				version: "1.0.0",
				type: "module",
				scripts: {
					dev: "vite",
					build: "tsc -b && vite build",
					preview: "vite preview"
				},
				dependencies: {
					"canvas-confetti": "^1.9.4",
					"lucide-react": "^0.546.0",
					"react": "^19.0.0",
					"react-dom": "^19.0.0"
				},
				devDependencies: {
					"@tailwindcss/vite": "^4.0.0",
					"@types/canvas-confetti": "^1.9.0",
					"@types/react": "^19.0.0",
					"@types/react-dom": "^19.0.0",
					"@vitejs/plugin-react": "^4.3.0",
					"tailwindcss": "^4.0.0",
					"typescript": "^5.7.0",
					"vite": "^6.0.0"
				}
			};
			zip.file("package.json", JSON.stringify(pkgJson, null, 2));
			// vite.config.ts
			zip.file("vite.config.ts", `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
});
`);
			// tsconfig.json
			zip.file("tsconfig.json", JSON.stringify({
				compilerOptions: {
					target: "ES2022",
					useDefineForClassFields: true,
					lib: [
						"ES2022",
						"DOM",
						"DOM.Iterable"
					],
					module: "ESNext",
					skipLibCheck: true,
					moduleResolution: "bundler",
					allowImportingTsExtensions: true,
					isolatedModules: true,
					moduleDetection: "force",
					noEmit: true,
					jsx: "react-jsx",
					strict: true,
					noUnusedLocals: true,
					noUnusedParameters: true,
					noFallthroughCasesInSwitch: true
				},
				include: ["src"]
			}, null, 2));
			// index.html
			zip.file("index.html", `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tetris Pro Arcade</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
  </head>
  <body class="bg-[#070b14] text-white">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"><\/script>
  </body>
</html>
`);
			// Fetch source files from current environment to pack into zip
			const filesToFetch = [
				"/src/main.tsx",
				"/src/App.tsx",
				"/src/index.css",
				"/src/types/tetris.ts",
				"/src/utils/tetrisConstants.ts",
				"/src/utils/soundEffects.ts",
				"/src/hooks/useTetris.ts",
				"/src/components/TetrisBoard.tsx",
				"/src/components/PiecePreview.tsx",
				"/src/components/HoldQueue.tsx",
				"/src/components/NextQueue.tsx",
				"/src/components/ScoreBoard.tsx",
				"/src/components/SoundControls.tsx",
				"/src/components/ThemeSelector.tsx",
				"/src/components/MobileControls.tsx",
				"/src/components/HighScoresModal.tsx",
				"/src/components/KeybindingsModal.tsx",
				"/src/components/GitHubExportModal.tsx"
			];
			for (const filePath of filesToFetch) {
				try {
					const resp = await fetch(filePath);
					if (resp.ok) {
						const text = await resp.text();
						zip.file(filePath.replace(/^\//, ""), text);
					}
				} catch {}
			}
			const content = await zip.generateAsync({ type: "blob" });
			const url = URL.createObjectURL(content);
			const link = document.createElement("a");
			link.href = url;
			link.download = "tetris-pro-arcade.zip";
			document.body.appendChild(link);
			link.click();
			document.body.removeChild(link);
			URL.revokeObjectURL(url);
		} catch (err) {
			console.error("Error bundling zip", err);
		} finally {
			setIsZipping(false);
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "relative w-full max-w-3xl max-h-[90vh] flex flex-col rounded-2xl bg-slate-900 border border-slate-700 shadow-2xl overflow-hidden",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-6 py-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2 rounded-xl bg-slate-800 text-cyan-400",
							children: /* @__PURE__ */ _jsxDEV(Github, { className: "w-5 h-5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 301,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 300,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-lg font-bold text-white",
							children: "GitHub Upload Suite"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 304,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Everything you need to publish this Tetris game onto GitHub"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 305,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 303,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 312,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 308,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 298,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex border-b border-slate-800 bg-slate-900/50 px-6 pt-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("quickstart"),
							className: `flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${activeTab === "quickstart" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-400 hover:text-slate-200"}`,
							children: [/* @__PURE__ */ _jsxDEV(Terminal, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 13
							}, this), "Git Commands"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("download"),
							className: `flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${activeTab === "download" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-400 hover:text-slate-200"}`,
							children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 337,
								columnNumber: 13
							}, this), "Download Zip (.zip)"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("readme"),
							className: `flex items-center gap-2 px-4 py-2.5 text-xs font-semibold border-b-2 transition-colors ${activeTab === "readme" ? "border-cyan-400 text-cyan-400" : "border-transparent text-slate-400 hover:text-slate-200"}`,
							children: [/* @__PURE__ */ _jsxDEV(BookOpen, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 348,
								columnNumber: 13
							}, this), "README.md Generator"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 340,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 317,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto p-6 space-y-4",
					children: [
						activeTab === "quickstart" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl bg-cyan-950/30 border border-cyan-500/30 text-xs text-cyan-200 space-y-1",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold flex items-center gap-1.5 text-cyan-300",
										children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 359,
											columnNumber: 19
										}, this), " Ready for GitHub"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 358,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
										"You can push this project directly to GitHub in 30 seconds. First create an empty repository on GitHub named ",
										/* @__PURE__ */ _jsxDEV("strong", { children: "tetris-pro-arcade" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 362,
											columnNumber: 128
										}, this),
										", then run these commands in your terminal:"
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 361,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative rounded-xl bg-slate-950 border border-slate-800 p-4 font-mono text-xs text-slate-300 overflow-x-auto",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => copyToClipboard(gitCommands, "git"),
										className: "absolute top-3 right-3 flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors text-xs font-sans font-medium",
										children: copiedSection === "git" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 373,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-emerald-400",
											children: "Copied!"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 374,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 372,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 378,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copy Commands" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 377,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 367,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("pre", {
										className: "pr-24",
										children: gitCommands
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 366,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("h3", {
										className: "text-xs font-bold uppercase tracking-wider text-slate-400",
										children: "How to host on GitHub Pages for Free"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 388,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("ol", {
										className: "text-xs text-slate-300 space-y-1.5 list-decimal list-inside",
										children: [
											/* @__PURE__ */ _jsxDEV("li", { children: "Push your code to your GitHub repo following the commands above." }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 392,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [
												"In your GitHub repo, click ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Settings" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 50
												}, this),
												" > ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Pages" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 393,
													columnNumber: 81
												}, this),
												"."
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 393,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [
												"Under ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Build and deployment" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 394,
													columnNumber: 29
												}, this),
												", select ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "GitHub Actions" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 394,
													columnNumber: 75
												}, this),
												" or ",
												/* @__PURE__ */ _jsxDEV("strong", { children: "Deploy from a branch" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 394,
													columnNumber: 110
												}, this),
												"."
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 394,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: [
												"Your game will be live for everyone at ",
												/* @__PURE__ */ _jsxDEV("code", {
													className: "text-cyan-400 font-mono",
													children: "https://<username>.github.io/tetris-pro-arcade/"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 395,
													columnNumber: 62
												}, this),
												"!"
											] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 395,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 391,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 387,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 13
						}, this),
						activeTab === "download" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-4 text-center py-6",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400",
									children: /* @__PURE__ */ _jsxDEV(Download, { className: "w-8 h-8" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 404,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 403,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-base font-bold text-white",
									children: "Download Complete Project Archive"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 407,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 max-w-md mx-auto mt-1",
									children: "Bundles all components, audio synthesizers, rotation algorithms, Vite build configs, and documentation into a single ready-to-unzip .zip file."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 408,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleDownloadZip,
										disabled: isZipping,
										className: "inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm shadow-lg shadow-cyan-500/20 active:scale-95 transition-all disabled:opacity-50",
										children: isZipping ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 421,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Packaging Zip..." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 422,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 420,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Download, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 426,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Download tetris-pro-arcade.zip" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 427,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 425,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 414,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 413,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 402,
							columnNumber: 13
						}, this),
						activeTab === "readme" && /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400",
									children: "Ready-made README.md for your GitHub repository:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => copyToClipboard(readmeContent, "readme"),
									className: "flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors text-xs font-medium",
									children: copiedSection === "readme" ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-3.5 h-3.5 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 445,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-emerald-400",
										children: "Copied Markdown"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 444,
										columnNumber: 21
									}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Copy, { className: "w-3.5 h-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 450,
										columnNumber: 23
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Copy README" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 451,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 449,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 439,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 437,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 rounded-xl bg-slate-950 border border-slate-800 max-h-96 overflow-y-auto font-mono text-xs text-slate-300",
								children: /* @__PURE__ */ _jsxDEV("pre", {
									className: "whitespace-pre-wrap",
									children: readmeContent
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 458,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 457,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 354,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between px-6 py-3 border-t border-slate-800 bg-slate-950",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-[11px] text-slate-500",
						children: "Open-source MIT licensed · GitHub ready"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 466,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-medium text-white transition-colors",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 469,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 465,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 296,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 295,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLEdBQUcsVUFBVSxNQUFNLE9BQU8sUUFBc0IsVUFBVSxVQUFVLGdCQUFnQjtBQUM3RixPQUFPLFdBQVc7OztBQU9sQixPQUFPLE1BQU0scUJBQXVELEVBQUUsUUFBUSxjQUFjO0NBQzFGLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUErQyxZQUFZO0NBQzdGLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUF3QixJQUFJO0NBQ3RFLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEtBQUs7Q0FFaEQsSUFBSSxDQUFDLFFBQVEsT0FBTztDQUVwQixNQUFNLG1CQUFtQixNQUFjLGNBQXNCO0VBQzNELFVBQVUsVUFBVSxVQUFVLElBQUk7RUFDbEMsaUJBQWlCLFNBQVM7RUFDMUIsaUJBQWlCLGlCQUFpQixJQUFJLEdBQUcsR0FBSTtDQUMvQztDQUVBLE1BQU0sY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrQnBCLE1BQU0sZ0JBQWdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBaUh0QixNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLGFBQWEsSUFBSTtFQUNqQixJQUFJO0dBQ0YsTUFBTSxNQUFNLElBQUksTUFBTTs7R0FHdEIsSUFBSSxLQUFLLGFBQWEsYUFBYTtHQUNuQyxJQUFJLEtBQUssY0FBYyxnREFBZ0Q7R0FDdkUsSUFBSSxLQUFLLFdBQVcsMEtBQTBLOztHQUc5TCxNQUFNLFVBQVU7SUFDZCxNQUFNO0lBQ04sU0FBUztJQUNULFNBQVM7SUFDVCxNQUFNO0lBQ04sU0FBUztLQUNQLEtBQUs7S0FDTCxPQUFPO0tBQ1AsU0FBUztJQUNYO0lBQ0EsY0FBYztLQUNaLG1CQUFtQjtLQUNuQixnQkFBZ0I7S0FDaEIsU0FBUztLQUNULGFBQWE7SUFDZjtJQUNBLGlCQUFpQjtLQUNmLHFCQUFxQjtLQUNyQiwwQkFBMEI7S0FDMUIsZ0JBQWdCO0tBQ2hCLG9CQUFvQjtLQUNwQix3QkFBd0I7S0FDeEIsZUFBZTtLQUNmLGNBQWM7S0FDZCxRQUFRO0lBQ1Y7R0FDRjtHQUNBLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxVQUFVLFNBQVMsTUFBTSxDQUFDLENBQUM7O0dBR3pELElBQUksS0FBSyxrQkFBa0I7Ozs7Ozs7Q0FPaEM7O0dBR0ssSUFBSSxLQUFLLGlCQUFpQixLQUFLLFVBQVU7SUFDdkMsaUJBQWlCO0tBQ2YsUUFBUTtLQUNSLHlCQUF5QjtLQUN6QixLQUFLO01BQUM7TUFBVTtNQUFPO0tBQWM7S0FDckMsUUFBUTtLQUNSLGNBQWM7S0FDZCxrQkFBa0I7S0FDbEIsNEJBQTRCO0tBQzVCLGlCQUFpQjtLQUNqQixpQkFBaUI7S0FDakIsUUFBUTtLQUNSLEtBQUs7S0FDTCxRQUFRO0tBQ1IsZ0JBQWdCO0tBQ2hCLG9CQUFvQjtLQUNwQiw0QkFBNEI7SUFDOUI7SUFDQSxTQUFTLENBQUMsS0FBSztHQUNqQixHQUFHLE1BQU0sQ0FBQyxDQUFDOztHQUdYLElBQUksS0FBSyxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Q0FlNUI7O0dBR0ssTUFBTSxlQUFlO0lBQ25CO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0dBRUEsS0FBSyxNQUFNLFlBQVksY0FBYztJQUNuQyxJQUFJO0tBQ0YsTUFBTSxPQUFPLE1BQU0sTUFBTSxRQUFRO0tBQ2pDLElBQUksS0FBSyxJQUFJO01BQ1gsTUFBTSxPQUFPLE1BQU0sS0FBSyxLQUFLO01BQzdCLElBQUksS0FBSyxTQUFTLFFBQVEsT0FBTyxFQUFFLEdBQUcsSUFBSTtLQUM1QztJQUNGLFFBQVEsQ0FFUjtHQUNGO0dBRUEsTUFBTSxVQUFVLE1BQU0sSUFBSSxjQUFjLEVBQUUsTUFBTSxPQUFPLENBQUM7R0FDeEQsTUFBTSxNQUFNLElBQUksZ0JBQWdCLE9BQU87R0FDdkMsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTztHQUNaLEtBQUssV0FBVztHQUNoQixTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsSUFBSSxnQkFBZ0IsR0FBRztFQUN6QixTQUFTLEtBQUs7R0FDWixRQUFRLE1BQU0sc0JBQXNCLEdBQUc7RUFDekMsVUFBVTtHQUNSLGFBQWEsS0FBSztFQUNwQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDYix3QkFBQyxRQUFELEVBQVEsV0FBVSxVQUFXOzs7OztNQUMxQjs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQStCO01BQXVCOzs7O2dCQUNwRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFBOEQ7Ozs7Y0FDakc7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBRVYsd0JBQUMsR0FBRCxFQUFHLFdBQVUsVUFBVzs7Ozs7S0FDbEI7Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsWUFBWTtPQUN4QyxXQUFXLDBGQUNULGNBQWMsZUFDVixrQ0FDQTtpQkFMUixDQVFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7aUJBQUMsY0FFMUI7Ozs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsVUFBVTtPQUN0QyxXQUFXLDBGQUNULGNBQWMsYUFDVixrQ0FDQTtpQkFMUixDQVFFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7aUJBQUMscUJBRTFCOzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFFBQVE7T0FDcEMsV0FBVywwRkFDVCxjQUFjLFdBQ1Ysa0NBQ0E7aUJBTFIsQ0FRRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2lCQUFDLHFCQUUxQjs7Ozs7O0tBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRyxjQUFjLGdCQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBaEIsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O29CQUFDLG1CQUNoQzs7Ozs7bUJBQ04sd0JBQUMsS0FBRDtVQUFHO1VBQzRHLHdCQUFDLFVBQUQsWUFBUSxvQkFBeUI7Ozs7O1VBQUM7U0FDOUk7Ozs7aUJBQ0E7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsVUFBRDtVQUNFLGVBQWUsZ0JBQWdCLGFBQWEsS0FBSztVQUNqRCxXQUFVO29CQUVULGtCQUFrQixRQUNqQixnREFDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwrQkFBZ0M7Ozs7b0JBQ2pELHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFtQjtVQUFhOzs7O2tCQUNoRDs7OztxQkFFRixnREFDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSxjQUFlOzs7O29CQUMvQix3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7O2tCQUN6Qjs7Ozs7U0FFRTs7OzttQkFDUix3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBUztTQUFpQjs7OztpQkFDdEM7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQTREO1NBRXRFOzs7O21CQUNKLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQ0Usd0JBQUMsTUFBRCxZQUFJLG1FQUFvRTs7Ozs7V0FDeEUsd0JBQUMsTUFBRDtZQUFJO1lBQTJCLHdCQUFDLFVBQUQsWUFBUSxXQUFnQjs7Ozs7WUFBQztZQUFNLHdCQUFDLFVBQUQsWUFBUSxRQUFhOzs7OztZQUFDO1dBQUs7Ozs7O1dBQ3pGLHdCQUFDLE1BQUQ7WUFBSTtZQUFNLHdCQUFDLFVBQUQsWUFBUSx1QkFBNEI7Ozs7O1lBQUM7WUFBUyx3QkFBQyxVQUFELFlBQVEsaUJBQXNCOzs7OztZQUFDO1lBQUksd0JBQUMsVUFBRCxZQUFRLHVCQUE0Qjs7Ozs7WUFBQztXQUFLOzs7OztXQUNySSx3QkFBQyxNQUFEO1lBQUk7WUFBdUMsd0JBQUMsUUFBRDthQUFNLFdBQVU7dUJBQTBCO1lBQTJEOzs7OztZQUFDO1dBQUs7Ozs7O1VBQ3BKOzs7OztpQkFDRDs7Ozs7O09BQ0Y7Ozs7OztNQUdOLGNBQWMsY0FDYix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7O1FBQzVCOzs7OztRQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBaUM7UUFBcUM7Ozs7a0JBQ3BGLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUErQztRQUV6RDs7OztnQkFDQTs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxVQUFEO1VBQ0UsU0FBUztVQUNULFVBQVU7VUFDVixXQUFVO29CQUVULFlBQ0MsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsK0VBQWdGOzs7O29CQUMvRix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2tCQUM1Qjs7OztxQkFFRixnREFDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O29CQUMvQix3QkFBQyxRQUFELFlBQU0saUNBQW9DOzs7O2tCQUMxQzs7Ozs7U0FFRTs7Ozs7UUFDTDs7Ozs7T0FDRjs7Ozs7O01BR04sY0FBYyxZQUNiLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUI7UUFBc0Q7Ozs7a0JBQy9GLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGdCQUFnQixlQUFlLFFBQVE7U0FDdEQsV0FBVTttQkFFVCxrQkFBa0IsV0FDakIsZ0RBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsK0JBQWdDOzs7O21CQUNqRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBbUI7U0FBcUI7Ozs7aUJBQ3hEOzs7O29CQUVGLGdEQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLGNBQWU7Ozs7bUJBQy9CLHdCQUFDLFFBQUQsWUFBTSxjQUFpQjs7OztpQkFDdkI7Ozs7O1FBRUU7Ozs7Z0JBQ0w7Ozs7O2lCQUVMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUF1QjtRQUFtQjs7Ozs7T0FDdEQ7Ozs7ZUFDRjs7Ozs7O0tBRUo7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBNkI7S0FFdkM7Ozs7ZUFDTix3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiR2l0SHViRXhwb3J0TW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFgsIERvd25sb2FkLCBDb3B5LCBDaGVjaywgR2l0aHViLCBFeHRlcm5hbExpbmssIFRlcm1pbmFsLCBCb29rT3BlbiwgU3BhcmtsZXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IEpTWmlwIGZyb20gJ2pzemlwJztcblxuaW50ZXJmYWNlIEdpdEh1YkV4cG9ydE1vZGFsUHJvcHMge1xuICBpc09wZW46IGJvb2xlYW47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBHaXRIdWJFeHBvcnRNb2RhbDogUmVhY3QuRkM8R2l0SHViRXhwb3J0TW9kYWxQcm9wcz4gPSAoeyBpc09wZW4sIG9uQ2xvc2UgfSkgPT4ge1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J3F1aWNrc3RhcnQnIHwgJ3JlYWRtZScgfCAnZG93bmxvYWQnPigncXVpY2tzdGFydCcpO1xuICBjb25zdCBbY29waWVkU2VjdGlvbiwgc2V0Q29waWVkU2VjdGlvbl0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzWmlwcGluZywgc2V0SXNaaXBwaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY29weVRvQ2xpcGJvYXJkID0gKHRleHQ6IHN0cmluZywgc2VjdGlvbklkOiBzdHJpbmcpID0+IHtcbiAgICBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dCh0ZXh0KTtcbiAgICBzZXRDb3BpZWRTZWN0aW9uKHNlY3Rpb25JZCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRDb3BpZWRTZWN0aW9uKG51bGwpLCAyMDAwKTtcbiAgfTtcblxuICBjb25zdCBnaXRDb21tYW5kcyA9IGAjIDEuIEluaXRpYWxpemUgbG9jYWwgcmVwb3NpdG9yeVxuZ2l0IGluaXRcblxuIyAyLiBTdGFnZSBhbGwgcHJvamVjdCBmaWxlc1xuZ2l0IGFkZCAuXG5cbiMgMy4gQ29tbWl0IHRoZSBhcmNhZGUgZ2FtZVxuZ2l0IGNvbW1pdCAtbSBcImZlYXQ6IGNvbXBsZXRlIFRldHJpcyBQcm8gQXJjYWRlIHJlbGVhc2VcIlxuXG4jIDQuIFNldCBkZWZhdWx0IGJyYW5jaCB0byBtYWluXG5naXQgYnJhbmNoIC1NIG1haW5cblxuIyA1LiBMaW5rIHlvdXIgR2l0SHViIHJlbW90ZSAocmVwbGFjZSB3aXRoIHlvdXIgcmVwbyBVUkwpXG5naXQgcmVtb3RlIGFkZCBvcmlnaW4gaHR0cHM6Ly9naXRodWIuY29tLzxZT1VSX0dJVEhVQl9VU0VSTkFNRT4vdGV0cmlzLXByby1hcmNhZGUuZ2l0XG5cbiMgNi4gUHVzaCB0byBHaXRIdWIhXG5naXQgcHVzaCAtdSBvcmlnaW4gbWFpbmA7XG5cbiAgY29uc3QgcmVhZG1lQ29udGVudCA9IGAjIFRldHJpcyBQcm8gQXJjYWRlIPCflbnvuI9cblxuPiBBIHRvdXJuYW1lbnQtZ3JhZGUsIHJlc3BvbnNpdmUgVGV0cmlzIGFyY2FkZSBnYW1lIGJ1aWx0IHdpdGggUmVhY3QgMTksIFR5cGVTY3JpcHQsIFZpdGUsIGFuZCBUYWlsd2luZCBDU1MuIEZlYXR1cmVzIFN1cGVyIFJvdGF0aW9uIFN5c3RlbSAoU1JTKSwgV2ViIEF1ZGlvIEFQSSBjaGlwdHVuZSBzeW50aGVzaXplciwgNy1iYWcgcmFuZG9taXplciwgbXVsdGlwbGUgZ2FtZSBtb2RlcywgYW5kIGN1c3RvbWl6YWJsZSByZXRybyBhcmNhZGUgdGhlbWVzLlxuXG4hW0xpY2Vuc2U6IE1JVF0oaHR0cHM6Ly9pbWcuc2hpZWxkcy5pby9iYWRnZS9MaWNlbnNlLU1JVC1ibHVlLnN2ZylcbiFbUmVhY3QgMTldKGh0dHBzOi8vaW1nLnNoaWVsZHMuaW8vYmFkZ2UvUmVhY3QtMTktNjFkYWZiLnN2ZylcbiFbVHlwZVNjcmlwdF0oaHR0cHM6Ly9pbWcuc2hpZWxkcy5pby9iYWRnZS9UeXBlU2NyaXB0LTUuMC0zMTc4YzYuc3ZnKVxuIVtWaXRlXShodHRwczovL2ltZy5zaGllbGRzLmlvL2JhZGdlL1ZpdGUtNi4wLTY0NmNmZi5zdmcpXG5cbi0tLVxuXG4jIyDwn46uIEtleSBGZWF0dXJlc1xuXG4tICoqU3RhbmRhcmQgR3VpZGVsaW5lIENvbXBsaWFuY2UqKjpcbiAgLSBGdWxsIFN1cGVyIFJvdGF0aW9uIFN5c3RlbSAoU1JTKSB3aXRoIHdhbGwga2lja3MgZm9yIGFsbCBwaWVjZXMgKGluY2x1ZGluZyBjb21wbGV4IEktcGllY2Uga2lja3MpLlxuICAtIEF1dGhlbnRpYyA3LUJhZyBSYW5kb21pemVyIChlbGltaW5hdGVzIHBpZWNlIGRyb3VnaHRzKS5cbiAgLSBHaG9zdCBQaWVjZSBwcm9qZWN0aW9uIGd1aWRlLlxuICAtIEhvbGQgUGllY2UgbWVjaGFuaXNtICh3aXRoIDEgc3dhcCBsb2NrKS5cbiAgLSBOZXh0IFF1ZXVlIHNob3dpbmcgdXBjb21pbmcgNC01IHBpZWNlcy5cbiAgLSBULVNwaW4gZGV0ZWN0aW9uICgzLWNvcm5lciBydWxlKSB3aXRoIHNjb3JlIGJvbnVzZXMuXG4gIC0gQmFjay10by1CYWNrIChCMkIpIFRldHJpcyBhbmQgQ29tYm8gc3RyZWFrcy5cblxuLSAqKkdhbWUgTW9kZXMqKjpcbiAgLSAqKk1hcmF0aG9uKio6IENsYXNzaWMgZW5kbGVzcyBsZXZlbCBwcm9ncmVzc2lvbiB3aXRoIHN0YW5kYXJkIGdyYXZpdHkgcmFtcCB1cCB0byBMZXZlbCAyMC5cbiAgLSAqKlNwcmludCAoNDAgTGluZXMpKio6IFJhY2UgYWdhaW5zdCB0aGUgbWlsbGlzZWNvbmQgY2xvY2sgdG8gY2xlYXIgNDAgbGluZXMuXG4gIC0gKipVbHRyYSAoMi1NaW51dGUgQmxpdHopKio6IFNjb3JlIG1heGltdW0gcG9pbnRzIGJlZm9yZSB0aGUgMTIwLXNlY29uZCBidXp6ZXIgc291bmRzLlxuICAtICoqWmVuIC8gUHJhY3RpY2UqKjogUmVsYXhlZCBwbGF5IHdpdGggY3VzdG9taXphYmxlIGdyYXZpdHkgc3BlZWQgc2xpZGVyIGFuZCBpbmZpbml0ZSBjbGVhcnMuXG5cbi0gKipQdXJlIFdlYiBBdWRpbyBTeW50aGVzaXplcioqOlxuICAtIFplcm8gZXh0ZXJuYWwgTVAzIG9yIGF1ZGlvIGRlcGVuZGVuY2llcy5cbiAgLSBSZWFsLXRpbWUgc3ludGhlc2l6ZWQgOC1iaXQgc291bmQgZWZmZWN0cyAoTW92ZSwgUm90YXRlLCBIYXJkIERyb3AgdGh1ZCwgU29mdCBEcm9wLCBIb2xkIGNoaW1lLCBUZXRyaXMgZmFuZmFyZSwgTGV2ZWwtdXAsIEdhbWUgT3ZlcikuXG4gIC0gQXV0aGVudGljIDgtYml0IGNoaXB0dW5lIGJhY2tncm91bmQgbXVzaWMgKEtvcm9iZWluaWtpIC8gVGV0cmlzIFRoZW1lIEEpIHdpdGggaW5kZXBlbmRlbnQgbGVhZCBhbmQgYmFzc2xpbmUgY2hhbm5lbHMuXG5cbi0gKipBcmNhZGUgVGhlbWVzKio6XG4gIC0gKkN5YmVycHVuayBOZW9uKiAoTHVtaW5lc2NlbnQgZ2xvdyBvbiB1bHRyYS1kYXJrIGdsYXNzKVxuICAtICoxOTg5IEFyY2FkZSogKE5vc3RhbGdpYyBTb3ZpZXQgYXJjYWRlIHByaW1hcmllcylcbiAgLSAqR2FtZUJveSAxOTg5KiAoQXV0aGVudGljIDQtc2hhZGUgZ3JlZW5pc2ggTENEIGRvdC1tYXRyaXgpXG4gIC0gKk1pZG5pZ2h0IE1pbmltYWwqIChDbGVhbiBjb250ZW1wb3JhcnkgZ3JhcGhpdGUgc2xhdGUpXG4gIC0gKlZhcG9yd2F2ZSBTdW5zZXQqIChEcmVhbXkgc3ludGh3YXZlIGxpbGFjICYgY29yYWwpXG5cbi0gKipJbnB1dCAmIEFjY2Vzc2liaWxpdHkqKjpcbiAgLSBSZXNwb25zaXZlIGtleWJvYXJkIGNvbnRyb2xzIHdpdGggREFTIChEZWxheWVkIEF1dG8gU2hpZnQpICYgQVJSIChBdXRvIFJlcGVhdCBSYXRlKS5cbiAgLSBPbi1zY3JlZW4gdG91Y2ggRC1QYWQgYW5kIHJvdGF0aW9uIGNvbnRyb2xzIGZvciBtb2JpbGUgJiB0YWJsZXQgZ2FtZXBsYXkuXG4gIC0gSGlnaCBzY29yZSBwZXJzaXN0ZW5jZSB3aXRoIFxcYGxvY2FsU3RvcmFnZVxcYC5cblxuLS0tXG5cbiMjIOKMqO+4jyBDb250cm9sc1xuXG58IEFjdGlvbiB8IFByaW1hcnkgS2V5IHwgU2Vjb25kYXJ5IEtleSB8XG58IDotLS0gfCA6LS0tIHwgOi0tLSB8XG58ICoqTW92ZSBMZWZ0KiogfCBcXGBBcnJvd0xlZnRcXGAgfCBcXGBBXFxgIHxcbnwgKipNb3ZlIFJpZ2h0KiogfCBcXGBBcnJvd1JpZ2h0XFxgIHwgXFxgRFxcYCB8XG58ICoqU29mdCBEcm9wKiogfCBcXGBBcnJvd0Rvd25cXGAgfCBcXGBTXFxgIHxcbnwgKipIYXJkIERyb3AqKiB8IFxcYFNwYWNlXFxgIHwgLSB8XG58ICoqUm90YXRlIENsb2Nrd2lzZSAoQ1cpKiogfCBcXGBBcnJvd1VwXFxgIHwgXFxgWFxcYCAvIFxcYFdcXGAgfFxufCAqKlJvdGF0ZSBDb3VudGVyLUNsb2Nrd2lzZSAoQ0NXKSoqIHwgXFxgWlxcYCB8IFxcYExlZnQgQ3RybFxcYCB8XG58ICoqSG9sZCBQaWVjZSoqIHwgXFxgQ1xcYCB8IFxcYExlZnQgU2hpZnRcXGAgfFxufCAqKlBhdXNlIC8gUmVzdW1lKiogfCBcXGBQXFxgIHwgXFxgRXNjYXBlXFxgIHxcbnwgKipSZXN0YXJ0IEdhbWUqKiB8IFxcYFJcXGAgfCAtIHxcblxuLS0tXG5cbiMjIPCfmoAgR2V0dGluZyBTdGFydGVkXG5cbiMjIyBQcmVyZXF1aXNpdGVzXG5cbi0gTm9kZS5qcyAodmVyc2lvbiAxOCBvciBoaWdoZXIgcmVjb21tZW5kZWQpXG4tIG5wbSBvciBwbnBtXG5cbiMjIyBJbnN0YWxsYXRpb25cblxuXFxgXFxgXFxgYmFzaFxuIyAxLiBDbG9uZSB5b3VyIHJlcG9zaXRvcnlcbmdpdCBjbG9uZSBodHRwczovL2dpdGh1Yi5jb20vPFlPVVJfR0lUSFVCX1VTRVJOQU1FPi90ZXRyaXMtcHJvLWFyY2FkZS5naXRcblxuIyAyLiBFbnRlciBkaXJlY3RvcnlcbmNkIHRldHJpcy1wcm8tYXJjYWRlXG5cbiMgMy4gSW5zdGFsbCBkZXBlbmRlbmNpZXNcbm5wbSBpbnN0YWxsXG5cbiMgNC4gU3RhcnQgbG9jYWwgZGV2ZWxvcG1lbnQgc2VydmVyXG5ucG0gcnVuIGRldlxuXFxgXFxgXFxgXG5cbk9wZW4gW2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMF0oaHR0cDovL2xvY2FsaG9zdDozMDAwKSAob3IgdGhlIHBvcnQgVml0ZSBvdXRwdXRzKSBpbiB5b3VyIGJyb3dzZXIuXG5cbi0tLVxuXG4jIyDwn4yQIERlcGxveSB0byBHaXRIdWIgUGFnZXMgKEZyZWUpXG5cbjEuIEluIFxcYHZpdGUuY29uZmlnLnRzXFxgLCBhZGQgeW91ciByZXBvIG5hbWUgYXMgYmFzZTpcbiAgIFxcYFxcYFxcYHR5cGVzY3JpcHRcbiAgIGV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gICAgIGJhc2U6ICcvdGV0cmlzLXByby1hcmNhZGUvJyxcbiAgICAgLy8gLi4uXG4gICB9KTtcbiAgIFxcYFxcYFxcYFxuMi4gQnVpbGQgZm9yIHByb2R1Y3Rpb246XG4gICBcXGBcXGBcXGBiYXNoXG4gICBucG0gcnVuIGJ1aWxkXG4gICBcXGBcXGBcXGBcbjMuIFB1c2ggdG8gYSBcXGBnaC1wYWdlc1xcYCBicmFuY2ggb3IgZW5hYmxlICoqR2l0SHViIFBhZ2VzKiogZnJvbSByZXBvc2l0b3J5IFNldHRpbmdzIC0+IFBhZ2VzIC0+IFNvdXJjZTogR2l0SHViIEFjdGlvbnMuXG5cbi0tLVxuXG4jIyDwn5OEIExpY2Vuc2VcblxuVGhpcyBwcm9qZWN0IGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgTGljZW5zZSAtIGZlZWwgZnJlZSB0byBtb2RpZnkgYW5kIHNoYXJlIVxuYDtcblxuICAvLyBPbmUtY2xpY2sgemlwIGRvd25sb2FkZXJcbiAgY29uc3QgaGFuZGxlRG93bmxvYWRaaXAgPSBhc3luYyAoKSA9PiB7XG4gICAgc2V0SXNaaXBwaW5nKHRydWUpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB6aXAgPSBuZXcgSlNaaXAoKTtcblxuICAgICAgLy8gUkVBRE1FICYgQ29uZmlnc1xuICAgICAgemlwLmZpbGUoJ1JFQURNRS5tZCcsIHJlYWRtZUNvbnRlbnQpO1xuICAgICAgemlwLmZpbGUoJy5naXRpZ25vcmUnLCBgbm9kZV9tb2R1bGVzXFxuZGlzdFxcbi5EU19TdG9yZVxcbioubG9jYWxcXG4uZW52XFxuYCk7XG4gICAgICB6aXAuZmlsZSgnTElDRU5TRScsIGBNSVQgTGljZW5zZVxcblxcbkNvcHlyaWdodCAoYykgMjAyNlxcblxcblBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzLi4uYCk7XG5cbiAgICAgIC8vIHBhY2thZ2UuanNvblxuICAgICAgY29uc3QgcGtnSnNvbiA9IHtcbiAgICAgICAgbmFtZTogXCJ0ZXRyaXMtcHJvLWFyY2FkZVwiLFxuICAgICAgICBwcml2YXRlOiB0cnVlLFxuICAgICAgICB2ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICAgIHR5cGU6IFwibW9kdWxlXCIsXG4gICAgICAgIHNjcmlwdHM6IHtcbiAgICAgICAgICBkZXY6IFwidml0ZVwiLFxuICAgICAgICAgIGJ1aWxkOiBcInRzYyAtYiAmJiB2aXRlIGJ1aWxkXCIsXG4gICAgICAgICAgcHJldmlldzogXCJ2aXRlIHByZXZpZXdcIlxuICAgICAgICB9LFxuICAgICAgICBkZXBlbmRlbmNpZXM6IHtcbiAgICAgICAgICBcImNhbnZhcy1jb25mZXR0aVwiOiBcIl4xLjkuNFwiLFxuICAgICAgICAgIFwibHVjaWRlLXJlYWN0XCI6IFwiXjAuNTQ2LjBcIixcbiAgICAgICAgICBcInJlYWN0XCI6IFwiXjE5LjAuMFwiLFxuICAgICAgICAgIFwicmVhY3QtZG9tXCI6IFwiXjE5LjAuMFwiXG4gICAgICAgIH0sXG4gICAgICAgIGRldkRlcGVuZGVuY2llczoge1xuICAgICAgICAgIFwiQHRhaWx3aW5kY3NzL3ZpdGVcIjogXCJeNC4wLjBcIixcbiAgICAgICAgICBcIkB0eXBlcy9jYW52YXMtY29uZmV0dGlcIjogXCJeMS45LjBcIixcbiAgICAgICAgICBcIkB0eXBlcy9yZWFjdFwiOiBcIl4xOS4wLjBcIixcbiAgICAgICAgICBcIkB0eXBlcy9yZWFjdC1kb21cIjogXCJeMTkuMC4wXCIsXG4gICAgICAgICAgXCJAdml0ZWpzL3BsdWdpbi1yZWFjdFwiOiBcIl40LjMuMFwiLFxuICAgICAgICAgIFwidGFpbHdpbmRjc3NcIjogXCJeNC4wLjBcIixcbiAgICAgICAgICBcInR5cGVzY3JpcHRcIjogXCJeNS43LjBcIixcbiAgICAgICAgICBcInZpdGVcIjogXCJeNi4wLjBcIlxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgemlwLmZpbGUoJ3BhY2thZ2UuanNvbicsIEpTT04uc3RyaW5naWZ5KHBrZ0pzb24sIG51bGwsIDIpKTtcblxuICAgICAgLy8gdml0ZS5jb25maWcudHNcbiAgICAgIHppcC5maWxlKCd2aXRlLmNvbmZpZy50cycsIGBpbXBvcnQgeyBkZWZpbmVDb25maWcgfSBmcm9tICd2aXRlJztcbmltcG9ydCByZWFjdCBmcm9tICdAdml0ZWpzL3BsdWdpbi1yZWFjdCc7XG5pbXBvcnQgdGFpbHdpbmRjc3MgZnJvbSAnQHRhaWx3aW5kY3NzL3ZpdGUnO1xuXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICBwbHVnaW5zOiBbcmVhY3QoKSwgdGFpbHdpbmRjc3MoKV0sXG59KTtcbmApO1xuXG4gICAgICAvLyB0c2NvbmZpZy5qc29uXG4gICAgICB6aXAuZmlsZSgndHNjb25maWcuanNvbicsIEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgY29tcGlsZXJPcHRpb25zOiB7XG4gICAgICAgICAgdGFyZ2V0OiBcIkVTMjAyMlwiLFxuICAgICAgICAgIHVzZURlZmluZUZvckNsYXNzRmllbGRzOiB0cnVlLFxuICAgICAgICAgIGxpYjogW1wiRVMyMDIyXCIsIFwiRE9NXCIsIFwiRE9NLkl0ZXJhYmxlXCJdLFxuICAgICAgICAgIG1vZHVsZTogXCJFU05leHRcIixcbiAgICAgICAgICBza2lwTGliQ2hlY2s6IHRydWUsXG4gICAgICAgICAgbW9kdWxlUmVzb2x1dGlvbjogXCJidW5kbGVyXCIsXG4gICAgICAgICAgYWxsb3dJbXBvcnRpbmdUc0V4dGVuc2lvbnM6IHRydWUsXG4gICAgICAgICAgaXNvbGF0ZWRNb2R1bGVzOiB0cnVlLFxuICAgICAgICAgIG1vZHVsZURldGVjdGlvbjogXCJmb3JjZVwiLFxuICAgICAgICAgIG5vRW1pdDogdHJ1ZSxcbiAgICAgICAgICBqc3g6IFwicmVhY3QtanN4XCIsXG4gICAgICAgICAgc3RyaWN0OiB0cnVlLFxuICAgICAgICAgIG5vVW51c2VkTG9jYWxzOiB0cnVlLFxuICAgICAgICAgIG5vVW51c2VkUGFyYW1ldGVyczogdHJ1ZSxcbiAgICAgICAgICBub0ZhbGx0aHJvdWdoQ2FzZXNJblN3aXRjaDogdHJ1ZVxuICAgICAgICB9LFxuICAgICAgICBpbmNsdWRlOiBbXCJzcmNcIl1cbiAgICAgIH0sIG51bGwsIDIpKTtcblxuICAgICAgLy8gaW5kZXguaHRtbFxuICAgICAgemlwLmZpbGUoJ2luZGV4Lmh0bWwnLCBgPCFkb2N0eXBlIGh0bWw+XG48aHRtbCBsYW5nPVwiZW5cIj5cbiAgPGhlYWQ+XG4gICAgPG1ldGEgY2hhcnNldD1cIlVURi04XCIgLz5cbiAgICA8bWV0YSBuYW1lPVwidmlld3BvcnRcIiBjb250ZW50PVwid2lkdGg9ZGV2aWNlLXdpZHRoLCBpbml0aWFsLXNjYWxlPTEuMFwiIC8+XG4gICAgPHRpdGxlPlRldHJpcyBQcm8gQXJjYWRlPC90aXRsZT5cbiAgICA8bGluayByZWw9XCJwcmVjb25uZWN0XCIgaHJlZj1cImh0dHBzOi8vZm9udHMuZ29vZ2xlYXBpcy5jb21cIj5cbiAgICA8bGluayByZWw9XCJwcmVjb25uZWN0XCIgaHJlZj1cImh0dHBzOi8vZm9udHMuZ3N0YXRpYy5jb21cIiBjcm9zc29yaWdpbj5cbiAgICA8bGluayBocmVmPVwiaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1KZXRCcmFpbnMrTW9ubzp3Z2h0QDQwMDs3MDAmZmFtaWx5PVBsdXMrSmFrYXJ0YStTYW5zOndnaHRANDAwOzYwMDs3MDA7ODAwJmRpc3BsYXk9c3dhcFwiIHJlbD1cInN0eWxlc2hlZXRcIj5cbiAgPC9oZWFkPlxuICA8Ym9keSBjbGFzcz1cImJnLVsjMDcwYjE0XSB0ZXh0LXdoaXRlXCI+XG4gICAgPGRpdiBpZD1cInJvb3RcIj48L2Rpdj5cbiAgICA8c2NyaXB0IHR5cGU9XCJtb2R1bGVcIiBzcmM9XCIvc3JjL21haW4udHN4XCI+PC9zY3JpcHQ+XG4gIDwvYm9keT5cbjwvaHRtbD5cbmApO1xuXG4gICAgICAvLyBGZXRjaCBzb3VyY2UgZmlsZXMgZnJvbSBjdXJyZW50IGVudmlyb25tZW50IHRvIHBhY2sgaW50byB6aXBcbiAgICAgIGNvbnN0IGZpbGVzVG9GZXRjaCA9IFtcbiAgICAgICAgJy9zcmMvbWFpbi50c3gnLFxuICAgICAgICAnL3NyYy9BcHAudHN4JyxcbiAgICAgICAgJy9zcmMvaW5kZXguY3NzJyxcbiAgICAgICAgJy9zcmMvdHlwZXMvdGV0cmlzLnRzJyxcbiAgICAgICAgJy9zcmMvdXRpbHMvdGV0cmlzQ29uc3RhbnRzLnRzJyxcbiAgICAgICAgJy9zcmMvdXRpbHMvc291bmRFZmZlY3RzLnRzJyxcbiAgICAgICAgJy9zcmMvaG9va3MvdXNlVGV0cmlzLnRzJyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9UZXRyaXNCb2FyZC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL1BpZWNlUHJldmlldy50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL0hvbGRRdWV1ZS50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL05leHRRdWV1ZS50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL1Njb3JlQm9hcmQudHN4JyxcbiAgICAgICAgJy9zcmMvY29tcG9uZW50cy9Tb3VuZENvbnRyb2xzLnRzeCcsXG4gICAgICAgICcvc3JjL2NvbXBvbmVudHMvVGhlbWVTZWxlY3Rvci50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL01vYmlsZUNvbnRyb2xzLnRzeCcsXG4gICAgICAgICcvc3JjL2NvbXBvbmVudHMvSGlnaFNjb3Jlc01vZGFsLnRzeCcsXG4gICAgICAgICcvc3JjL2NvbXBvbmVudHMvS2V5YmluZGluZ3NNb2RhbC50c3gnLFxuICAgICAgICAnL3NyYy9jb21wb25lbnRzL0dpdEh1YkV4cG9ydE1vZGFsLnRzeCcsXG4gICAgICBdO1xuXG4gICAgICBmb3IgKGNvbnN0IGZpbGVQYXRoIG9mIGZpbGVzVG9GZXRjaCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBmZXRjaChmaWxlUGF0aCk7XG4gICAgICAgICAgaWYgKHJlc3Aub2spIHtcbiAgICAgICAgICAgIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwLnRleHQoKTtcbiAgICAgICAgICAgIHppcC5maWxlKGZpbGVQYXRoLnJlcGxhY2UoL15cXC8vLCAnJyksIHRleHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gZmFsbGJhY2sgaWYgZGlyZWN0IGZldGNoIGlzbid0IGF2YWlsYWJsZVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGNvbnRlbnQgPSBhd2FpdCB6aXAuZ2VuZXJhdGVBc3luYyh7IHR5cGU6ICdibG9iJyB9KTtcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoY29udGVudCk7XG4gICAgICBjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgICAgbGluay5ocmVmID0gdXJsO1xuICAgICAgbGluay5kb3dubG9hZCA9ICd0ZXRyaXMtcHJvLWFyY2FkZS56aXAnO1xuICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChsaW5rKTtcbiAgICAgIGxpbmsuY2xpY2soKTtcbiAgICAgIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQobGluayk7XG4gICAgICBVUkwucmV2b2tlT2JqZWN0VVJMKHVybCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBidW5kbGluZyB6aXAnLCBlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc1ppcHBpbmcoZmFsc2UpO1xuICAgIH1cbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1ibGFjay84MCBiYWNrZHJvcC1ibHVyLW1kIGFuaW1hdGUtZmFkZS1pblwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgbWF4LXctM3hsIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIHRleHQtY3lhbi00MDBcIj5cbiAgICAgICAgICAgICAgPEdpdGh1YiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ib2xkIHRleHQtd2hpdGVcIj5HaXRIdWIgVXBsb2FkIFN1aXRlPC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPkV2ZXJ5dGhpbmcgeW91IG5lZWQgdG8gcHVibGlzaCB0aGlzIFRldHJpcyBnYW1lIG9udG8gR2l0SHViPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMS41IHJvdW5kZWQtbGcgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIE5hdmlnYXRpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTkwMC81MCBweC02IHB0LTJcIj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3F1aWNrc3RhcnQnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMi41IHRleHQteHMgZm9udC1zZW1pYm9sZCBib3JkZXItYi0yIHRyYW5zaXRpb24tY29sb3JzICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3F1aWNrc3RhcnQnXG4gICAgICAgICAgICAgICAgPyAnYm9yZGVyLWN5YW4tNDAwIHRleHQtY3lhbi00MDAnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFRlcm1pbmFsIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgR2l0IENvbW1hbmRzXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdkb3dubG9hZCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtNCBweS0yLjUgdGV4dC14cyBmb250LXNlbWlib2xkIGJvcmRlci1iLTIgdHJhbnNpdGlvbi1jb2xvcnMgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnZG93bmxvYWQnXG4gICAgICAgICAgICAgICAgPyAnYm9yZGVyLWN5YW4tNDAwIHRleHQtY3lhbi00MDAnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgRG93bmxvYWQgWmlwICguemlwKVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYigncmVhZG1lJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC00IHB5LTIuNSB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgYm9yZGVyLWItMiB0cmFuc2l0aW9uLWNvbG9ycyAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdyZWFkbWUnXG4gICAgICAgICAgICAgICAgPyAnYm9yZGVyLWN5YW4tNDAwIHRleHQtY3lhbi00MDAnXG4gICAgICAgICAgICAgICAgOiAnYm9yZGVyLXRyYW5zcGFyZW50IHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtc2xhdGUtMjAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPEJvb2tPcGVuIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgUkVBRE1FLm1kIEdlbmVyYXRvclxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIENvbnRlbnRzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdxdWlja3N0YXJ0JyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLWN5YW4tOTUwLzMwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgdGV4dC14cyB0ZXh0LWN5YW4tMjAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtY3lhbi0zMDBcIj5cbiAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+IFJlYWR5IGZvciBHaXRIdWJcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICBZb3UgY2FuIHB1c2ggdGhpcyBwcm9qZWN0IGRpcmVjdGx5IHRvIEdpdEh1YiBpbiAzMCBzZWNvbmRzLiBGaXJzdCBjcmVhdGUgYW4gZW1wdHkgcmVwb3NpdG9yeSBvbiBHaXRIdWIgbmFtZWQgPHN0cm9uZz50ZXRyaXMtcHJvLWFyY2FkZTwvc3Ryb25nPiwgdGhlbiBydW4gdGhlc2UgY29tbWFuZHMgaW4geW91ciB0ZXJtaW5hbDpcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcC00IGZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIG92ZXJmbG93LXgtYXV0b1wiPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvcHlUb0NsaXBib2FyZChnaXRDb21tYW5kcywgJ2dpdCcpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTMgcmlnaHQtMyBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHB4LTMgcHktMS41IHJvdW5kZWQtbGcgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCB0cmFuc2l0aW9uLWNvbG9ycyB0ZXh0LXhzIGZvbnQtc2FucyBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2NvcGllZFNlY3Rpb24gPT09ICdnaXQnID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwXCI+Q29waWVkITwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC8+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxDb3B5IGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Db3B5IENvbW1hbmRzPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPHByZSBjbGFzc05hbWU9XCJwci0yNFwiPntnaXRDb21tYW5kc308L3ByZT5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEdpdEh1YiBQYWdlcyAxLWNsaWNrIGd1aWRlICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICBIb3cgdG8gaG9zdCBvbiBHaXRIdWIgUGFnZXMgZm9yIEZyZWVcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxvbCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIHNwYWNlLXktMS41IGxpc3QtZGVjaW1hbCBsaXN0LWluc2lkZVwiPlxuICAgICAgICAgICAgICAgICAgPGxpPlB1c2ggeW91ciBjb2RlIHRvIHlvdXIgR2l0SHViIHJlcG8gZm9sbG93aW5nIHRoZSBjb21tYW5kcyBhYm92ZS48L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPkluIHlvdXIgR2l0SHViIHJlcG8sIGNsaWNrIDxzdHJvbmc+U2V0dGluZ3M8L3N0cm9uZz4gJmd0OyA8c3Ryb25nPlBhZ2VzPC9zdHJvbmc+LjwvbGk+XG4gICAgICAgICAgICAgICAgICA8bGk+VW5kZXIgPHN0cm9uZz5CdWlsZCBhbmQgZGVwbG95bWVudDwvc3Ryb25nPiwgc2VsZWN0IDxzdHJvbmc+R2l0SHViIEFjdGlvbnM8L3N0cm9uZz4gb3IgPHN0cm9uZz5EZXBsb3kgZnJvbSBhIGJyYW5jaDwvc3Ryb25nPi48L2xpPlxuICAgICAgICAgICAgICAgICAgPGxpPllvdXIgZ2FtZSB3aWxsIGJlIGxpdmUgZm9yIGV2ZXJ5b25lIGF0IDxjb2RlIGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgZm9udC1tb25vXCI+aHR0cHM6Ly8mbHQ7dXNlcm5hbWUmZ3Q7LmdpdGh1Yi5pby90ZXRyaXMtcHJvLWFyY2FkZS88L2NvZGU+ITwvbGk+XG4gICAgICAgICAgICAgICAgPC9vbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ2Rvd25sb2FkJyAmJiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNCB0ZXh0LWNlbnRlciBweS02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNiBoLTE2IHJvdW5kZWQtMnhsIGJnLWN5YW4tNTAwLzEwIGJvcmRlciBib3JkZXItY3lhbi01MDAvMzAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbXgtYXV0byB0ZXh0LWN5YW4tNDAwXCI+XG4gICAgICAgICAgICAgICAgPERvd25sb2FkIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+RG93bmxvYWQgQ29tcGxldGUgUHJvamVjdCBBcmNoaXZlPC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG1heC13LW1kIG14LWF1dG8gbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgQnVuZGxlcyBhbGwgY29tcG9uZW50cywgYXVkaW8gc3ludGhlc2l6ZXJzLCByb3RhdGlvbiBhbGdvcml0aG1zLCBWaXRlIGJ1aWxkIGNvbmZpZ3MsIGFuZCBkb2N1bWVudGF0aW9uIGludG8gYSBzaW5nbGUgcmVhZHktdG8tdW56aXAgLnppcCBmaWxlLlxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRG93bmxvYWRaaXB9XG4gICAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXNaaXBwaW5nfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTYgcHktMyByb3VuZGVkLXhsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1jeWFuLTUwMCB0by1ibHVlLTYwMCBob3Zlcjpmcm9tLWN5YW4tNDAwIGhvdmVyOnRvLWJsdWUtNTAwIHRleHQtd2hpdGUgZm9udC1ib2xkIHRleHQtc20gc2hhZG93LWxnIHNoYWRvdy1jeWFuLTUwMC8yMCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi1hbGwgZGlzYWJsZWQ6b3BhY2l0eS01MFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2lzWmlwcGluZyA/IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNCBoLTQgYm9yZGVyLTIgYm9yZGVyLXdoaXRlIGJvcmRlci10LXRyYW5zcGFyZW50IHJvdW5kZWQtZnVsbCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPlBhY2thZ2luZyBaaXAuLi48L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICA8RG93bmxvYWQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RG93bmxvYWQgdGV0cmlzLXByby1hcmNhZGUuemlwPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHthY3RpdmVUYWIgPT09ICdyZWFkbWUnICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlJlYWR5LW1hZGUgUkVBRE1FLm1kIGZvciB5b3VyIEdpdEh1YiByZXBvc2l0b3J5Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb3B5VG9DbGlwYm9hcmQocmVhZG1lQ29udGVudCwgJ3JlYWRtZScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBweC0zIHB5LTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0yMDAgdHJhbnNpdGlvbi1jb2xvcnMgdGV4dC14cyBmb250LW1lZGl1bVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge2NvcGllZFNlY3Rpb24gPT09ICdyZWFkbWUnID8gKFxuICAgICAgICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNDAwXCI+Q29waWVkIE1hcmtkb3duPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgICAgPENvcHkgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNvcHkgUkVBRE1FPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQteGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIG1heC1oLTk2IG92ZXJmbG93LXktYXV0byBmb250LW1vbm8gdGV4dC14cyB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgIDxwcmUgY2xhc3NOYW1lPVwid2hpdGVzcGFjZS1wcmUtd3JhcFwiPntyZWFkbWVDb250ZW50fTwvcHJlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBGb290ZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTYgcHktMyBib3JkZXItdCBib3JkZXItc2xhdGUtODAwIGJnLXNsYXRlLTk1MFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICBPcGVuLXNvdXJjZSBNSVQgbGljZW5zZWQgwrcgR2l0SHViIHJlYWR5XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTEuNSByb3VuZGVkLWxnIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXdoaXRlIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICBDbG9zZVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==